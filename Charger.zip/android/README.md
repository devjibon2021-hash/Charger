# Charging Assistant - Android Native Application (চার্জিং সহকারী)

এই ফোল্ডারে সম্পূর্ণ Native Android Project রয়েছে যা ব্যাকগ্রাউন্ডে চার্জিং মনিটরিং, 10/15 মিনিট ভয়েস রিমাইন্ডার এবং কাস্টম ভয়েস অ্যালার্ট পরিচালনা করে।

## প্রধান আর্কিটেকচার বৈশিষ্ট্য:

1. **Native Foreground Service (`ChargingForegroundService`)**:
   - অ্যাপের স্ক্রিন অফ বা লক থাকলেও Android-এর নিয়ম অনুযায়ী সার্ভিস ব্যাকগ্রাউন্ডে চলমান থাকে।
   - নোটিফিকেশন বারে সার্বক্ষণিক লাইভ ব্যাটারি পার্সেন্টেজ ও চার্জিং অবস্থা দেখায়।
   - চার্জার লাগানো বা খোলার সাথে সাথে ব্রডকাস্ট রিসিভার ইভেন্ট গ্রহণ করে।

2. **Native Text-to-Speech (`BengaliTTSHelper`)**:
   - `Locale("bn", "BD")` ও `Locale("bn", "IN")` ব্যবহার করে নেটিভ বাংলা উচ্চারণ।
   - লকস্ক্রিনে অডিও প্লেব্যাকের জন্য `AudioAttributes.USAGE_ASSISTANCE_SONIFICATION` এবং সাময়িক `WakeLock` সমন্বয়।
   - ব্যবহারকারীর লিখিত **Custom Voice Message** অগ্রাধিকার পায় এবং কোনো অবস্থাতেই ডিফল্ট মেসেজ দ্বারা ওভাররাইড হয় না।

3. **10/15 মিনিট পর পর Voice Reminder**:
   - চার্জার লাগানো মাত্রই নির্ধারিত বিরতিতে (১০ মিনিট, ১৫ মিনিট ইত্যাদি) `AlarmManager` ও `Handler` টাইমার শুরু হয়।
   - প্রতিটি সাইকেলে ব্যবহারকারীর সংরক্ষিত কাস্টম ভয়েস মেসেজ পড়ে শোনায়।
   - চার্জার বিচ্ছিন্ন হলে স্বয়ংক্রিয়ভাবে টাইমার বন্ধ হয়।

4. **React ↔ Native Bridge (`ChargingAssistantBridge`)**:
   - WebView-এর ভেতরে `@JavascriptInterface` এর মাধ্যমে সেটিংস ও ইভেন্ট আদান-প্রদান হয়।
   - লাইভ ব্যাটারি আপডেট React UI-তে পাঠানো হয়।

5. **ডিভাইস রিস্টার্ট সাপোর্ট (`BootReceiver`)**:
   - ফোন রিস্টার্ট হলে `BOOT_COMPLETED` রিসিভার স্বয়ংক্রিয়ভাবে সার্ভিসকে পুনরায় চালু করে।

6. **Battery Optimization ও Unrestricted মোড**:
   - সেটিংস থেকে এক ক্লিকে Android সিস্টেমের Battery Optimization সেটিংস খুলে দেওয়া যায়।

## কীভাবে Build করবেন (Build Instructions):

### অপশন ১: Android Studio দিয়ে:
1. Android Studio খুলুন।
2. **Open an Existing Project** সিলেক্ট করে এই `/android` ফোল্ডারটি ওপেন করুন।
3. Gradle Sync শেষ হতে দিন।
4. আপনার ফোন বা এমুলেটর কানেক্ট করে **Run 'app'** (Shift + F10) চাপুন।
5. APK তৈরি করতে: **Build > Build Bundle(s) / APK(s) > Build APK(s)**।

### অপশন ২: Command Line (Gradle) দিয়ে:
```bash
cd android
# Debug APK তৈরি করতে:
./gradlew assembleDebug

# রিলিজ APK তৈরি করতে:
./gradlew assembleRelease
```
তৈরি হওয়া APK পাবেন: `android/app/build/outputs/apk/debug/app-debug.apk`
