import React, { useState } from 'react';
import {
  Zap,
  BellRing,
  ShieldCheck,
  Heart,
  Sparkles,
  Power,
  Volume2,
  MessageSquare,
  Headphones,
  Usb,
  Radio,
  Smartphone,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Play,
  Info,
  LayoutGrid,
  Check,
} from 'lucide-react';
import { BatteryIndicator } from './BatteryIndicator';
import { BatteryState, AppSettings } from '../types';
import { BackgroundServiceState } from '../services/backgroundService';
import { toBn } from '../utils/bnUtils';

interface HomeViewProps {
  batteryState: BatteryState;
  settings: AppSettings;
  reminderActive: boolean;
  reminderSecondsLeft: number;
  onStopReminder: () => void;
  notificationPermission: NotificationPermission;
  onRequestNotificationPermission: () => void;
  onOpenDiagnostic: () => void;
  onToggleService?: () => void;
  onNavigateTab: (tab: 'charging' | 'chat' | 'stats' | 'alerts' | 'settings') => void;
  onUpdateSettings?: (newSettings: Partial<AppSettings>) => void;
  backgroundState?: BackgroundServiceState;
  backgroundTesting?: boolean;
  backgroundCountdown?: number | null;
  onTestBackgroundVoice?: (delaySeconds?: number) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  batteryState,
  settings,
  reminderActive,
  reminderSecondsLeft,
  onStopReminder,
  notificationPermission,
  onRequestNotificationPermission,
  onOpenDiagnostic,
  onToggleService,
  onNavigateTab,
  onUpdateSettings,
  backgroundState,
  backgroundTesting,
  backgroundCountdown,
  onTestBackgroundVoice,
}) => {
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);
  const [showWidgetGuide, setShowWidgetGuide] = useState(false);
  const [widgetPinnedSuccess, setWidgetPinnedSuccess] = useState(false);
  const targetLevel = settings.targetBatteryLevel === 0 ? settings.customTargetLevel : settings.targetBatteryLevel;
  const isServiceOn = settings.serviceEnabled !== false;
  const isBgOn = settings.backgroundModeEnabled !== false && isServiceOn;

  const handlePinWidget = () => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (
        w.ChargingAssistantNative &&
        typeof (w.ChargingAssistantNative as Record<string, unknown>).requestPinWidget === 'function'
      ) {
        const success = Boolean((w.ChargingAssistantNative as { requestPinWidget: () => boolean }).requestPinWidget());
        if (success) {
          setWidgetPinnedSuccess(true);
          setTimeout(() => setWidgetPinnedSuccess(false), 4000);
          return;
        }
      }
    }
    setShowWidgetGuide((prev) => !prev);
  };

  const [nativeServiceRunning, setNativeServiceRunning] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).isServiceRunning === 'function') {
        return Boolean((w.ChargingAssistantNative as { isServiceRunning: () => boolean }).isServiceRunning());
      }
    }
    return false;
  });

  React.useEffect(() => {
    const checkService = () => {
      if (typeof window !== 'undefined') {
        const w = window as unknown as Record<string, unknown>;
        if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).isServiceRunning === 'function') {
          const running = Boolean((w.ChargingAssistantNative as { isServiceRunning: () => boolean }).isServiceRunning());
          setNativeServiceRunning(running);
        }
      }
    };

    const handleStatusEvent = (e: Event) => {
      const customEv = e as CustomEvent<{ isRunning: boolean }>;
      if (customEv?.detail && typeof customEv.detail.isRunning === 'boolean') {
        setNativeServiceRunning(customEv.detail.isRunning);
      } else {
        checkService();
      }
    };

    checkService();
    window.addEventListener('nativeServiceStatus', handleStatusEvent);
    window.addEventListener('nativeBridgeReady', checkService);
    const interval = setInterval(checkService, 3000);

    return () => {
      window.removeEventListener('nativeServiceStatus', handleStatusEvent);
      window.removeEventListener('nativeBridgeReady', checkService);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="space-y-4 pb-20">
      {/* 0. Master ON / OFF Control Card */}
      <div
        className={`p-4 rounded-2xl border shadow-xs transition-all ${
          isServiceOn
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-50'
            : 'bg-rose-500/10 border-rose-500/30 text-rose-950 dark:text-rose-50'
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-xs ${
                isServiceOn
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-600 text-white'
              }`}
            >
              <Power className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold tracking-tight">
                  {isServiceOn ? 'চার্জিং সহকারী চালু (ON)' : 'চার্জিং সহকারী বন্ধ (OFF)'}
                </span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    isServiceOn ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                  }`}
                />
              </div>
              <p className="text-[11px] opacity-80 mt-0.5 leading-tight">
                {isServiceOn
                  ? 'ব্যাটারি, চার্জার, USB ও ইয়ারফোন ভয়েস অ্যালার্ট সক্রিয় রয়েছে।'
                  : 'সকল ভয়েস কথা বলা, শব্দ ও নোটিফিকেশন সাময়িক বন্ধ আছে।'}
              </p>
            </div>
          </div>

          {onToggleService && (
            <div className="flex items-center bg-white dark:bg-zinc-900 rounded-xl p-1 border border-zinc-200/80 dark:border-zinc-800 shadow-2xs shrink-0">
              <button
                onClick={() => {
                  if (!isServiceOn) onToggleService();
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  isServiceOn
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
                }`}
              >
                ON
              </button>
              <button
                onClick={() => {
                  if (isServiceOn) onToggleService();
                }}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  !isServiceOn
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
                }`}
              >
                OFF
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 1. Main Battery Indicator */}
      <BatteryIndicator batteryState={batteryState} targetLevel={targetLevel} />

      {/* 2. Dedicated Background Voice Assistant & Quick Test Card */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3.5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                isBgOn
                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400'
              }`}
            >
              <Radio className={`w-4 h-4 ${isBgOn ? 'animate-pulse' : ''}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                  ব্যাকগ্রাউন্ড ভয়েস সহকারী
                </span>
                <span
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    isBgOn
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                      : 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400'
                  }`}
                >
                  {isBgOn ? 'সক্রিয় (Active)' : 'বন্ধ (Off)'}
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
                {isBgOn
                  ? 'অ্যাপ মিনিমাইজ বা লক থাকলেও চার্জ ও ব্যাটারি বার্তা বলবে'
                  : 'অ্যাপ থেকে বের হলে কথা বলা বন্ধ থাকবে'}
              </p>
            </div>
          </div>

          {onUpdateSettings && (
            <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
              <input
                type="checkbox"
                checked={settings.backgroundModeEnabled !== false}
                onChange={(e) => onUpdateSettings({ backgroundModeEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          )}
        </div>

        {/* Verified Service Status UI */}
        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/60 dark:border-zinc-700/50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                nativeServiceRunning || isBgOn
                  ? 'bg-emerald-500 animate-pulse'
                  : 'bg-zinc-400'
              }`}
            />
            <span className="text-[11px] font-semibold text-zinc-800 dark:text-zinc-200">
              {nativeServiceRunning || isBgOn ? (
                <span>● Background Monitoring: Active</span>
              ) : (
                <span>○ Background Monitoring: Inactive</span>
              )}
            </span>
          </div>

          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              nativeServiceRunning
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                : isBgOn
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300'
                : 'bg-zinc-200 text-zinc-700 dark:bg-zinc-700 dark:text-zinc-300'
            }`}
          >
            {nativeServiceRunning ? 'Native Verified' : isBgOn ? 'Web PWA' : 'Off'}
          </span>
        </div>

        {/* 5-Second Background Voice Test Button & Countdown */}
        {backgroundTesting ? (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-950 dark:text-amber-50 space-y-2 animate-pulse">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                  {toBn(backgroundCountdown ?? 0)}
                </span>
                <span className="text-xs font-bold">টেস্ট চলছে! এখনই অ্যাপ থেকে বের হন</span>
              </div>
              <span className="text-[11px] font-mono text-amber-700 dark:text-amber-300">
                {toBn(backgroundCountdown ?? 0)}s
              </span>
            </div>
            <p className="text-[11px] text-amber-800 dark:text-amber-200 leading-snug">
              👉 <strong>হোম (Home) বাটন প্রেস করে</strong> ফোনের হোম স্ক্রিনে যান বা স্ক্রিন লক করুন। কাউন্টডাউন শেষে বাইরে থেকেই বাংলা ভয়েস শুনবেন!
            </p>
          </div>
        ) : (
          <button
            onClick={() => onTestBackgroundVoice?.(5)}
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>৫ সেকেন্ডের ব্যাকগ্রাউন্ড টেস্ট শুরু করুন</span>
          </button>
        )}

        {/* Android Optimization Guide Toggle */}
        <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800">
          <button
            onClick={() => setShowAndroidGuide(!showAndroidGuide)}
            className="w-full flex items-center justify-between text-left text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-zinc-100 transition py-0.5"
          >
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-zinc-500" />
              <span>মোবাইলে ব্যাকগ্রাউন্ডে চালু রাখার ৩টি নিয়ম</span>
            </div>
            {showAndroidGuide ? (
              <ChevronUp className="w-3.5 h-3.5 text-zinc-400" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
            )}
          </button>

          {showAndroidGuide && (
            <div className="mt-2.5 space-y-2 text-[11px] text-zinc-600 dark:text-zinc-400 bg-zinc-50 dark:bg-zinc-800/50 p-3 rounded-xl border border-zinc-200/70 dark:border-zinc-700/60 leading-relaxed">
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  ১
                </span>
                <span>
                  <strong>হোম বাটন চেপে মিনিমাইজ রাখুন:</strong> অ্যাপ থেকে বের হতে হোম বাটন চাপুন। রিসেন্ট অ্যাপস তালিকা থেকে সোয়াইপ করে বন্ধ করবেন না।
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  ২
                </span>
                <span>
                  <strong>নোটিফিকেশন চালু রাখুন:</strong> পুশ নোটিফিকেশন অনুমোদন দিলে Android লকস্ক্রিনেও ভয়েস সার্ভিস চালু রাখে।
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  ৩
                </span>
                <span>
                  <strong>ব্যাটারি অপটিমাইজেশন বন্ধ করুন:</strong> Android Settings &gt; Apps &gt; সহকারী &gt; Battery &gt; <strong>Unrestricted (সীমাহীন)</strong> করুন যাতে ফোন এটিকে ঘুম পাড়িয়ে না দেয়।
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  ৪
                </span>
                <span>
                  <strong>স্ক্রিন অফেও সার্বক্ষণিক সুরক্ষা:</strong> ফোন লক বা ডিসপ্লে বন্ধ থাকলেও নেটিভ ফোরগ্রাউন্ড সার্ভিস ও ওয়েক-লকের মাধ্যমে চার্জার সংযোগ, বিচ্ছিন্নতা ও রিমাইন্ডার স্বয়ংক্রিয়ভাবে বেজে উঠবে।
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 2. Android Home Screen Widget Card */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                  হোম স্ক্রিন উইজেট (Home Widget)
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  Android Native
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                অ্যাপ না খুলেই মোবাইলের হোম স্ক্রিনে ব্যাটারি ও চার্জিং লাইভ দেখতে পারবেন
              </p>
            </div>
          </div>
        </div>

        {/* Live Widget Mockup Preview */}
        <div className="p-3.5 rounded-xl bg-zinc-900 text-white border border-zinc-800 shadow-inner space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-semibold">
              <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
              <span>চার্জিং সহকারী</span>
            </div>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                batteryState.charging
                  ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {batteryState.charging ? 'চার্জ হচ্ছে ⚡' : 'সক্রিয়'}
            </span>
          </div>

          <div className="flex items-center justify-between pt-0.5">
            <div className="text-2xl font-black text-white tracking-tight">
              {toBn(batteryState.levelPercent)}%
            </div>
            <div className="text-right">
              <div className="text-xs font-bold text-zinc-200">
                {batteryState.charging ? 'চার্জিং চলছে ⚡' : 'চার্জার সংযোগ নেই'}
              </div>
              <div className="text-[10px] text-zinc-400">
                {batteryState.temperature !== null ? `${toBn(batteryState.temperature)}°C • ` : ''}টার্গেট: {toBn(targetLevel)}%
              </div>
            </div>
          </div>

          {/* Mini progress bar */}
          <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${batteryState.charging ? 'bg-emerald-500' : 'bg-emerald-400'}`}
              style={{ width: `${Math.min(100, Math.max(0, batteryState.levelPercent))}%` }}
            />
          </div>

          <div className="flex items-center justify-between pt-1 text-[10px] text-zinc-400 border-t border-zinc-800/80">
            <span>স্ক্রিন অফেও ভয়েস ও অ্যালার্ট চালু থাকে</span>
            <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 text-[10px]">
              🔊 উইজেট বাটন
            </span>
          </div>
        </div>

        {/* Action Button */}
        {widgetPinnedSuccess ? (
          <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-900 dark:text-emerald-100 flex items-center justify-center gap-2 text-xs font-semibold">
            <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>উইজেট অনুরোধ পাঠানো হয়েছে! হোম স্ক্রিন চেক করুন।</span>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handlePinWidget}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>হোম স্ক্রিনে পিন করুন</span>
            </button>
            <button
              type="button"
              onClick={() => setShowWidgetGuide(!showWidgetGuide)}
              className="py-2.5 px-3 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-medium flex items-center justify-center gap-1.5 transition"
            >
              <Info className="w-3.5 h-3.5 text-zinc-500" />
              <span>উইজেট আনার নিয়ম</span>
            </button>
          </div>
        )}

        {/* Collapsible Widget Manual Setup Guide */}
        {showWidgetGuide && (
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60 text-xs text-zinc-600 dark:text-zinc-400 space-y-2 leading-relaxed">
            <div className="font-semibold text-zinc-800 dark:text-zinc-200 text-xs flex items-center gap-1.5">
              <span>📱 অ্যান্ড্রয়েড হোম স্ক্রিনে উইজেট সেট করার নিয়ম:</span>
            </div>
            <div className="space-y-1 text-[11px]">
              <p>১. ফোনের হোম স্ক্রিনে যে কোনো খালি জায়গায় <strong>২-৩ সেকেন্ড চেপে ধরে রাখুন</strong> (Touch & Hold)।</p>
              <p>২. নিচে আসা অপশনগুলো থেকে <strong>'Widgets' (উইজেট)</strong> আইকনে চাপুন।</p>
              <p>৩. তালিকা থেকে <strong>'চার্জিং সহকারী' (Charging Assistant)</strong> উইজেটটি খুঁজে বের করুন।</p>
              <p>৪. উইজেটটি চেপে ধরে ড্র্যাগ করে আপনার পছন্দের হোম স্ক্রিনে বসিয়ে দিন।</p>
            </div>
          </div>
        )}
      </div>

      {/* Active Repeated Reminder Banner (Section 4) */}
      {reminderActive && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-900 dark:text-amber-100 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500 text-white shadow-xs">
              <BellRing className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-semibold">পুনরাবৃত্তিমূলক রিমাইন্ডার সক্রিয়</div>
              <div className="text-[11px] text-amber-700 dark:text-amber-300">
                পরবর্তী সংকেত: {toBn(Math.ceil(reminderSecondsLeft / 60))} মিনিট পর
              </div>
            </div>
          </div>
          <button
            onClick={onStopReminder}
            className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs transition"
          >
            রিমাইন্ডার বন্ধ করুন
          </button>
        </div>
      )}

      {/* Notification Permission Card (if not granted) */}
      {notificationPermission !== 'granted' && (
        <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-500" />
            </div>
            <div>
              <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                চার্জিং নোটিফিকেশন চালু করুন
              </div>
              <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                টার্গেট চার্জ ও চার্জার বিচ্ছিন্ন হলে সাথে সাথে সতর্কতা পাবেন
              </div>
            </div>
          </div>
          <button
            onClick={onRequestNotificationPermission}
            className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-white dark:text-zinc-900 text-xs font-medium shadow-xs transition flex-shrink-0"
          >
            অনুমতি দিন
          </button>
        </div>
      )}

      {/* Target & Protection Tip Card */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 dark:text-zinc-100">
            <Heart className="w-4 h-4 text-rose-500" />
            <span>ব্যাটারি দীর্ঘায়ু টিপস</span>
          </div>
          <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/50 font-medium">
            {toBn(targetLevel)}% নির্ধারিত
          </span>
        </div>
        <p className="mt-2 text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
          লিথিয়াম-আয়ন ব্যাটারি ৮০% থেকে ৮৫% পর্যন্ত চার্জ রাখলে ব্যাটারির ক্ষয়রোধ হয় এবং ডিভাইসের ব্যাটারি লাইফ সাধারণ ব্যবহারের চেয়ে দ্বিগুণ পর্যন্ত দীর্ঘস্থায়ী হয়।
        </p>
        <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
          <span className="text-[11px] text-zinc-400">টার্গেট পরিবর্তন করতে চান?</span>
          <button
            onClick={() => onNavigateTab('charging')}
            className="text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline underline-offset-2"
          >
            টার্গেট সেট করুন →
          </button>
        </div>
      </div>

      {/* Quick Action Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => onNavigateTab('chat')}
          className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 text-left hover:border-emerald-500/50 transition shadow-xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <Volume2 className="w-4 h-4" />
          </div>
          <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">ভয়েস রাইটার ও চ্যাট</div>
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
            বাংলায় যা লিখবেন তাই বলবে + English Chat
          </div>
        </button>

        <button
          onClick={() => onNavigateTab('alerts')}
          className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 text-left hover:border-blue-500/50 transition shadow-xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <Headphones className="w-4 h-4" />
          </div>
          <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">USB ও ইয়ারফোন এলার্ট</div>
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
            সংযোগ ও বিচ্ছিন্ন হলে ভয়েস সতর্কতা
          </div>
        </button>

        <button
          onClick={() => onNavigateTab('charging')}
          className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 text-left hover:border-zinc-350 dark:hover:border-zinc-700 transition shadow-xs"
        >
          <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2">
            <Zap className="w-4 h-4 fill-current" />
          </div>
          <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">চার্জিং ক্যালকুলেটর</div>
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
            টার্গেট ও সময় হিসাব করুন
          </div>
        </button>

        <button
          onClick={() => onNavigateTab('stats')}
          className="p-3.5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 text-left hover:border-zinc-350 dark:hover:border-zinc-700 transition shadow-xs"
        >
          <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-2">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">চার্জিং হিস্ট্রি ও স্ট্যাটস</div>
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
            সেশন ও ব্যাটারি স্থায়িত্ব
          </div>
        </button>
      </div>
    </div>
  );
};
