import React, { useState } from 'react';
import { Zap, AlertCircle, Info, ShieldCheck, Thermometer, Gauge, Activity, BatteryCharging, Battery } from 'lucide-react';
import { BatteryState } from '../types';
import { toBn, toBnPercent } from '../utils/bnUtils';

interface BatteryIndicatorProps {
  batteryState: BatteryState;
  targetLevel: number;
}

export const BatteryIndicator: React.FC<BatteryIndicatorProps> = ({
  batteryState,
  targetLevel,
}) => {
  const [showApiInfo, setShowApiInfo] = useState(false);
  const pct = batteryState.levelPercent;
  const isCharging = batteryState.charging;

  // Determine color scheme based on level and charging state
  let colorTheme = 'emerald';
  if (pct <= 20) {
    colorTheme = 'rose';
  } else if (pct <= 45) {
    colorTheme = 'amber';
  }

  const getGradient = () => {
    if (colorTheme === 'rose') return 'from-rose-500 to-red-600';
    if (colorTheme === 'amber') return 'from-amber-400 to-amber-600';
    return 'from-emerald-400 to-teal-600';
  };

  const getRingColor = () => {
    if (colorTheme === 'rose') return 'stroke-rose-500';
    if (colorTheme === 'amber') return 'stroke-amber-500';
    return 'stroke-emerald-500';
  };

  // SVG Circular progress math
  const radius = 88;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (pct / 100) * circumference;

  return (
    <div className="w-full">
      {/* Central Indicator Card */}
      <div className="relative overflow-hidden rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 p-5 sm:p-6 shadow-xs">
        {/* Glow backdrop during charging */}
        {isCharging && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 h-56 bg-emerald-500/8 dark:bg-emerald-500/10 blur-2xl rounded-full pointer-events-none" />
        )}

        <div className="relative flex flex-col items-center justify-center">
          {/* Circular Battery Dial */}
          <div className="relative w-48 h-48 sm:w-52 sm:h-52 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 200 200">
              {/* Background Track */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-zinc-100 dark:stroke-zinc-800"
                strokeWidth="10"
                fill="none"
              />
              {/* Progress Ring */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className={`${getRingColor()} transition-all duration-700 ease-out`}
                strokeWidth="10"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="none"
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              {/* Charging Status Pill */}
              <div className="flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-medium mb-1 transition-all">
                {isCharging ? (
                  <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 dark:text-emerald-300 dark:bg-emerald-950/60 border border-emerald-200/60 dark:border-emerald-800/50">
                    <Zap className="w-3.5 h-3.5 fill-current animate-pulse" />
                    চার্জ হচ্ছে
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-zinc-600 bg-zinc-100 dark:text-zinc-300 dark:bg-zinc-800/80 border border-zinc-200/60 dark:border-zinc-700/60">
                    <Battery className="w-3.5 h-3.5" />
                    ব্যাটারিতে চলছে
                  </span>
                )}
              </div>

              {/* Big Percentage */}
              <div className="flex items-baseline justify-center font-bold tracking-tighter text-zinc-950 dark:text-zinc-50">
                <span className="text-5xl font-mono">{toBn(pct)}</span>
                <span className="text-xl text-zinc-400 font-sans ml-0.5 font-normal">%</span>
              </div>

              {/* Target Indicator badge */}
              <div className="mt-1 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                টার্গেট: <span className="font-semibold text-zinc-800 dark:text-zinc-200">{toBn(targetLevel)}%</span>
              </div>
            </div>
          </div>

          {/* Quick Hardware Status Summary Badge */}
          <div className="mt-3 flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-zinc-100/90 dark:bg-zinc-800/80 text-zinc-700 dark:text-zinc-300 border border-zinc-200/60 dark:border-zinc-700/60">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              হেলথ: ভালো (Good)
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-zinc-100/90 dark:bg-zinc-800/80 text-zinc-700 dark:text-zinc-300 border border-zinc-200/60 dark:border-zinc-700/60">
              <BatteryCharging className="w-3.5 h-3.5 text-blue-500" />
              লেভেল: {pct >= 80 ? 'উচ্চ (High)' : pct >= 25 ? 'স্বাভাবিক (Normal)' : 'স্বল্প (Low)'}
            </span>
          </div>
        </div>

        {/* Real Hardware Metrics Section */}
        <div className="mt-6 pt-5 border-t border-zinc-200/70 dark:border-zinc-800/70">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              ডিভাইস ও ব্যাটারি মেট্রিক্স
            </h3>
            <button
              onClick={() => setShowApiInfo(!showApiInfo)}
              className="text-[11px] text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200 font-medium underline underline-offset-2 flex items-center gap-0.5"
            >
              <Info className="w-3 h-3" />
              API তথ্য
            </button>
          </div>

          {/* API Information Callout */}
          {showApiInfo && (
            <div className="mb-3 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-600 dark:text-zinc-400 leading-relaxed">
              <p className="font-semibold text-zinc-900 dark:text-zinc-200 mb-1">প্রামাণিক তথ্য নীতি (No Fake Data):</p>
              বর্তমান স্ট্যান্ডার্ড ব্রাউজার ও ওয়েব এপিআই শুধুমাত্র ব্যাটারি পার্সেন্টেজ ও চার্জিং স্টেট প্রকাশ করে। তাপমাত্রা, ভোল্টেজ ও ওয়াট সরাসরি পেতে নেটিভ Android OEM পারমিশন প্রয়োজন। তাই আমরা ভুয়া সংখ্যা না দেখিয়ে সঠিক অবস্থা তুলে ধরছি।
            </div>
          )}

          {/* 4-Metric Grid */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* Temperature */}
            <div className="p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60">
              <div className="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                  তাপমাত্রা
                </span>
                <span className="text-[10px] text-zinc-400">°C</span>
              </div>
              <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                {batteryState.temperature !== null ? (
                  `${toBn(batteryState.temperature)}°C`
                ) : (
                  <span className="text-xs font-normal text-zinc-500 dark:text-zinc-400">
                    ডিভাইসে উপলব্ধ নয়
                  </span>
                )}
              </div>
            </div>

            {/* Voltage */}
            <div className="p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60">
              <div className="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Gauge className="w-3.5 h-3.5 text-blue-500" />
                  Voltage
                </span>
                <span className="text-[10px] text-zinc-400">V</span>
              </div>
              <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                {batteryState.voltage !== null ? (
                  `${toBn(batteryState.voltage)}V`
                ) : (
                  <span className="text-xs font-normal text-zinc-500 dark:text-zinc-400">
                    ডিভাইসে উপলব্ধ নয়
                  </span>
                )}
              </div>
            </div>

            {/* Current */}
            <div className="p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60">
              <div className="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-purple-500" />
                  Current (অ্যাম্পিয়ার)
                </span>
                <span className="text-[10px] text-zinc-400">A</span>
              </div>
              <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                {batteryState.current !== null ? (
                  `${toBn(batteryState.current)}A`
                ) : (
                  <span className="text-xs font-normal text-zinc-500 dark:text-zinc-400">
                    ডিভাইসে উপলব্ধ নয়
                  </span>
                )}
              </div>
            </div>

            {/* Power / Watt */}
            <div className="p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60">
              <div className="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-emerald-500" />
                  Power (পাওয়ার)
                </span>
                <span className="text-[10px] text-zinc-400">W</span>
              </div>
              <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                {batteryState.power !== null ? (
                  `${toBn(batteryState.power)}W`
                ) : (
                  <span className="text-xs font-normal text-zinc-500 dark:text-zinc-400">
                    ডিভাইসে উপলব্ধ নয়
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Charging Type / Source */}
          <div className="mt-2.5 p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60 flex items-center justify-between">
            <span className="text-xs text-zinc-600 dark:text-zinc-400 font-medium">
              চার্জিং টাইপ:
            </span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              {isCharging ? 'AC অ্যাডাপ্টার / ফাস্ট চার্জ' : 'ডিসকানেক্টেড (অফ)'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
