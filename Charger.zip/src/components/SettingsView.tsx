import React, { useState } from 'react';
import {
  Settings,
  Bell,
  Volume2,
  Mic,
  Vibrate,
  Moon,
  Sun,
  Monitor,
  Smartphone,
  RotateCcw,
  Trash2,
  Info,
  Check,
  Package,
  ExternalLink,
  Copy,
  Download,
  VolumeX,
  Radio,
  Sliders,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Zap,
  AlertTriangle,
  Layers,
  Play,
  MessageSquare,
  Sparkles,
  ShieldCheck,
  Clock,
  BellRing,
  LayoutGrid,
} from 'lucide-react';
import { AppSettings, BatteryState, VoiceMode, AlertEventKey, AlertChannels } from '../types';
import { getDeviceInfo } from '../utils/deviceInfo';
import { toBn } from '../utils/bnUtils';
import { DEFAULT_SETTINGS } from '../utils/storage';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useBengaliVoice } from '../hooks/useBengaliVoice';
import { alertEngine } from '../utils/alertEngine';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  batteryState: BatteryState;
  onClearHistory: () => void;
  onResetSettings: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  batteryState,
  onClearHistory,
  onResetSettings,
}) => {
  const [deviceInfo] = useState(getDeviceInfo());
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showClearHistoryConfirm, setShowClearHistoryConfirm] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showChannelsSection, setShowChannelsSection] = useState(true);
  const [showBatteryGuide, setShowBatteryGuide] = useState(false);
  const [reminderTesting, setReminderTesting] = useState(false);
  const { isInstallable, install } = usePWAInstall();
  const voice = useBengaliVoice();

  const [isBatteryOptimizationIgnored, setIsBatteryOptimizationIgnored] = useState<boolean | null>(() => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).isBatteryOptimizationIgnored === 'function') {
        return Boolean((w.ChargingAssistantNative as { isBatteryOptimizationIgnored: () => boolean }).isBatteryOptimizationIgnored());
      }
    }
    return null;
  });

  const checkBatteryOptimization = () => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).isBatteryOptimizationIgnored === 'function') {
        setIsBatteryOptimizationIgnored(Boolean((w.ChargingAssistantNative as { isBatteryOptimizationIgnored: () => boolean }).isBatteryOptimizationIgnored()));
      }
    }
  };

  React.useEffect(() => {
    checkBatteryOptimization();
    window.addEventListener('focus', checkBatteryOptimization);
    return () => {
      window.removeEventListener('focus', checkBatteryOptimization);
    };
  }, []);

  // App URLs
  const shareAppUrl = 'https://ais-pre-65n4szlilzab2m2yqvmoue-790463454183.europe-west2.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(shareAppUrl)}`;

  const handleCopyLink = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(shareAppUrl).then(() => {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      }).catch(() => {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      });
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleVoiceModeChange = (mode: VoiceMode) => {
    onUpdateSettings({ voiceMode: mode });
    voice.setVoiceMode(mode);
  };

  const handleChannelToggle = (
    alertKey: AlertEventKey,
    channel: 'voice' | 'sound' | 'vibration' | 'notification'
  ) => {
    const currentChannels: AlertChannels = settings.alertChannels || DEFAULT_SETTINGS.alertChannels;
    const alertConfig = currentChannels[alertKey] || {
      voice: true,
      sound: true,
      vibration: true,
      notification: true,
    };
    const updated: AlertChannels = {
      ...currentChannels,
      [alertKey]: {
        ...alertConfig,
        [channel]: !alertConfig[channel],
      },
    };
    onUpdateSettings({ alertChannels: updated });
  };

  const alertItems: Array<{
    key: AlertEventKey;
    title: string;
    description: string;
  }> = [
    { key: 'charger_connected', title: 'চার্জার সংযোগ', description: 'চার্জার প্লাগ ইন করলে' },
    { key: 'target_reached', title: 'লক্ষ্যমাত্রা চার্জ', description: 'নির্দিষ্ট চার্জ শতাংশে পৌঁছালে' },
    { key: 'charging_complete', title: 'পূর্ণ চার্জ (১০০%)', description: '১০০% চার্জ সম্পন্ন হলে' },
    { key: 'charger_removed', title: 'চার্জার বিচ্ছিন্ন', description: 'চার্জার খুলে ফেলা হলে' },
    { key: 'temperature_warning', title: 'উচ্চ তাপমাত্রা', description: 'ব্যাটারি নির্দিষ্ট তাপমাত্রার বেশি হলে' },
    { key: 'battery_low', title: 'কম ব্যাটারি (২০%)', description: 'চার্জ ২০%-এ নেমে এলে' },
    { key: 'reminder', title: 'পুনরাবৃত্তিমূলক রিমাইন্ডার', description: 'চার্জার না খোলা পর্যন্ত সতর্কবার্তা' },
  ];

  const currentChannels = settings.alertChannels || DEFAULT_SETTINGS.alertChannels;

  const activeCustomVoice = (
    settings.customPhrases?.target_reached ||
    settings.customPhrases?.customBengaliText ||
    settings.customPhrases?.reminder ||
    ''
  ).trim();

  const handleTestVoiceWithCustom = async () => {
    const textToSpeak = activeCustomVoice || 'এটি চার্জিং সহকারীর বাংলা ভয়েস পরীক্ষা।';
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).testVoice === 'function') {
        (w.ChargingAssistantNative as { testVoice: (t: string) => void }).testVoice(textToSpeak);
        return;
      }
    }
    voice.speakCustom(textToSpeak);
  };

  const handleTestReminder = async () => {
    setReminderTesting(true);
    const intervalMins = settings.reminderIntervalMinutes || 10;
    const textToSpeak = activeCustomVoice || 'আপনার ফোন এখনও চার্জে আছে। এটি পরীক্ষামূলক রিমাইন্ডার।';

    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).testReminder === 'function') {
        (w.ChargingAssistantNative as { testReminder: (i: number, t: string) => void }).testReminder(intervalMins, textToSpeak);
        setTimeout(() => setReminderTesting(false), 2000);
        return;
      }
    }

    // Web / PWA fallback test
    alertEngine.playTone('reminder');
    alertEngine.vibrate('reminder');
    if (settings.bengaliVoiceEnabled) {
      voice.speakCustom(textToSpeak);
    }
    setTimeout(() => setReminderTesting(false), 2000);
  };

  const handleOpenBatterySettings = () => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).requestBatteryOptimization === 'function') {
        (w.ChargingAssistantNative as { requestBatteryOptimization: () => void }).requestBatteryOptimization();
        return;
      }
    }
    setShowBatteryGuide(!showBatteryGuide);
  };

  const [showWidgetGuide, setShowWidgetGuide] = useState(false);
  const [widgetPinnedSuccess, setWidgetPinnedSuccess] = useState(false);

  const handlePinWidget = () => {
    if (typeof window !== 'undefined') {
      const w = window as unknown as Record<string, unknown>;
      if (
        w.ChargingAssistantNative &&
        typeof (w.ChargingAssistantNative as Record<string, unknown>).requestPinWidget === 'function'
      ) {
        const success = Boolean((w.ChargingAssistantNative as { requestPinWidget: () => boolean }).requestPinWidget());
        if (success) {
          setWidgetPinnedSuccess(true);
          setTimeout(() => setWidgetPinnedSuccess(false), 4000);
          return;
        }
      }
    }
    setShowWidgetGuide((prev) => !prev);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Global Alert Controls */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 flex items-center justify-center">
            <Settings className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              অ্যাপ সেটিংস ও পছন্দসমূহ
            </h2>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              অ্যালার্ট, ভয়েস ও ডিসপ্লে কনফিগারেশন
            </p>
          </div>
        </div>

        {/* Master Service ON / OFF Switch */}
        <div className="p-3.5 rounded-2xl bg-zinc-100/90 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/60 flex items-center justify-between mb-4 shadow-2xs">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-xs transition-colors ${settings.serviceEnabled !== false ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}`}>
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
                  চার্জিং সহকারী সার্ভিস (Master Switch)
                </span>
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${settings.serviceEnabled !== false ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'}`}>
                  {settings.serviceEnabled !== false ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
              </div>
              <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                {settings.serviceEnabled !== false ? 'ভয়েস, শব্দ ও নোটিফিকেশন সক্রিয় আছে' : 'সকল অ্যালার্ট ও কথা বলা সাময়িক বন্ধ'}
              </div>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.serviceEnabled !== false}
              onChange={(e) => onUpdateSettings({ serviceEnabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-zinc-300 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {/* Global Toggles */}
        <div className="space-y-4">
          {/* Bengali Voice Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">বাংলা ভয়েস অ্যালার্ট</div>
                <div className="text-[11px] text-zinc-500">বাংলায় চার্জিং ঘোষণা শুনুন</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.bengaliVoiceEnabled}
                onChange={(e) => onUpdateSettings({ bengaliVoiceEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Sound Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">সাউন্ড ইফেক্ট ও মেলোডি</div>
                <div className="text-[11px] text-zinc-500">কানেক্ট ও সম্পূর্ণ চার্জে সুর বাজবে</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Vibration Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                <Vibrate className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">ভাইব্রেশন (কম্পন)</div>
                <div className="text-[11px] text-zinc-500">ফোনের হ্যাপটিক ভাইব্রেশন প্রতিক্রিয়া</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.vibrationEnabled}
                onChange={(e) => onUpdateSettings({ vibrationEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Notification System Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">পুশ নোটিফিকেশন</div>
                <div className="text-[11px] text-zinc-500">লকস্ক্রিন ও স্ট্যাটাসবারে বার্তা প্রদর্শন</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.notificationEnabled}
                onChange={(e) => onUpdateSettings({ notificationEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Background Running Mode Toggle */}
          <div className="flex items-center justify-between pt-3 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Radio className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">ব্যাকগ্রাউন্ড ভয়েস ও কিপ-এলাইভ</div>
                <div className="text-[11px] text-zinc-500">অ্যাপ মিনিমাইজ বা স্ক্রিন লক থাকলেও কথা বলবে</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.backgroundModeEnabled !== false}
                onChange={(e) => onUpdateSettings({ backgroundModeEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Screen Wake Lock Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">চার্জিংয়ের সময় স্ক্রিন অন রাখুন</div>
                <div className="text-[11px] text-zinc-500">চার্জার লাগানো অবস্থায় ডিসপ্লে স্লিপ হবে না</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.keepScreenOnWhileCharging === true}
                onChange={(e) => onUpdateSettings({ keepScreenOnWhileCharging: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Temperature Warning Threshold */}
          <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                  তাপমাত্রা সতর্কতার সীমা (Threshold)
                </div>
                <div className="text-[11px] text-zinc-500">নির্দিষ্ট তাপমাত্রা অতিক্রম করলে সতর্ক করবে</div>
              </div>
              <span className="text-xs font-semibold font-mono text-amber-600 dark:text-amber-400">
                {toBn(settings.temperatureThreshold)}°C
              </span>
            </div>
            <input
              type="range"
              min="38"
              max="50"
              value={settings.temperatureThreshold}
              onChange={(e) => onUpdateSettings({ temperatureThreshold: parseInt(e.target.value, 10) })}
              className="w-full accent-amber-500 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Dark Mode Selector */}
          <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800">
            <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 mb-2">
              অ্যাপের থিম মোড (Theme)
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'light', label: 'লাইট মোড', icon: Sun },
                { id: 'dark', label: 'ডার্ক মোড', icon: Moon },
                { id: 'system', label: 'সিস্টেম', icon: Monitor },
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = settings.themeMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => onUpdateSettings({ themeMode: m.id as AppSettings['themeMode'] })}
                    className={`py-2 px-2.5 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition ${
                      isSelected
                        ? 'bg-zinc-900 border-zinc-900 text-white dark:bg-zinc-100 dark:border-zinc-100 dark:text-zinc-900 shadow-xs'
                        : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-600'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Dedicated Bengali Voice Engine Settings (Section 4 & 5) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                বাংলা ভয়েস সেটিংস
              </h3>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                অফলাইন অডিও ও টেক্সট-টু-স্পিচ কনফিগারেশন
              </p>
            </div>
          </div>

          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold ${
              voice.status === 'ready' || voice.status === 'android_tts'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/50'
                : voice.status === 'offline_mode'
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800/50'
                : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/50'
            }`}
          >
            <CheckCircle2 className="w-3 h-3" />
            <span>
              {voice.status === 'android_tts'
                ? 'Android TTS'
                : voice.status === 'offline_mode'
                ? 'Offline Audio'
                : 'ভয়েস প্রস্তুত'}
            </span>
          </span>
        </div>

        {/* Voice Mode Selector (Section 4 & 5) */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
            ভয়েস মোড নির্বাচন (Voice Mode)
          </div>
          <div className="grid grid-cols-1 gap-2">
            {[
              {
                mode: 'automatic' as VoiceMode,
                label: 'Automatic (স্বয়ংক্রিয় - প্রস্তাবিত)',
                desc: 'Android TTS পেলে ব্যবহার করবে, অন্যথায় নির্ভরযোগ্য অফলাইন অডিও প্লে করবে।',
              },
              {
                mode: 'android_tts' as VoiceMode,
                label: 'Android TTS (শুধুমাত্র সিস্টেম ইঞ্জিন)',
                desc: 'ফোনের গুগল বা ডিভাইসের বিল্ট-ইন বাংলা টেক্সট-টু-স্পিচ ব্যবহার করবে।',
              },
              {
                mode: 'offline_voice' as VoiceMode,
                label: 'Offline বাংলা Voice (বিল্ট-ইন অডিও)',
                desc: 'ইন্টারনেট ও ডিভাইস TTS ছাড়া ১০০% অফলাইনে প্রাক-রেকর্ডকৃত বাংলা কণ্ঠে ঘোষণা।',
              },
            ].map((item) => {
              const isSelected = settings.voiceMode === item.mode;
              return (
                <div
                  key={item.mode}
                  onClick={() => handleVoiceModeChange(item.mode)}
                  className={`p-3 rounded-xl border cursor-pointer transition flex items-start gap-3 ${
                    isSelected
                      ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-400/80 dark:border-blue-600/70 shadow-2xs'
                      : 'bg-zinc-50/70 dark:bg-zinc-800/40 border-zinc-200/80 dark:border-zinc-700/60 hover:border-zinc-300 dark:hover:border-zinc-600'
                  }`}
                >
                  <input
                    type="radio"
                    name="voiceModeRadio"
                    checked={isSelected}
                    onChange={() => handleVoiceModeChange(item.mode)}
                    className="mt-0.5 w-4 h-4 accent-blue-600 cursor-pointer"
                  />
                  <div className="space-y-0.5">
                    <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                      {item.label}
                    </div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-normal">
                      {item.desc}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real-time Voice Diagnostics Bar */}
        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-700/60 text-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-zinc-500 dark:text-zinc-400">বর্তমান সক্রিয় ইঞ্জিন:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              {voice.activeTier === 'native_bridge'
                ? 'Android Native Bridge'
                : voice.activeTier === 'device_tts'
                ? `Android TTS (${voice.bengaliVoiceName || 'Bengali'})`
                : 'অফলাইন বাংলা অডিও (Bundled)'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-zinc-500 dark:text-zinc-400">অফলাইন সাউন্ড ফাইলস:</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">
              ১০১টি অডিও (০-১০০ সংখ্যা ও ইভেন্ট প্রস্তুত)
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-zinc-500 dark:text-zinc-400">ইন্টারনেট নির্ভরতা:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              সম্পূর্ণ অফলাইন (No Internet Required)
            </span>
          </div>
        </div>

        {/* Active Custom Voice Message Preview */}
        {activeCustomVoice && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>সংরক্ষিত কাস্টম ভয়েস মেসেজ সক্রিয়:</span>
            </div>
            <p className="text-xs text-emerald-700 dark:text-emerald-400 italic">
              "{activeCustomVoice}"
            </p>
            <p className="text-[10px] text-emerald-600/80 dark:text-emerald-500">
              * অ্যালার্ট ও ১০/১৫ মিনিট রিমাইন্ডারের সময় এই কাস্টম বার্তাটিই প্রাধান্য পাবে।
            </p>
          </div>
        )}

        {/* Action Buttons: Test Voice and Test Reminder */}
        <div className="space-y-2 pt-1">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleTestVoiceWithCustom}
              disabled={voice.isSpeaking}
              className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition disabled:opacity-50"
            >
              <Mic className="w-4 h-4" />
              <span>{voice.isSpeaking ? 'কথা বলছে...' : 'ভয়েস টেস্ট (Test Voice)'}</span>
            </button>

            <button
              onClick={handleTestReminder}
              disabled={reminderTesting}
              className="py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition disabled:opacity-50"
            >
              <BellRing className="w-4 h-4" />
              <span>{reminderTesting ? 'টেস্টিং...' : 'রিমাইন্ডার টেস্ট (Test)'}</span>
            </button>
          </div>

          {voice.isSpeaking && (
            <button
              onClick={() => voice.stopVoice()}
              className="w-full py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition"
            >
              <VolumeX className="w-4 h-4" />
              <span>কথা বলা থামান (Stop Voice)</span>
            </button>
          )}
        </div>
      </div>

      {/* 3. Dedicated Repeating Reminder Configuration (১০/১৫ মিনিট রিমাইন্ডার) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                ধারাবাহিক চার্জিং রিমাইন্ডার (Repeating Reminder)
              </h3>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                চার্জ চলাকালীন ব্যাকগ্রাউন্ড ও লকস্ক্রিনে নির্দিষ্ট সময় পরপর মনে করিয়ে দেবে
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.repeatReminderEnabled}
              onChange={(e) => onUpdateSettings({ repeatReminderEnabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {settings.repeatReminderEnabled && (
          <div className="space-y-3 pt-1">
            <div className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              রিমাইন্ডারের বিরতি নির্বাচন করুন:
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[5, 10, 15, 30].map((mins) => {
                const isSelected = settings.reminderIntervalMinutes === mins;
                return (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => onUpdateSettings({ reminderIntervalMinutes: mins })}
                    className={`py-2 px-1.5 rounded-xl text-xs font-semibold border flex flex-col items-center justify-center transition ${
                      isSelected
                        ? 'bg-amber-500 border-amber-500 text-white shadow-xs'
                        : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-amber-400'
                    }`}
                  >
                    <span>{toBn(mins)} মিনিট</span>
                    {mins === 10 && <span className="text-[9px] opacity-80">(স্ট্যান্ডার্ড)</span>}
                    {mins === 15 && <span className="text-[9px] opacity-80">(প্রস্তাবিত)</span>}
                  </button>
                );
              })}
            </div>

            <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/60 dark:border-zinc-700/60 text-[11px] text-zinc-600 dark:text-zinc-400 flex items-start gap-2">
              <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <span>
                চার্জার সংযুক্ত হওয়া মাত্র রিমাইন্ডার সক্রিয় হবে এবং প্রতি <strong>{toBn(settings.reminderIntervalMinutes || 10)} মিনিট</strong> পর পর আপনার কাস্টম ভয়েস বার্তাটি পড়ে শোনাবে। চার্জার খুলে নিলে রিমাইন্ডার স্বয়ংক্রিয়ভাবে বন্ধ হবে।
              </span>
            </div>
          </div>
        )}
      </div>

      {/* 4. Android Battery Optimization Guidance (Section 9) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                  ব্যাটারি অপটিমাইজেশন (Unrestricted Mode)
                </h3>
                {isBatteryOptimizationIgnored !== null && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isBatteryOptimizationIgnored
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                    }`}
                  >
                    {isBatteryOptimizationIgnored ? 'Unrestricted (সীমাহীন)' : 'Optimized (সীমাবদ্ধ)'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                Samsung, Xiaomi, Vivo ও Oppo ফোনে ব্যাকগ্রাউন্ড সার্ভিস সচল রাখার নির্দেশিকা
              </p>
            </div>
          </div>
        </div>

        <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
          Android ফোনের পাওয়ার সেভিং বা ব্যাটারি অপটিমাইজেশনের কারণে লকস্ক্রিনে ব্যাকগ্রাউন্ড রিমাইন্ডার বন্ধ হতে পারে। নিরবচ্ছিন্ন ভয়েসের জন্য অ্যাপটির ব্যাকগ্রাউন্ড ব্যবহারকে <strong>Unrestricted (সীমাহীন)</strong> মোডে রাখুন।
        </p>

        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={handleOpenBatterySettings}
            className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition"
          >
            <Zap className="w-4 h-4" />
            <span>ব্যাটারি অপটিমাইজেশন (Unrestricted Mode)</span>
          </button>

          <button
            onClick={() => setShowBatteryGuide(!showBatteryGuide)}
            className="py-2.5 px-3 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold transition"
          >
            {showBatteryGuide ? 'নির্দেশিকা লুকান' : 'নিয়ম দেখুন'}
          </button>
        </div>

        {/* Force stop disclaimer note */}
        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 text-[11px] text-zinc-600 dark:text-zinc-400 leading-relaxed border border-zinc-200/60 dark:border-zinc-700/60">
          💡 <strong>জরুরি তথ্য:</strong> হোম বাটন প্রেস করে বের হলে বা রিসেন্ট অ্যাপস থেকে সরালেও ব্যাকগ্রাউন্ড সার্ভিস সক্রিয় থাকবে। তবে Android-এর <em>Settings → Apps → Force Stop</em> করলে সিস্টেম সমস্ত ব্যাকগ্রাউন্ড প্রসেস সম্পূর্ণ বন্ধ করে দেয়, সেক্ষেত্রে পুনরায় অ্যাপ চালু করতে হবে।
        </div>

        {showBatteryGuide && (
          <div className="pt-2 space-y-2 border-t border-zinc-100 dark:border-zinc-800 text-xs">
            <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/60 space-y-1">
              <span className="font-bold text-zinc-900 dark:text-zinc-100">📱 Samsung (One UI):</span>
              <p className="text-zinc-600 dark:text-zinc-400">
                Settings → Apps → চার্জিং সহকারী → Battery → <strong>Unrestricted</strong> সিলেক্ট করুন।
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/60 space-y-1">
              <span className="font-bold text-zinc-900 dark:text-zinc-100">📱 Xiaomi / Redmi / POCO (MIUI / HyperOS):</span>
              <p className="text-zinc-600 dark:text-zinc-400">
                Settings → Apps → Manage Apps → চার্জিং সহকারী → <strong>Autostart</strong> চালু করুন এবং Battery Saver থেকে <strong>No restrictions</strong> নির্বাচন করুন।
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/60 space-y-1">
              <span className="font-bold text-zinc-900 dark:text-zinc-100">📱 Vivo / Oppo / Realme / OnePlus:</span>
              <p className="text-zinc-600 dark:text-zinc-400">
                App Info → Battery Usage → <strong>Allow background activity</strong> এবং <strong>Allow auto launch</strong> চালু রাখুন।
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/60 space-y-1">
              <span className="font-bold text-zinc-900 dark:text-zinc-100">📱 Google Pixel / Motorola / Stock Android:</span>
              <p className="text-zinc-600 dark:text-zinc-400">
                Settings → Apps → চার্জিং সহকারী → App battery usage → <strong>Unrestricted</strong> সিলেক্ট করুন।
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 4.1 Home Screen Widget Configuration */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                  হোম স্ক্রিন উইজেট (Home Widget)
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  সক্রিয়
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                ফোনের হোম স্ক্রিনে রিয়েল-টাইম ব্যাটারি শতকরা হার ও চার্জিং স্ট্যাটাস
              </p>
            </div>
          </div>
        </div>

        <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
          আপনার মোবাইলের হোম স্ক্রিনে সরাসরি <strong>চার্জিং সহকারী উইজেট</strong> যুক্ত করতে পারেন। উইজেটটি প্রতি মিনিটে ব্যাকগ্রাউন্ড সার্ভিস ও ব্যাটারি ম্যানেজারের সাথে অটো-সিঙ্ক হয় এবং স্ক্রিন অফ থাকলেও ভয়েস সংকেত পাঠাতে সক্ষম।
        </p>

        {widgetPinnedSuccess ? (
          <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-900 dark:text-emerald-100 flex items-center justify-center gap-2 text-xs font-semibold">
            <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>উইজেট অনুরোধ পাঠানো হয়েছে! হোম স্ক্রিনে চেক করুন।</span>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={handlePinWidget}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>হোম স্ক্রিনে পিন করুন</span>
            </button>
            <button
              type="button"
              onClick={() => setShowWidgetGuide(!showWidgetGuide)}
              className="py-2.5 px-3 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold transition flex items-center justify-center gap-1.5"
            >
              <Info className="w-3.5 h-3.5 text-zinc-500" />
              <span>{showWidgetGuide ? 'লুকান' : 'উইজেটের নিয়ম'}</span>
            </button>
          </div>
        )}

        {showWidgetGuide && (
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60 text-xs text-zinc-600 dark:text-zinc-400 space-y-1.5 leading-relaxed">
            <div className="font-semibold text-zinc-800 dark:text-zinc-200 text-xs">
              ম্যানুয়ালি উইজেট যোগ করার পদ্ধতি:
            </div>
            <p>১. আপনার ফোনের হোম স্ক্রিনে কোনো ফাঁকা স্থানে <strong>২-৩ সেকেন্ড চেপে ধরে রাখুন</strong>।</p>
            <p>২. নিচে <strong>'Widgets' (উইজেট)</strong> বাটন দেখা যাবে, সেখানে চাপুন।</p>
            <p>৩. তালিকা থেকে <strong>'চার্জিং সহকারী' (Charging Assistant)</strong> সিলেক্ট করুন।</p>
            <p>৪. টেনে এনে আপনার পছন্দসই খালি স্ক্রিন স্পেসে ছেড়ে দিন।</p>
          </div>
        )}
      </div>

      {/* 5. Granular Alert Channels Checklist (Section 8) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                প্রতিটি অ্যালার্টের চ্যানেল সেটিংস
              </h3>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                ভয়েস, সাউন্ড, ভাইব্রেশন ও নোটিফিকেশন কাস্টমাইজ করুন
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowChannelsSection(!showChannelsSection)}
            className="text-xs text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 font-medium px-2 py-1"
          >
            {showChannelsSection ? 'লুকান' : 'প্রদর্শন'}
          </button>
        </div>

        {showChannelsSection && (
          <div className="space-y-2.5 pt-1">
            {alertItems.map((item) => {
              const channelState = currentChannels[item.key] || {
                voice: true,
                sound: true,
                vibration: true,
                notification: true,
              };

              return (
                <div
                  key={item.key}
                  className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-700/60 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                        {item.title}
                      </div>
                      <div className="text-[10px] text-zinc-500 dark:text-zinc-400">
                        {item.description}
                      </div>
                    </div>
                  </div>

                  {/* 4 Checkbox Badges for this alert */}
                  <div className="grid grid-cols-4 gap-1.5 pt-1">
                    {[
                      { id: 'voice' as const, label: 'ভয়েস', icon: Mic, active: channelState.voice },
                      { id: 'sound' as const, label: 'সাউন্ড', icon: Volume2, active: channelState.sound },
                      { id: 'vibration' as const, label: 'কম্পন', icon: Vibrate, active: channelState.vibration },
                      { id: 'notification' as const, label: 'নোটিফিকেশন', icon: Bell, active: channelState.notification },
                    ].map((ch) => {
                      const Icon = ch.icon;
                      return (
                        <button
                          key={ch.id}
                          type="button"
                          onClick={() => handleChannelToggle(item.key, ch.id)}
                          className={`py-1.5 px-2 rounded-lg text-[11px] font-medium border flex items-center justify-center gap-1 transition ${
                            ch.active
                              ? 'bg-white dark:bg-zinc-700 border-zinc-300 dark:border-zinc-600 text-zinc-900 dark:text-zinc-100 shadow-2xs'
                              : 'bg-transparent border-dashed border-zinc-300/80 dark:border-zinc-700/80 text-zinc-400 dark:text-zinc-500 opacity-60'
                          }`}
                        >
                          <Icon className="w-3 h-3" />
                          <span>{ch.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Device & Battery Information (Section 12) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              ডিভাইস ও ব্যাটারি তথ্য (Device Info)
            </h3>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              হার্ডওয়্যার ও ওএস স্পেসিফিকেশন
            </p>
          </div>
        </div>

        <div className="space-y-1 text-xs">
          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Device Model</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">
              {deviceInfo.deviceModel || 'Android Phone / Web Client'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Android / OS Version</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">
              {deviceInfo.androidVersion || deviceInfo.os}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Battery Level</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400 font-mono">
              {toBn(batteryState.levelPercent)}%
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Battery Status</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">
              {batteryState.charging ? 'চার্জ হচ্ছে (Charging)' : 'ব্যাটারিতে চলছে (Discharging)'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Battery Temperature</span>
            <span className="text-zinc-500 dark:text-zinc-400">
              {batteryState.temperature !== null ? `${toBn(batteryState.temperature)}°C` : 'এই ডিভাইসে এই তথ্য পাওয়া যাচ্ছে না'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Battery Voltage</span>
            <span className="text-zinc-500 dark:text-zinc-400">
              {batteryState.voltage !== null ? `${toBn(batteryState.voltage)}V` : 'ডিভাইসে উপলব্ধ নয়'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Charging Type</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">
              {batteryState.charging ? 'AC অ্যাডাপ্টার / Type-C' : 'ডিসকানেক্টেড'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-zinc-800">
            <span className="text-zinc-500">Battery Technology</span>
            <span className="font-medium text-zinc-900 dark:text-zinc-100">
              লিথিয়াম-আয়ন (Li-Ion)
            </span>
          </div>

          <div className="flex items-center justify-between py-2">
            <span className="text-zinc-500">Battery Capacity</span>
            <span className="text-zinc-500 dark:text-zinc-400">
              {batteryState.capacityMah !== null ? `${toBn(batteryState.capacityMah)} mAh` : 'এই ডিভাইসে এই তথ্য পাওয়া যাচ্ছে না'}
            </span>
          </div>
        </div>

        <div className="mt-3 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60 text-[11px] text-zinc-600 dark:text-zinc-400 leading-relaxed flex items-start gap-2">
          <Info className="w-4 h-4 text-zinc-500 dark:text-zinc-400 flex-shrink-0 mt-0.5" />
          <span>
            প্রামাণিক তথ্য নীতি: অ্যান্ড্রয়েড ওয়েবভিউ বা স্ট্যান্ডার্ড ব্রাউজারে যেসব সেন্সর ডেটা (ভোল্টেজ, মিলিঅ্যাম্পিয়ার ইত্যাদি) প্রাইভেসি সীমাবদ্ধতার কারণে সরাসরি এক্সপোজড নয়, সেগুলোতে কোনো মিথ্যা ডেটা প্রদর্শন করা হয় না।
          </span>
        </div>
      </div>

      {/* 5. Android APK & PWA Builder Section (Section 21) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Package className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              Android APK ও PWA বিল্ডার
            </h3>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              শেয়ার লিংক ও PWABuilder দিয়ে সরাসরি APK তৈরি
            </p>
          </div>
        </div>

        {/* Icons status pill */}
        <div className="p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60 text-xs">
          <div className="flex items-center gap-1.5 font-medium text-emerald-600 dark:text-emerald-400 mb-1">
            <Check className="w-3.5 h-3.5" />
            <span>PWA Builder ও Android আইকন প্রস্তুত</span>
          </div>
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
            PWABuilder-এর প্রয়োজনীয় 512x512 PNG, 192x192 PNG, Maskable আইকন এবং iOS Apple Touch Icon যথাযথভাবে কনফিগার করা হয়েছে।
          </div>
        </div>

        {/* Share App URL Box */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
            অ্যাপ শেয়ার লিংক (Share URL):
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={shareAppUrl}
              className="flex-1 text-xs px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 font-mono select-all truncate"
            />
            <button
              onClick={handleCopyLink}
              title="লিংক কপি করুন"
              className="px-3 py-2 rounded-xl text-xs font-medium bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-white dark:text-zinc-900 transition flex items-center gap-1.5 flex-shrink-0"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'কপি হয়েছে' : 'কপি'}</span>
            </button>
          </div>
        </div>

        {/* PWA Builder Action Button */}
        <div className="pt-1">
          <a
            href={pwaBuilderUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition"
          >
            <ExternalLink className="w-4 h-4" />
            <span>PWA Builder-এ সরাসরি APK বানান</span>
          </a>
        </div>

        {/* Direct In-App Install Button if available */}
        {isInstallable && (
          <button
            onClick={install}
            className="w-full py-2 px-3 rounded-xl bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-medium flex items-center justify-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>এই ডিভাইসে সরাসরি অ্যাপ ইনস্টল করুন</span>
          </button>
        )}

        {/* 3 Step Guide */}
        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-700/60 text-[11px] text-zinc-600 dark:text-zinc-400 space-y-1.5 leading-relaxed">
          <div className="font-semibold text-zinc-800 dark:text-zinc-200 text-xs">
            PWABuilder দিয়ে যেভাবে APK পাবেন:
          </div>
          <div>১. উপরের সবুজ বাটনে ক্লিক করে PWABuilder ওপেন করুন (লিংকটি ইতোমধ্যে যুক্ত থাকবে)।</div>
          <div>২. পেজে <strong className="text-zinc-800 dark:text-zinc-200">"Package for Stores"</strong> বাটনে ট্যাপ করে <strong className="text-zinc-800 dark:text-zinc-200">Android</strong> নির্বাচন করুন।</div>
          <div>৩. <strong className="text-zinc-800 dark:text-zinc-200">"Generate Package"</strong> বাটনে ক্লিক করলেই আপনার ফোনের জন্য টেস্ট ও সাইন্ড APK এবং Play Store-এর জন্য AAB বান্ডিল ডাউনলোড হবে।</div>
        </div>
      </div>

      {/* 6. Reset & Danger Zone */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3">
        <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
          ডাটা ব্যবস্থাপনা ও রিসেট
        </h3>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setShowClearHistoryConfirm(true)}
            className="py-2 px-3 rounded-xl bg-zinc-100 hover:bg-rose-50 hover:text-rose-600 dark:bg-zinc-800 dark:hover:bg-rose-950/40 text-zinc-700 dark:text-zinc-300 text-xs font-medium flex items-center justify-center gap-1.5 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>হিস্ট্রি মুছুন</span>
          </button>

          <button
            onClick={() => setShowResetConfirm(true)}
            className="py-2 px-3 rounded-xl bg-zinc-100 hover:bg-amber-50 hover:text-amber-700 dark:bg-zinc-800 dark:hover:bg-amber-950/40 text-zinc-700 dark:text-zinc-300 text-xs font-medium flex items-center justify-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>রিসেট সেটিংস</span>
          </button>
        </div>

        {/* Clear History Confirmation */}
        {showClearHistoryConfirm && (
          <div className="p-3 rounded-xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 text-xs">
            <div className="font-semibold text-rose-800 dark:text-rose-200 mb-1">
              সব চার্জিং ইতিহাস মুছে ফেলতে চান?
            </div>
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => {
                  onClearHistory();
                  setShowClearHistoryConfirm(false);
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-medium shadow-xs"
              >
                হ্যাঁ, মুছুন
              </button>
              <button
                onClick={() => setShowClearHistoryConfirm(false)}
                className="px-3 py-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-medium"
              >
                বাতিল
              </button>
            </div>
          </div>
        )}

        {/* Reset Settings Confirmation */}
        {showResetConfirm && (
          <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-xs">
            <div className="font-semibold text-amber-800 dark:text-amber-200 mb-1">
              ডিফল্ট সেটিক্সে ফিরিয়ে নিতে চান?
            </div>
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => {
                  onResetSettings();
                  setShowResetConfirm(false);
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-medium shadow-xs"
              >
                হ্যাঁ, রিসেট করুন
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-medium"
              >
                বাতিল
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
