import React from 'react';
import { Zap, Wifi, WifiOff, Download, Moon, Sun, Monitor, AlertTriangle } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { AppSettings } from '../types';

interface HeaderProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onToggleService?: () => void;
  isOnline: boolean;
  testMode: boolean;
  onExitTestMode: () => void;
  onOpenDiagnostic: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  onToggleService,
  isOnline,
  testMode,
  onExitTestMode,
  onOpenDiagnostic,
}) => {
  const { isInstallable, install } = usePWAInstall();

  const cycleTheme = () => {
    if (settings.themeMode === 'system') onUpdateSettings({ themeMode: 'dark' });
    else if (settings.themeMode === 'dark') onUpdateSettings({ themeMode: 'light' });
    else onUpdateSettings({ themeMode: 'system' });
  };

  const isServiceOn = settings.serviceEnabled !== false;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-200/80 dark:border-zinc-800/80 bg-white/85 dark:bg-zinc-950/85 backdrop-blur-md px-4 py-3">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* App Title & Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-emerald-400 dark:text-emerald-600 flex items-center justify-center shadow-xs border border-zinc-800/20 dark:border-zinc-200/20">
            <Zap className="w-4 h-4 fill-current" />
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-tight text-zinc-900 dark:text-zinc-100 leading-tight">
              চার্জিং সহকারী
            </h1>
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 dark:text-zinc-400">
              {isOnline ? (
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                  <Wifi className="w-3 h-3" /> অনলাইন
                </span>
              ) : (
                <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                  <WifiOff className="w-3 h-3" /> অফলাইন মোড
                </span>
              )}
              <span>•</span>
              <span>Android Ready</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          {/* Master Service ON/OFF Button */}
          {onToggleService && (
            <button
              onClick={onToggleService}
              title={isServiceOn ? 'সহকারী বন্ধ করতে ট্যাপ করুন (Turn OFF)' : 'সহকারী চালু করতে ট্যাপ করুন (Turn ON)'}
              className={`px-2.5 py-1.5 text-xs rounded-xl font-semibold transition-all flex items-center gap-1.5 border shadow-xs ${
                isServiceOn
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/50'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800 hover:bg-rose-100 dark:hover:bg-rose-900/50'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${isServiceOn ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              <span>{isServiceOn ? 'অন (ON)' : 'অফ (OFF)'}</span>
            </button>
          )}

          {/* Test Mode Trigger */}
          <button
            onClick={onOpenDiagnostic}
            title="ডায়াগনস্টিক ও পরীক্ষা"
            className="px-2.5 py-1.5 text-xs rounded-xl font-medium bg-zinc-100 hover:bg-zinc-200/80 dark:bg-zinc-800/80 dark:hover:bg-zinc-700/80 text-zinc-700 dark:text-zinc-300 border border-zinc-200/60 dark:border-zinc-750 transition-colors flex items-center gap-1"
          >
            <span>টেস্ট</span>
          </button>

          {/* PWA Install Button */}
          {isInstallable && (
            <button
              onClick={install}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-white dark:text-zinc-900 shadow-xs transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ইন্সটল</span>
            </button>
          )}

          {/* Theme Mode Button */}
          <button
            onClick={cycleTheme}
            title={`থিম: ${settings.themeMode}`}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/80 transition-colors"
          >
            {settings.themeMode === 'dark' ? (
              <Moon className="w-4 h-4 text-emerald-400" />
            ) : settings.themeMode === 'light' ? (
              <Sun className="w-4 h-4 text-amber-500" />
            ) : (
              <Monitor className="w-4 h-4 text-zinc-500" />
            )}
          </button>
        </div>
      </div>

      {/* Test Mode Notification Strip */}
      {testMode && (
        <div className="mt-2 max-w-md mx-auto py-1 px-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-between text-xs text-amber-700 dark:text-amber-300">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
            <span>সিমুলেশন টেস্ট মোড চালু রয়েছে</span>
          </div>
          <button
            onClick={onExitTestMode}
            className="font-semibold underline hover:text-amber-800 dark:hover:text-amber-200"
          >
            রিয়েল সেন্সরে ফিরুন
          </button>
        </div>
      )}
    </header>
  );
};
