import React, { useState, useEffect, useRef } from 'react';
import {
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  MessageSquare,
  Mic,
  RotateCcw,
  Trash2,
  Play,
  Square,
  Copy,
  Check,
  Headphones,
  Usb,
  BatteryCharging,
  Info,
  Sliders,
  Globe,
  CheckCircle2
} from 'lucide-react';
import { BatteryState, AppSettings, ChatMessage, CustomVoiceItem } from '../types';
import { toBn, toBnPercent } from '../utils/bnUtils';
import { bengaliVoiceService } from '../services/bengaliVoiceService';
import {
  loadChatMessages,
  saveChatMessages,
  loadCustomVoiceHistory,
  saveCustomVoiceHistory
} from '../utils/storage';

interface ChatViewProps {
  batteryState: BatteryState;
  settings: AppSettings;
  onUpdateSettings?: (settings: Partial<AppSettings>) => void;
  onOpenDiagnostic?: () => void;
}

const DEFAULT_PRESET_PHRASES = [
  'আমার ফোনের চার্জ পূর্ণ হয়েছে, অনুগ্রহ করে চার্জার খুলে দিন।',
  'চার্জার সংযোগ করা হয়েছে। ফোনটি চার্জ হচ্ছে।',
  'ইউএসবি সংযোগ সফলভাবে সম্পন্ন হয়েছে।',
  'ইয়ারফোন সংযোগ করা হয়েছে। অডিও প্রস্তুত।',
  'সতর্কতা! ফোনের ব্যাটারির তাপমাত্রা অনেক বেশি।',
  'চার্জার খুলে ফেলা হয়েছে। ব্যাটারি চেক করুন।',
  'চার্জিং সহকারী সক্রিয় আছে, আপনাকে ধন্যবাদ।',
];

const INITIAL_BOT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg_welcome',
    sender: 'assistant',
    textBn: 'স্বাগতম! আমি আপনার চার্জিং সহকারী বট। ব্যাটারির স্বাস্থ্য, চার্জিং টিপস, ইউএসবি বা ইয়ারফোন সম্পর্কিত যেকোনো প্রশ্ন বাংলায় বা ইংরেজিতে জিজ্ঞাসা করতে পারেন।',
    textEn: 'Welcome! I am your Charging Assistant Bot. You can ask any question about battery health, charging status, USB or earphone connection in Bengali or English.',
    timestamp: Date.now(),
  },
];

export const ChatView: React.FC<ChatViewProps> = ({
  batteryState,
  settings,
  onUpdateSettings,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'writer'>('writer');
  
  // Voice Writer (বাংলায় যা লিখা হবে তাই বলবে) state
  const [inputText, setInputText] = useState(
    settings.customPhrases?.customBengaliText || 'আমার ফোনের চার্জ পূর্ণ হয়েছে, চার্জার খুলে দিন।'
  );
  const [speechRate, setSpeechRate] = useState<number>(0.92);
  const [voiceEngine, setVoiceEngine] = useState<'cloud' | 'device'>('cloud');
  const [speakStatus, setSpeakStatus] = useState<'idle' | 'loading' | 'speaking' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [voiceHistory, setVoiceHistory] = useState<CustomVoiceItem[]>(() => {
    const saved = loadCustomVoiceHistory();
    if (saved.length > 0) return saved;
    return DEFAULT_PRESET_PHRASES.slice(0, 4).map((text, idx) => ({
      id: `preset_${idx}`,
      text,
      timestamp: Date.now() - idx * 60000,
    }));
  });

  // Bilingual Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = loadChatMessages();
    return saved.length > 0 ? saved : INITIAL_BOT_MESSAGES;
  });
  const [chatInput, setChatInput] = useState('');
  const [languagePreference, setLanguagePreference] = useState<'both' | 'bn' | 'en'>('both');
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Subscribe to voice service speaking status
  useEffect(() => {
    const unsubscribe = bengaliVoiceService.subscribe((info) => {
      setIsSpeaking(info.isSpeaking);
      if (!info.isSpeaking) {
        setSpeakingMessageId(null);
        setSpeakStatus((prev) => (prev === 'speaking' || prev === 'loading' ? 'idle' : prev));
      }
    });
    return () => unsubscribe();
  }, []);

  // Save history updates
  useEffect(() => {
    saveCustomVoiceHistory(voiceHistory);
  }, [voiceHistory]);

  useEffect(() => {
    saveChatMessages(chatMessages);
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // Handle Speak Custom Text
  const handleSpeakText = async (textToSpeak: string) => {
    bengaliVoiceService.unlock();
    if (isSpeaking) {
      handleStopSpeaking();
      return;
    }

    const trimmed = textToSpeak.trim();
    if (!trimmed) return;

    setErrorMessage(null);
    setSpeakStatus('loading');
    setIsSpeaking(true);

    // Add to history if not exists
    if (!voiceHistory.some((h) => h.text === trimmed)) {
      setVoiceHistory((prev) => [
        { id: `hist_${Date.now()}`, text: trimmed, timestamp: Date.now() },
        ...prev.slice(0, 25),
      ]);
    }

    // Automatically update customBengaliText in settings so system remembers user's sentence
    if (onUpdateSettings) {
      onUpdateSettings({
        customPhrases: {
          ...settings.customPhrases,
          useCustomPhrases: true,
          customBengaliText: trimmed,
        },
      });
    }

    try {
      const ok = await bengaliVoiceService.speakCustomText(trimmed, {
        rate: speechRate,
        forceDeviceTTS: voiceEngine === 'device',
        onStart: () => {
          setSpeakStatus('speaking');
          setIsSpeaking(true);
        },
        onEnd: () => {
          setIsSpeaking(false);
          setSpeakStatus('idle');
        },
        onError: (err) => {
          setIsSpeaking(false);
          setSpeakStatus('error');
          setErrorMessage(err || 'উচ্চারণ করা যায়নি। ব্রাউজার অডিও ভলিউম চেক করুন।');
        },
      });

      if (!ok) {
        setIsSpeaking(false);
        setSpeakStatus('error');
        setErrorMessage('উচ্চারণ করা যায়নি। অনুগ্রহ করে সাউন্ড অন আছে কিনা পরীক্ষা করুন।');
      }
    } catch (err: unknown) {
      setIsSpeaking(false);
      setSpeakStatus('error');
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(`ভুল হয়েছে: ${msg}`);
    }
  };

  const handleStopSpeaking = () => {
    bengaliVoiceService.stopCurrentVoice();
    setIsSpeaking(false);
    setSpeakStatus('idle');
    setSpeakingMessageId(null);
  };

  const handleSetAsAlert = (
    eventKey: 'target_reached' | 'charger_connected' | 'charger_removed' | 'battery_low'
  ) => {
    const trimmed = inputText.trim();
    if (!trimmed || !onUpdateSettings) return;

    onUpdateSettings({
      customPhrases: {
        ...settings.customPhrases,
        useCustomPhrases: true,
        [eventKey]: trimmed,
        customBengaliText: trimmed,
      },
    });

    const labels: Record<string, string> = {
      target_reached: 'ফুল চার্জ / টার্গেট',
      charger_connected: 'চার্জার সংযোগ',
      charger_removed: 'চার্জার বিচ্ছিন্ন',
      battery_low: 'লো ব্যাটারি',
    };

    setSaveSuccessMsg(`✓ "${labels[eventKey]}" অ্যালার্টে সংরক্ষিত!`);
    setTimeout(() => setSaveSuccessMsg(null), 3500);
  };

  const handleSpeakMessage = async (msg: ChatMessage, lang: 'bn' | 'en') => {
    bengaliVoiceService.unlock();
    if (speakingMessageId === `${msg.id}_${lang}`) {
      handleStopSpeaking();
      return;
    }

    handleStopSpeaking();
    setSpeakingMessageId(`${msg.id}_${lang}`);

    const textToSpeak = lang === 'bn' ? msg.textBn : msg.textEn;
    await bengaliVoiceService.speakCustomText(textToSpeak, {
      lang,
      rate: speechRate,
      onEnd: () => setSpeakingMessageId(null),
      onError: () => setSpeakingMessageId(null),
    });
  };

  // Generate intelligent bilingual battery response
  const generateAssistantResponse = (query: string): { textBn: string; textEn: string } => {
    const q = query.toLowerCase();
    const currentPct = batteryState.levelPercent;
    const isCharging = batteryState.charging;
    const temp = batteryState.temperature;

    if (q.includes('battery') || q.includes('ব্যাটারি') || q.includes('চার্জ') || q.includes('percentage') || q.includes('level') || q.includes('অবস্থা')) {
      return {
        textBn: `আপনার ফোনের বর্তমান ব্যাটারি চার্জ ${toBn(currentPct)}%। চার্জিং অবস্থা: ${
          isCharging ? '🔌 এখন চার্জ হচ্ছে' : '🔋 ব্যাটারিতে চলছে'
        }। ${temp ? `তাপমাত্রা: ${toBn(temp)}°C।` : ''} লক্ষ্যমাত্রা ${toBn(settings.targetBatteryLevel)}% এ পৌঁছালে অ্যালার্ট দেওয়া হবে।`,
        textEn: `Your current battery level is ${currentPct}%. Charging status: ${
          isCharging ? 'Plugged in and charging' : 'Running on battery'
        }. ${temp ? `Temperature: ${temp}°C.` : ''} You will be alerted when it reaches ${settings.targetBatteryLevel}%.`,
      };
    }

    if (q.includes('tip') || q.includes('টিপস') || q.includes('ভালো') || q.includes('life') || q.includes('স্বাস্থ্য') || q.includes('health')) {
      return {
        textBn: `ব্যাটারি দীর্ঘস্থায়ী রাখার সেরা ৩টি নিয়ম:\n১. চার্জ সবসময় ২০% থেকে ৮০% এর মধ্যে রাখুন।\n২. অতিরিক্ত গরম জায়গায় রেখে চার্জ করবেন না।\n৩. সারারাত চার্জে লাগানো রাখবেন না, ৮০-৮৫% হলে খুলে নিন।`,
        textEn: `Top 3 rules to maximize battery lifespan:\n1. Keep charge between 20% and 80% (the 20-80 golden rule).\n2. Avoid charging in hot environments (>40°C).\n3. Do not leave your phone plugged in overnight; unplug at 80-85%.`,
      };
    }

    if (q.includes('usb') || q.includes('ইউএসবি')) {
      return {
        textBn: `চার্জিং সহকারী নতুন USB ডিভাইস কানেক্ট অথবা ডিসকানেক্ট হলে তাৎক্ষণিক বাংলায় ভয়েস ও শব্দ সতর্কবার্তা দেয়। আপনার USB ডিটেকশন সেটিংস: ${
          settings.usbDetectionEnabled ? 'চালু আছে' : 'বন্ধ আছে'
        }।`,
        textEn: `The Charging Assistant automatically speaks and sounds an alert whenever a USB device is plugged in or unplugged. Your USB detection setting is currently: ${
          settings.usbDetectionEnabled ? 'Enabled' : 'Disabled'
        }.`,
      };
    }

    if (q.includes('earphone') || q.includes('headphone') || q.includes('ইয়ারফোন') || q.includes('হেডফোন')) {
      return {
        textBn: `ইয়ারফোন বা হেডফোন (3.5mm জ্যাক, Type-C অথবা ব্লুটুথ) প্লাগ ইন করলে বলবে: "ইয়ারফোন সংযোগ করা হয়েছে" এবং খুলে নিলে বলবে: "ইয়ারফোন বিচ্ছিন্ন করা হয়েছে"।`,
        textEn: `When earphones or headphones are connected, the assistant announces "ইয়ারফোন সংযোগ করা হয়েছে", and when unplugged, it alerts "ইয়ারফোন বিচ্ছিন্ন করা হয়েছে".`,
      };
    }

    if (q.includes('temperature') || q.includes('গরম') || q.includes('তাপমাত্রা') || q.includes('hot')) {
      return {
        textBn: `ব্যাটারির জন্য ৩৫°C থেকে ৪০°C স্বাভাবিক। ৪২°C এর বেশি তাপমাত্রা ব্যাটারির স্থায়িত্ব হ্রাস করে। তাপমাত্রা ৪২°C এর উপরে গেলে চার্জিং সহকারী দ্রুত সতর্ক করে।`,
        textEn: `Normal battery operating temperature is 35°C to 40°C. Exceeding 42°C can degrade lithium-ion cells prematurely. The assistant alerts you if temperature crosses 42°C.`,
      };
    }

    if (q.includes('off') || q.includes('on') || q.includes('বন্ধ') || q.includes('চালু')) {
      return {
        textBn: `অ্যাপের ওপরে থাকা 'অন/অফ' বাটন দিয়ে আপনি যেকোনো সময় পুরো চার্জিং সহকারীর সব ভয়েস ও সাউন্ড অ্যালার্ট বন্ধ বা চালু করতে পারেন।`,
        textEn: `You can toggle the Master ON/OFF button at the top header anytime to silence or resume all voice and sound alerts.`,
      };
    }

    // Generic helpful response
    return {
      textBn: `আমি আপনার চার্জিং সহকারী। আপনার ব্যাটারির চার্জ বর্তমানে ${toBn(currentPct)}%। আপনি ব্যাটারি স্বাস্থ্য, চার্জিং নিয়ম, ইউএসবি বা ইয়ারফোন সতর্কবার্তা সম্পর্কে জানতে চাইলে যে কোনো প্রশ্ন করতে পারেন।`,
      textEn: `I am your Charging Assistant. Your phone is at ${currentPct}% battery. Feel free to ask about battery optimization, charging etiquette, or USB/earphone voice alerts.`,
    };
  };

  // Handle Send Chat
  const handleSendChat = async (textToSend?: string) => {
    const raw = textToSend || chatInput;
    const trimmed = raw.trim();
    if (!trimmed) return;

    const userMessage: ChatMessage = {
      id: `user_${Date.now()}`,
      sender: 'user',
      textBn: trimmed,
      textEn: trimmed,
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setChatInput('');
    setIsAiLoading(true);

    let botResponse = generateAssistantResponse(trimmed);

    // Try server AI if available
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          batteryState: {
            levelPercent: batteryState.levelPercent,
            charging: batteryState.charging,
            temperature: batteryState.temperature,
          },
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.textBn && data?.textEn) {
          botResponse = { textBn: data.textBn, textEn: data.textEn };
        }
      }
    } catch {
      // Offline fallback used seamlessly
    } finally {
      setIsAiLoading(false);
    }

    const botMessage: ChatMessage = {
      id: `bot_${Date.now() + 1}`,
      sender: 'assistant',
      textBn: botResponse.textBn,
      textEn: botResponse.textEn,
      timestamp: Date.now() + 100,
    };

    setChatMessages((prev) => [...prev, botMessage]);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-4 pb-16">
      {/* Top Segmented Tab Switcher */}
      <div className="bg-zinc-200/80 dark:bg-zinc-900 p-1 rounded-2xl flex items-center shadow-xs border border-zinc-200/60 dark:border-zinc-800">
        <button
          onClick={() => setActiveSubTab('writer')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            activeSubTab === 'writer'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 shadow-xs'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5 text-emerald-500" />
          <span>ভয়েস স্পিকার (যা লিখবেন তাই বলবে)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('chat')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            activeSubTab === 'chat'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 shadow-xs'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5 text-blue-500" />
          <span>সহকারী চ্যাট (বাংলা ও English)</span>
        </button>
      </div>

      {/* SUBTAB 1: ভয়েস স্পিকার (বাংলায় যা লিখা হবে তাই বলবে) */}
      {activeSubTab === 'writer' && (
        <div className="space-y-4">
          {/* Main Input Card */}
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200/80 dark:border-zinc-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                    বাংলা ভয়েস রাইটার
                  </h2>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    এখানে যা লিখবেন, স্পষ্ট অফলাইন/অনলাইন বাংলা ভয়েসে উচ্চারণ করবে
                  </p>
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-1">
                {isSpeaking ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span>{speakStatus === 'loading' ? 'অডিও তৈরি হচ্ছে...' : 'উচ্চস্বরে বলছে...'}</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                    প্রস্তুত
                  </span>
                )}
              </div>
            </div>

            {/* Voice Engine Mode Switcher */}
            <div className="flex items-center justify-between p-1.5 rounded-xl bg-zinc-100/70 dark:bg-zinc-800/50 text-[11px]">
              <span className="text-zinc-500 dark:text-zinc-400 font-medium pl-1">ভয়েস ইঞ্জিন:</span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setVoiceEngine('cloud')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition ${
                    voiceEngine === 'cloud'
                      ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                      : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200/60 dark:hover:bg-zinc-700/60'
                  }`}
                  title="যেকোনো বাংলা বাক্যের জন্য ১০০% নির্ভরযোগ্য ও স্পষ্ট উচ্চারণ"
                >
                  🌐 স্পষ্ট অনলাইন ভয়েস (প্রস্তাবিত)
                </button>
                <button
                  type="button"
                  onClick={() => setVoiceEngine('device')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition ${
                    voiceEngine === 'device'
                      ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 shadow-xs font-semibold'
                      : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200/60 dark:hover:bg-zinc-700/60'
                  }`}
                  title="ডিভাইসের নিজস্ব অফলাইন TTS স্পিচ ইঞ্জিন"
                >
                  📱 ডিভাইস TTS
                </button>
              </div>
            </div>

            {/* Textarea */}
            <div className="relative">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="এখানে বাংলায় যা লিখবেন তাই বলবে... যেমন: 'আমার ফোন এখন চার্জে আছে, ফুল চার্জ হলে খুলে দিন।'"
                rows={3}
                className="w-full rounded-xl p-3 text-sm bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-750 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40 transition resize-none"
              />
              <div className="flex items-center justify-between text-[11px] text-zinc-400 px-1">
                <span>{toBn(inputText.length)} অক্ষর</span>
                {inputText.length > 0 && (
                  <button
                    onClick={() => setInputText('')}
                    className="hover:text-rose-500 transition-colors"
                  >
                    মুছুন
                  </button>
                )}
              </div>
            </div>

            {/* Speaking Live Pulse Animation */}
            {isSpeaking && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-400">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 h-3">
                    <span className="w-1 h-3 bg-emerald-500 rounded-full animate-bounce" />
                    <span className="w-1 h-3 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1 h-3 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                  <span className="font-semibold">বাংলায় উচ্চারণ চলছে...</span>
                </div>
                <button
                  type="button"
                  onClick={handleStopSpeaking}
                  className="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-medium hover:bg-emerald-700 transition"
                >
                  থামুন
                </button>
              </div>
            )}

            {/* Error Banner with helpful troubleshooting */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-xs text-rose-700 dark:text-rose-300 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold flex items-center gap-1.5">
                    ⚠️ {errorMessage}
                  </span>
                  <button
                    onClick={() => setErrorMessage(null)}
                    className="text-zinc-400 hover:text-zinc-600 text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-[11px] text-rose-600/90 dark:text-rose-400/90">
                  পরামর্শ: ফোনের মিডিয়া ভলিউম বাড়ান, মিউট অফ করুন এবং ইন্টারনেট সংযোগ সচল রাখুন।
                </p>
                <div className="pt-1 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleSpeakText(inputText)}
                    className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-semibold hover:bg-rose-700 transition"
                  >
                    পুনরায় চেষ্টা করুন
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setVoiceEngine('cloud');
                      setErrorMessage(null);
                      handleSpeakText(inputText);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-[11px] font-medium hover:bg-zinc-300 transition"
                  >
                    স্পষ্ট অনলাইন মোডে বলুন
                  </button>
                </div>
              </div>
            )}

            {/* Speed selection */}
            <div className="flex items-center justify-between pt-1 border-t border-zinc-100 dark:border-zinc-800/80">
              <div className="flex items-center gap-1 text-xs text-zinc-500">
                <Sliders className="w-3.5 h-3.5" />
                <span>গতি:</span>
              </div>
              <div className="flex items-center gap-1">
                {[
                  { label: 'ধীর (০.৮x)', val: 0.8 },
                  { label: 'স্বাভাবিক (১.০x)', val: 0.95 },
                  { label: 'দ্রুত (১.২x)', val: 1.2 },
                ].map((s) => (
                  <button
                    key={s.val}
                    onClick={() => setSpeechRate(s.val)}
                    className={`px-2 py-0.5 rounded-lg text-[11px] font-medium transition ${
                      speechRate === s.val
                        ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 font-semibold'
                        : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-750'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => handleSpeakText(inputText)}
                disabled={!inputText.trim()}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-xs ${
                  isSpeaking
                    ? 'bg-amber-600 hover:bg-amber-700 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white'
                }`}
              >
                {isSpeaking ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span>⏹️ কথা বলা থামান</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    <span>🗣️ বাংলায় বলুন (Speak Now)</span>
                  </>
                )}
              </button>

              {isSpeaking && (
                <button
                  onClick={handleStopSpeaking}
                  className="py-2.5 px-3 rounded-xl text-xs font-semibold bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-750 text-zinc-700 dark:text-zinc-300 transition"
                  title="থামুন"
                >
                  <VolumeX className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Set written text as Alert Voice */}
            <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span>এই লিখিত বাক্যটি ব্যাটারি অ্যালার্টে সেট করুন:</span>
                </span>
                {saveSuccessMsg && (
                  <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                    {saveSuccessMsg}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleSetAsAlert('target_reached')}
                  disabled={!inputText.trim()}
                  className="py-1.5 px-2 rounded-xl text-[11px] font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition flex items-center justify-center gap-1 disabled:opacity-50"
                  title="ফুল চার্জ বা নির্দিষ্ট লক্ষ্যমাত্রায় পৌঁছালে এই বাক্যটি বলবে"
                >
                  <span>🔋 ফুল চার্জ / টার্গেটে</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSetAsAlert('charger_connected')}
                  disabled={!inputText.trim()}
                  className="py-1.5 px-2 rounded-xl text-[11px] font-medium bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/60 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition flex items-center justify-center gap-1 disabled:opacity-50"
                  title="চার্জার লাগানোর সাথে সাথে এই বাক্যটি বলবে"
                >
                  <span>🔌 চার্জার কানেক্টে</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSetAsAlert('charger_removed')}
                  disabled={!inputText.trim()}
                  className="py-1.5 px-2 rounded-xl text-[11px] font-medium bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-200 dark:hover:bg-zinc-750 transition flex items-center justify-center gap-1 disabled:opacity-50"
                  title="চার্জার খুলে ফেলার সাথে সাথে এই বাক্যটি বলবে"
                >
                  <span>⚡ চার্জার খুললে</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSetAsAlert('battery_low')}
                  disabled={!inputText.trim()}
                  className="py-1.5 px-2 rounded-xl text-[11px] font-medium bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60 hover:bg-rose-100 dark:hover:bg-rose-900/50 transition flex items-center justify-center gap-1 disabled:opacity-50"
                  title="ব্যাটারি ২০% এর নিচে নামলে এই বাক্যটি বলবে"
                >
                  <span>🪫 লো ব্যাটারিতে</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Preset Chips */}
          <div className="space-y-1.5">
            <h3 className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 px-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>জনপ্রিয় রেডিমেড বাক্য (ট্যাপ করলেই বলবে):</span>
            </h3>
            <div className="grid grid-cols-1 gap-1.5">
              {DEFAULT_PRESET_PHRASES.map((phrase, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setInputText(phrase);
                    handleSpeakText(phrase);
                  }}
                  className="w-full text-left p-2.5 rounded-xl text-xs bg-white dark:bg-zinc-900 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 border border-zinc-200/80 dark:border-zinc-800 text-zinc-800 dark:text-zinc-200 transition-all flex items-center justify-between group"
                >
                  <span className="line-clamp-1 group-hover:text-emerald-700 dark:group-hover:text-emerald-400">
                    {phrase}
                  </span>
                  <Volume2 className="w-3.5 h-3.5 text-zinc-400 group-hover:text-emerald-500 shrink-0 ml-2" />
                </button>
              ))}
            </div>
          </div>

          {/* Spoken History */}
          {voiceHistory.length > 0 && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                  সাম্প্রতিক উচ্চারিত বাক্য
                </span>
                <button
                  onClick={() => setVoiceHistory([])}
                  className="text-[11px] text-zinc-400 hover:text-rose-500 flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" /> হিস্ট্রি মুছুন
                </button>
              </div>

              <div className="space-y-1.5">
                {voiceHistory.slice(0, 5).map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-xl bg-white/70 dark:bg-zinc-900/70 border border-zinc-200/60 dark:border-zinc-800 flex items-center justify-between gap-2"
                  >
                    <span className="text-xs text-zinc-700 dark:text-zinc-300 line-clamp-1 flex-1">
                      {item.text}
                    </span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleSpeakText(item.text)}
                        title="পুনরায় শুনুন"
                        className="p-1 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 transition"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleCopy(item.text, item.id)}
                        title="কপি করুন"
                        className="p-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: দ্বিভাষিক সহকারী চ্যাট (বাংলা ও English) */}
      {activeSubTab === 'chat' && (
        <div className="space-y-3">
          {/* Top Language & Help Bar */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1 text-xs text-zinc-500">
              <Globe className="w-3.5 h-3.5 text-blue-500" />
              <span>ভাষা প্রদর্শন:</span>
            </div>
            <div className="flex items-center gap-1">
              {[
                { id: 'both' as const, label: 'উভয় (Both)' },
                { id: 'bn' as const, label: 'বাংলা' },
                { id: 'en' as const, label: 'English' },
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => setLanguagePreference(lang.id)}
                  className={`px-2 py-0.5 rounded-lg text-[11px] font-medium transition ${
                    languagePreference === lang.id
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-750'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Messages Container */}
          <div className="bg-white dark:bg-zinc-900 rounded-2xl p-3 border border-zinc-200/80 dark:border-zinc-800 shadow-xs min-h-[280px] max-h-[420px] overflow-y-auto space-y-3">
            {chatMessages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                      isUser
                        ? 'bg-emerald-600 text-white rounded-tr-xs shadow-xs'
                        : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-tl-xs border border-zinc-200/60 dark:border-zinc-750'
                    }`}
                  >
                    {isUser ? (
                      <div>{msg.textBn}</div>
                    ) : (
                      <div className="space-y-2">
                        {/* Bengali Response */}
                        {(languagePreference === 'both' || languagePreference === 'bn') && (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between gap-2 border-b border-zinc-200/60 dark:border-zinc-700/60 pb-1">
                              <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                                বাংলা (Bengali)
                              </span>
                              <button
                                onClick={() => handleSpeakMessage(msg, 'bn')}
                                className={`flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded-md transition ${
                                  speakingMessageId === `${msg.id}_bn`
                                    ? 'bg-emerald-500 text-white animate-pulse'
                                    : 'bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300'
                                }`}
                              >
                                <Volume2 className="w-3 h-3" />
                                <span>{speakingMessageId === `${msg.id}_bn` ? 'থামুন' : 'শুনুন'}</span>
                              </button>
                            </div>
                            <p className="whitespace-pre-line text-zinc-800 dark:text-zinc-200">{msg.textBn}</p>
                          </div>
                        )}

                        {/* English Response */}
                        {(languagePreference === 'both' || languagePreference === 'en') && (
                          <div className="space-y-1 pt-1">
                            <div className="flex items-center justify-between gap-2 border-b border-zinc-200/60 dark:border-zinc-700/60 pb-1">
                              <span className="text-[10px] font-semibold text-blue-600 dark:text-blue-400">
                                English
                              </span>
                              <button
                                onClick={() => handleSpeakMessage(msg, 'en')}
                                className={`flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded-md transition ${
                                  speakingMessageId === `${msg.id}_en`
                                    ? 'bg-blue-500 text-white animate-pulse'
                                    : 'bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300'
                                }`}
                              >
                                <Volume2 className="w-3 h-3" />
                                <span>{speakingMessageId === `${msg.id}_en` ? 'Stop' : 'Listen'}</span>
                              </button>
                            </div>
                            <p className="whitespace-pre-line text-zinc-700 dark:text-zinc-300 font-sans">{msg.textEn}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            {isAiLoading && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 text-xs text-zinc-500 w-fit">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
                <span>সহকারী উত্তর লিখছে... (Thinking...)</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Quick Suggested Questions */}
          <div className="space-y-1">
            <span className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400 px-1">
              প্রশ্ন করার সহজ নমুনা:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {[
                { bn: '🔋 বর্তমান ব্যাটারি অবস্থা কী?', en: 'Battery status' },
                { bn: '⚡ ব্যাটারি ভালো রাখার টিপস', en: 'Battery tips' },
                { bn: '🔌 ইউএসবি সংযোগ তথ্য', en: 'USB status' },
                { bn: '🎧 ইয়ারফোন এলার্ট কীভাবে কাজ করে?', en: 'Earphone alert' },
                { bn: '🌡️ ব্যাটারির আদর্শ তাপমাত্রা কত?', en: 'Optimal temp' },
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendChat(chip.bn)}
                  className="px-2.5 py-1 rounded-xl text-[11px] bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 shrink-0 transition"
                >
                  {chip.bn}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendChat();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="বাংলা বা ইংরেজিতে লিখুন... (e.g. Battery health)"
              className="flex-1 py-2.5 px-3.5 rounded-xl text-xs bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/40"
            />
            <button
              type="submit"
              disabled={!chatInput.trim()}
              className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-medium shadow-xs transition"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
