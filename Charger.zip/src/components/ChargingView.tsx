import React, { useState } from 'react';
import { Zap, Clock, Moon, Bell, Sparkles, Check, Sliders, Info, ShieldAlert, ArrowRight } from 'lucide-react';
import { BatteryState, AppSettings } from '../types';
import { toBn, formatBnDuration } from '../utils/bnUtils';

interface ChargingViewProps {
  batteryState: BatteryState;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  reminderActive: boolean;
  onStopReminder: () => void;
}

export const ChargingView: React.FC<ChargingViewProps> = ({
  batteryState,
  settings,
  onUpdateSettings,
  reminderActive,
  onStopReminder,
}) => {
  // Calculator state
  const [calcCurrent, setCalcCurrent] = useState<number>(batteryState.levelPercent);
  const [calcTarget, setCalcTarget] = useState<number>(settings.targetBatteryLevel || 85);
  const [chargerPreset, setChargerPreset] = useState<number>(18); // 10W, 18W, 33W, 65W

  // Custom Target State
  const targetOptions = [80, 85, 90, 95, 100];
  const intervalOptions = [5, 10, 15, 30];

  // Calculate estimated charging time
  const calculateEstimate = () => {
    if (calcTarget <= calcCurrent) {
      return 0;
    }
    const diffPct = calcTarget - calcCurrent;
    // Standard estimation based on typical smartphone ~4500mAh-5000mAh battery:
    // 10W: ~1.5 mins per %
    // 18W: ~1.0 mins per %
    // 33W: ~0.65 mins per %
    // 65W+: ~0.4 mins per %
    let minsPerPercent = 1.0;
    if (chargerPreset === 10) minsPerPercent = 1.6;
    else if (chargerPreset === 18) minsPerPercent = 1.1;
    else if (chargerPreset === 33) minsPerPercent = 0.7;
    else if (chargerPreset >= 65) minsPerPercent = 0.45;

    // Slow down in last 10% (trickle charging)
    const extraTrickle = calcTarget > 80 ? 8 : 0;
    const totalMinutes = Math.round(diffPct * minsPerPercent + extraTrickle);
    return totalMinutes * 60; // seconds
  };

  const estimatedSeconds = calculateEstimate();

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Target Battery Level Selection (Section 3) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                টার্গেট ব্যাটারি লেভেল অ্যালার্ট
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                নির্দিষ্ট চার্জে পৌঁছালে অ্যালার্ট ও নোটিফিকেশন বাজবে
              </p>
            </div>
          </div>
        </div>

        {/* Target Buttons */}
        <div className="grid grid-cols-5 gap-2 mt-3">
          {targetOptions.map((lvl) => {
            const isSelected = settings.targetBatteryLevel === lvl;
            return (
              <button
                key={lvl}
                onClick={() => onUpdateSettings({ targetBatteryLevel: lvl })}
                className={`py-2 rounded-xl text-xs font-semibold transition flex flex-col items-center justify-center border ${
                  isSelected
                    ? 'bg-zinc-900 border-zinc-900 text-white dark:bg-zinc-100 dark:border-zinc-100 dark:text-zinc-900 shadow-xs'
                    : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-600'
                }`}
              >
                <span>{toBn(lvl)}%</span>
                {lvl === 85 && (
                  <span className={`text-[9px] font-normal ${isSelected ? 'text-zinc-300 dark:text-zinc-600' : 'text-emerald-600 dark:text-emerald-400'}`}>
                    সেরা
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Custom Target Slider */}
        <div className="mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-zinc-600 dark:text-zinc-400 font-medium">কাস্টম টার্গেট নির্ধারণ:</span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400 font-mono text-sm">
              {toBn(settings.customTargetLevel)}%
            </span>
          </div>
          <input
            type="range"
            min="50"
            max="100"
            step="1"
            value={settings.customTargetLevel}
            onChange={(e) => {
              const val = parseInt(e.target.value, 10);
              onUpdateSettings({ customTargetLevel: val, targetBatteryLevel: 0 });
            }}
            className="w-full accent-emerald-600 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg cursor-pointer"
          />
          {settings.targetBatteryLevel === 0 && (
            <div className="mt-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
              <Check className="w-3 h-3" /> কাস্টম লেভেল ({toBn(settings.customTargetLevel)}%) সক্রিয় রয়েছে
            </div>
          )}
        </div>
      </div>

      {/* 2. Repeated Charging Reminder (Section 4) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                পুনরাবৃত্তিমূলক রিমাইন্ডার
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                টার্গেট পার করার পর নির্দিষ্ট সময় পরপর স্মরণ করাবে
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.repeatReminderEnabled}
              onChange={(e) => onUpdateSettings({ repeatReminderEnabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {settings.repeatReminderEnabled && (
          <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800 space-y-2">
            <div className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              রিমাইন্ডার ব্যবধান (Interval):
            </div>
            <div className="grid grid-cols-4 gap-2">
              {intervalOptions.map((mins) => {
                const isSelected = settings.reminderIntervalMinutes === mins;
                return (
                  <button
                    key={mins}
                    onClick={() => onUpdateSettings({ reminderIntervalMinutes: mins })}
                    className={`py-1.5 rounded-xl text-xs font-medium transition border ${
                      isSelected
                        ? 'bg-zinc-900 border-zinc-900 text-white dark:bg-zinc-100 dark:border-zinc-100 dark:text-zinc-900 shadow-xs'
                        : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-600'
                    }`}
                  >
                    {toBn(mins)} মিনিট
                  </button>
                );
              })}
            </div>

            {reminderActive && (
              <div className="mt-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between">
                <span className="text-xs text-amber-800 dark:text-amber-300 font-medium">
                  বর্তমানে রিমাইন্ডার চলছে
                </span>
                <button
                  onClick={onStopReminder}
                  className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium"
                >
                  বন্ধ করুন
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. Charging Calculator (Section 9) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              চার্জিং সময় ক্যালকুলেটর
            </h2>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              বর্তমান থেকে টার্গেট লেভেলে পৌঁছাতে আনুমানিক সময়
            </p>
          </div>
        </div>

        {/* Inputs */}
        <div className="mt-4 space-y-3">
          {/* Current Level Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-zinc-600 dark:text-zinc-400 font-medium">বর্তমান চার্জ:</span>
              <span className="font-semibold text-zinc-900 dark:text-zinc-100 font-mono">
                {toBn(calcCurrent)}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={calcCurrent}
              onChange={(e) => setCalcCurrent(parseInt(e.target.value, 10))}
              className="w-full accent-zinc-800 dark:accent-zinc-200 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Target Level Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-zinc-600 dark:text-zinc-400 font-medium">টার্গেট চার্জ:</span>
              <span className="font-semibold text-emerald-600 dark:text-emerald-400 font-mono">
                {toBn(calcTarget)}%
              </span>
            </div>
            <input
              type="range"
              min={calcCurrent}
              max="100"
              value={calcTarget}
              onChange={(e) => setCalcTarget(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-600 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>

          {/* Charger Wattage Preset */}
          <div>
            <div className="text-xs text-zinc-600 dark:text-zinc-400 mb-1.5 font-medium">
              চার্জারের গতি / পাওয়ার প্রোফাইল:
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { watt: 10, label: '১০W স্লো' },
                { watt: 18, label: '১৮W ফাস্ট' },
                { watt: 33, label: '৩৩W টার্বো' },
                { watt: 65, label: '৬৫W+ সুপার' },
              ].map((p) => (
                <button
                  key={p.watt}
                  onClick={() => setChargerPreset(p.watt)}
                  className={`py-1.5 px-2 rounded-xl text-[11px] font-medium border transition ${
                    chargerPreset === p.watt
                      ? 'bg-zinc-900 border-zinc-900 text-white dark:bg-zinc-100 dark:border-zinc-100 dark:text-zinc-900 shadow-xs'
                      : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-600'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Estimation Result Box */}
          <div className="mt-4 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/70">
            <div className="flex items-center justify-between text-xs text-zinc-600 dark:text-zinc-400 font-medium mb-1">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" /> আনুমানিক প্রয়োজনীয় সময়
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-200/70 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-300">
                আনুমানিক (Estimated)
              </span>
            </div>

            <div className="text-2xl font-bold text-zinc-950 dark:text-zinc-50 font-sans mt-1">
              {formatBnDuration(estimatedSeconds)}
            </div>

            <div className="mt-2 text-[11px] text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
              <span>{toBn(calcCurrent)}%</span>
              <ArrowRight className="w-3 h-3" />
              <span>{toBn(calcTarget)}%</span>
              <span>(মোট বৃদ্ধি: +{toBn(Math.max(0, calcTarget - calcCurrent))}%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Night Charging Mode (Section 13) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                নাইট চার্জিং মোড (Night Mode)
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                রাতের বেলায় ব্যাটারি সুরক্ষিত রাখতে বিশেষ সতর্কতা
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.nightModeEnabled}
              onChange={(e) => onUpdateSettings({ nightModeEnabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {settings.nightModeEnabled && (
          <div className="mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800 space-y-3">
            <div>
              <div className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-2">
                রাতের টার্গেট লেভেল নির্বাচন:
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[80, 90, 100].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => onUpdateSettings({ nightTargetLevel: lvl })}
                    className={`py-1.5 rounded-xl text-xs font-medium border transition ${
                      settings.nightTargetLevel === lvl
                        ? 'bg-zinc-900 border-zinc-900 text-white dark:bg-zinc-100 dark:border-zinc-100 dark:text-zinc-900 shadow-xs'
                        : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-600'
                    }`}
                  >
                    {toBn(lvl)}%
                  </button>
                ))}
              </div>
            </div>

            {/* Clear, honest technical disclaimer as requested */}
            <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60 text-[11px] text-zinc-600 dark:text-zinc-400 leading-relaxed">
              <div className="font-semibold text-zinc-800 dark:text-zinc-200 mb-0.5 flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-zinc-600 dark:text-zinc-400" />
                হার্ডওয়্যার ক্ষমতা সংক্রান্ত নোট:
              </div>
              মোবাইল অ্যাপ্লিকেশন দিয়ে সরাসরি পাওয়ার কাট-অফ বা কারেন্ট বন্ধ করা সম্ভব নয়। এই মোডে লক্ষ্যমাত্রা পৌঁছালে সফটওয়্যার মিষ্টি সুর ও নোটিফিকেশনের মাধ্যমে আপনাকে চার্জার খুলে নিতে অনুরোধ করবে।
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
