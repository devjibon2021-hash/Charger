import React from 'react';
import { Home, Zap, MessageSquare, BarChart2, Bell, Settings } from 'lucide-react';

export type NavTab = 'home' | 'charging' | 'chat' | 'alerts' | 'stats' | 'settings';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unreadCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  unreadCount = 0,
}) => {
  const navItems = [
    { id: 'home' as NavTab, label: 'হোম', icon: Home },
    { id: 'charging' as NavTab, label: 'চার্জিং', icon: Zap },
    { id: 'chat' as NavTab, label: 'চ্যাট/ভয়েস', icon: MessageSquare },
    { id: 'alerts' as NavTab, label: 'সতর্কতা', icon: Bell, badge: unreadCount },
    { id: 'stats' as NavTab, label: 'স্ট্যাটস', icon: BarChart2 },
    { id: 'settings' as NavTab, label: 'সেটিংস', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-zinc-950/90 backdrop-blur-md border-t border-zinc-200/80 dark:border-zinc-800/80 px-1 py-1.5 pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-6 gap-0.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`min-h-[48px] flex flex-col items-center justify-center rounded-xl transition-all relative ${
                isActive
                  ? 'text-zinc-950 dark:text-zinc-50 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-700 dark:text-zinc-500 dark:hover:text-zinc-300 font-normal'
              }`}
            >
              <div className="relative">
                <Icon className={`w-4.5 h-4.5 transition-transform duration-150 ${isActive ? 'scale-110 stroke-[2.3]' : 'stroke-[1.7]'}`} />
                {item.badge && item.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 min-w-[14px] h-3 px-0.5 rounded-full bg-rose-600 text-[8px] font-bold text-white flex items-center justify-center">
                    {item.badge > 9 ? '৯+' : item.badge}
                  </span>
                ) : null}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-full px-0.5">{item.label}</span>
              {isActive && (
                <div className="w-1 h-1 bg-emerald-500 rounded-full mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
