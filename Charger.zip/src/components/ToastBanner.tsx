import React from 'react';
import { X, Bell, Zap, ZapOff, CheckCircle2, AlertTriangle, Mic } from 'lucide-react';

interface ToastBannerProps {
  message: { id: string; text: string; type: string } | null;
  onDismiss: () => void;
}

export const ToastBanner: React.FC<ToastBannerProps> = ({ message, onDismiss }) => {
  if (!message) return null;

  const getIcon = () => {
    switch (message.type) {
      case 'charger_connected':
        return <Zap className="w-4 h-4 text-emerald-500 fill-current" />;
      case 'charger_disconnected':
        return <ZapOff className="w-4 h-4 text-neutral-400" />;
      case 'target_reached':
        return <CheckCircle2 className="w-4 h-4 text-blue-500" />;
      case 'warning':
      case 'temperature_warning':
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'voice':
        return <Mic className="w-4 h-4 text-purple-500" />;
      default:
        return <Bell className="w-4 h-4 text-emerald-500" />;
    }
  };

  return (
    <div className="fixed top-16 left-0 right-0 z-50 px-4 pointer-events-none flex justify-center animate-in fade-in slide-in-from-top-4 duration-200">
      <div className="pointer-events-auto max-w-sm w-full bg-zinc-900/95 dark:bg-zinc-900/95 text-white backdrop-blur-md rounded-xl p-2.5 shadow-lg border border-zinc-700/60 flex items-center justify-between gap-2.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-zinc-800 flex items-center justify-center flex-shrink-0">
            {getIcon()}
          </div>
          <p className="text-xs font-medium leading-snug line-clamp-2 text-zinc-100">
            {message.text}
          </p>
        </div>
        <button
          onClick={onDismiss}
          className="p-1 rounded-md text-zinc-400 hover:text-white transition flex-shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
