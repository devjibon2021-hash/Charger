import React, { useState } from 'react';
import { BarChart2, Calendar, Clock, Battery, Trash2, Download, AlertTriangle, ArrowUpRight, Zap, CheckCircle } from 'lucide-react';
import { ChargingSession } from '../types';
import { toBn, toBnPercent, formatBnDateTime, formatBnDuration, formatBnTime } from '../utils/bnUtils';
import { deleteSession, clearSessions } from '../utils/storage';

interface StatisticsViewProps {
  sessions: ChargingSession[];
  onUpdateSessions: (sessions: ChargingSession[]) => void;
}

export const StatisticsView: React.FC<StatisticsViewProps> = ({
  sessions,
  onUpdateSessions,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Filter today and this week
  const now = Date.now();
  const oneDayAgo = now - 24 * 60 * 60 * 1000;
  const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;

  const todaySessions = sessions.filter((s) => s.timestamp >= oneDayAgo);
  const weekSessions = sessions.filter((s) => s.timestamp >= oneWeekAgo);

  // Compute Averages
  const totalSessionsCount = sessions.length;
  const avgDuration =
    totalSessionsCount > 0
      ? Math.round(sessions.reduce((acc, s) => acc + (s.durationSeconds || 0), 0) / totalSessionsCount)
      : 0;

  const avgStart =
    totalSessionsCount > 0
      ? Math.round(sessions.reduce((acc, s) => acc + (s.startLevel || 0), 0) / totalSessionsCount)
      : 0;

  const avgEnd =
    totalSessionsCount > 0
      ? Math.round(sessions.reduce((acc, s) => acc + (s.endLevel || 0), 0) / totalSessionsCount)
      : 0;

  // Handle Delete Single Session
  const handleDelete = (id: string) => {
    const updated = deleteSession(id);
    onUpdateSessions(updated);
  };

  // Handle Clear All
  const handleClearAll = () => {
    clearSessions();
    onUpdateSessions([]);
    setShowClearConfirm(false);
  };

  // Export JSON
  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(sessions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `charging_history_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Header & Summary Metrics (Section 8) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <BarChart2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                চার্জিং পরিসংখ্যান
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                ব্যবহার ও চার্জিং অভ্যাসের সামগ্রিক চিত্র
              </p>
            </div>
          </div>

          {sessions.length > 0 && (
            <button
              onClick={handleExport}
              title="হিস্ট্রি ডাউনলোড করুন"
              className="p-2 rounded-xl text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition"
            >
              <Download className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* 6 Key Metrics Grid */}
        <div className="grid grid-cols-2 gap-2">
          {/* Today */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              আজ চার্জ করা হয়েছে
            </div>
            <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100 mt-0.5">
              {toBn(todaySessions.length)} <span className="text-xs font-normal text-zinc-500">বার</span>
            </div>
          </div>

          {/* This Week */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              এই সপ্তাহে চার্জ
            </div>
            <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100 mt-0.5">
              {toBn(weekSessions.length)} <span className="text-xs font-normal text-zinc-500">বার</span>
            </div>
          </div>

          {/* Avg Duration */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              গড় সময়কাল
            </div>
            <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 mt-1">
              {totalSessionsCount > 0 ? formatBnDuration(avgDuration) : '০ মিনিট'}
            </div>
          </div>

          {/* Total Sessions */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              মোট সেশন
            </div>
            <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100 mt-0.5">
              {toBn(totalSessionsCount)} <span className="text-xs font-normal text-zinc-500">বার</span>
            </div>
          </div>

          {/* Avg Start Level */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              গড় শুরুর চার্জ
            </div>
            <div className="text-base font-semibold text-zinc-900 dark:text-zinc-100 mt-0.5 font-mono">
              {toBn(avgStart)}%
            </div>
          </div>

          {/* Avg End Level */}
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/70 dark:border-zinc-700/60">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
              গড় শেষ চার্জ
            </div>
            <div className="text-base font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5 font-mono">
              {toBn(avgEnd)}%
            </div>
          </div>
        </div>

        {/* Visual Trend Chart (Recent 7 Sessions) */}
        {sessions.length > 0 && (
          <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400 mb-2 font-medium">
              <span>সাম্প্রতিক সেশনসমূহের চার্জ বৃদ্ধি (+%)</span>
              <span>সর্বশেষ ৭টি সেশন</span>
            </div>
            <div className="h-24 flex items-end gap-2 pt-2 px-1">
              {sessions.slice(0, 7).reverse().map((s, idx) => {
                const diff = Math.max(5, s.endLevel - s.startLevel);
                const heightPct = Math.min(100, Math.round((diff / 100) * 100));
                return (
                  <div key={s.id || idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                    <div className="text-[9px] text-zinc-400 mb-1 font-mono">
                      +{toBn(diff)}%
                    </div>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full rounded-t bg-zinc-900 dark:bg-zinc-200 group-hover:opacity-80 transition-all"
                    />
                    <div className="text-[9px] text-zinc-400 mt-1 truncate max-w-full">
                      {toBn(idx + 1)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 2. Charging History (Section 7) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              চার্জিং ইতিহাস (History)
            </h3>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              সংরক্ষিত সেশন বিস্তারিত
            </p>
          </div>
          {sessions.length > 0 && (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="text-xs text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1 font-medium"
            >
              <Trash2 className="w-3.5 h-3.5" />
              সব মুছুন
            </button>
          )}
        </div>

        {/* Clear Confirmation Dialog */}
        {showClearConfirm && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 text-xs">
            <div className="flex items-center gap-2 text-rose-700 dark:text-rose-300 font-semibold mb-1">
              <AlertTriangle className="w-4 h-4" />
              আপনি কি নিশ্চিত সব ইতিহাস মুছে ফেলতে চান?
            </div>
            <p className="text-rose-600/90 dark:text-rose-400/90 text-[11px] mb-2.5">
              এই প্রক্রিয়াটি বাতিল করা যাবে না। আপনার লোকাল স্টোরেজ থেকে সব সেশন মুছে যাবে।
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-medium shadow-xs"
              >
                হ্যাঁ, মুছে ফেলুন
              </button>
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-medium"
              >
                বাতিল
              </button>
            </div>
          </div>
        )}

        {/* Sessions List */}
        {sessions.length === 0 ? (
          <div className="py-12 text-center text-zinc-400 dark:text-zinc-500">
            <Zap className="w-8 h-8 mx-auto mb-2 opacity-30 stroke-1" />
            <div className="text-xs font-semibold">কোনো চার্জিং সেশন সংরক্ষিত নেই</div>
            <div className="text-[11px] mt-1">চার্জার সংযোগ ও বিচ্ছিন্ন করলে স্বয়ংক্রিয়ভাবে হিস্ট্রি যোগ হবে।</div>
          </div>
        ) : (
          <div className="space-y-2">
            {sessions.map((s) => (
              <div
                key={s.id}
                className="p-3.5 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/50 relative group transition hover:border-zinc-300 dark:hover:border-zinc-600"
              >
                <div className="flex items-start justify-between">
                  <div>
                    {/* Date */}
                    <div className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      {formatBnDateTime(s.timestamp)}
                    </div>
                    {/* Time interval */}
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
                      {formatBnTime(s.timestamp)} → {s.endTime ? formatBnTime(s.endTime) : 'চলমান'}
                    </div>
                  </div>

                  <button
                    onClick={() => handleDelete(s.id)}
                    title="সেশন মুছুন"
                    className="p-1 text-zinc-400 hover:text-rose-500 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Session Progress Strip */}
                <div className="mt-2.5 pt-2.5 border-t border-zinc-200/50 dark:border-zinc-700/50 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-medium text-zinc-800 dark:text-zinc-200 font-mono">
                    <span>{toBn(s.startLevel)}%</span>
                    <span className="text-zinc-400">→</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{toBn(s.endLevel)}%</span>
                    <span className="text-[11px] text-emerald-600 font-sans ml-1">
                      (+{toBn(Math.max(0, s.endLevel - s.startLevel))}%)
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                    <Clock className="w-3 h-3 text-zinc-400" />
                    <span>সময়: {formatBnDuration(s.durationSeconds)}</span>
                  </div>
                </div>

                {/* Temperature status if recorded */}
                {s.maxTemperature && (
                  <div className="mt-1 text-[10px] text-amber-600 dark:text-amber-400">
                    সর্বোচ্চ তাপমাত্রা: {toBn(s.maxTemperature)}°C
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
