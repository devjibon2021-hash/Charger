import React from 'react';
import {
  Bell,
  BellOff,
  Volume2,
  Mic,
  Vibrate,
  CheckCircle2,
  AlertTriangle,
  Zap,
  ZapOff,
  Info,
  Trash2,
  Headphones,
  Radio,
  RefreshCw,
  AlertCircle,
  VolumeX,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { AppNotification, AppSettings } from '../types';
import { toBn, formatBnDateTime } from '../utils/bnUtils';
import { alertEngine } from '../utils/alertEngine';
import { useTTSDiagnostics } from '../hooks/useTTSDiagnostics';

interface AlertsViewProps {
  notifications: AppNotification[];
  onClearNotifications: () => void;
  notificationPermission: NotificationPermission;
  onRequestNotificationPermission: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  notifications,
  onClearNotifications,
  notificationPermission,
  onRequestNotificationPermission,
  settings,
  onUpdateSettings,
}) => {
  const tts = useTTSDiagnostics();

  const getNotificationIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'charger_connected':
        return <Zap className="w-4 h-4 text-emerald-500 fill-current" />;
      case 'charger_disconnected':
        return <ZapOff className="w-4 h-4 text-neutral-500" />;
      case 'target_reached':
      case 'charging_complete':
        return <CheckCircle2 className="w-4 h-4 text-blue-500" />;
      case 'temperature_warning':
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'reminder':
        return <Bell className="w-4 h-4 text-amber-500" />;
      case 'usb_connected':
      case 'usb_disconnected':
        return <Radio className="w-4 h-4 text-purple-500" />;
      case 'peripheral_connected':
      case 'peripheral_disconnected':
        return <Headphones className="w-4 h-4 text-teal-500" />;
      default:
        return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getStatusBadge = () => {
    switch (tts.lastTestStatus) {
      case 'speaking':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 animate-pulse">
            <Volume2 className="w-3 h-3" /> কথা বলছে...
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
            <CheckCircle2 className="w-3 h-3" /> সফলভাবে সম্পন্ন
          </span>
        );
      case 'testing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300">
            <RefreshCw className="w-3 h-3 animate-spin" /> পরীক্ষা চলছে...
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-3 h-3" /> ত্রুটি
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
            অপেক্ষমাণ
          </span>
        );
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* 1. System Notification Status Card */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                সিস্টেম নোটিফিকেশন অনুমতি
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                লক স্ক্রিন ও ব্যাকগ্রাউন্ডে সতর্কবার্তা প্রদর্শন
              </p>
            </div>
          </div>

          <div>
            {notificationPermission === 'granted' ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/50">
                <CheckCircle2 className="w-3.5 h-3.5" /> সক্রিয়
              </span>
            ) : notificationPermission === 'denied' ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200/60 dark:border-rose-800/50">
                <BellOff className="w-3.5 h-3.5" /> ব্লক করা
              </span>
            ) : (
              <button
                onClick={onRequestNotificationPermission}
                className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-white dark:text-zinc-900 text-xs font-medium shadow-xs transition"
              >
                অনুমতি দিন
              </button>
            )}
          </div>
        </div>

        {notificationPermission === 'denied' && (
          <div className="mt-3 p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/70 dark:border-rose-900/40 text-[11px] text-rose-700 dark:text-rose-300">
            ব্রাউজার সেটিংসে নোটিফিকেশন ব্লক করা রয়েছে। সরাসরি লকস্ক্রিন নোটিফিকেশন পেতে ব্রাউজার সাইট সেটিংসে অনুমতি প্রদান করুন।
          </div>
        )}
      </div>

      {/* 2. Comprehensive Bengali Voice Engine & Diagnostic Section */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs space-y-3.5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                বাংলা ভয়েস ইঞ্জিন (TTS) ও ডায়াগনস্টিক
              </h3>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                Android ও ব্রাউজারের প্রকৃত টেক্সট-টু-স্পিচ স্ট্যাটাস
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {getStatusBadge()}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            onClick={() =>
              tts.testVoice('আপনার ফোনের চার্জ ৯০ শতাংশ হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।')
            }
            disabled={tts.lastTestStatus === 'speaking'}
            className="flex-1 min-w-[130px] px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition disabled:opacity-50"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>ভয়েস টেস্ট করুন</span>
          </button>

          {tts.lastTestStatus === 'speaking' && (
            <button
              onClick={tts.cancelSpeech}
              className="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs transition"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>থামুন</span>
            </button>
          )}

          <button
            onClick={tts.reloadVoices}
            title="ভয়েস তালিকা পুনরায় রিফ্রেশ করুন"
            className="px-3 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-medium flex items-center gap-1.5 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>রিফ্রেশ</span>
          </button>
        </div>

        {/* Diagnostic Metrics Table (No Fake Data) */}
        <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-700/60 divide-y divide-zinc-200/60 dark:divide-zinc-700/50 text-xs">
          <div className="flex items-center justify-between py-1.5 first:pt-0">
            <span className="text-zinc-500 dark:text-zinc-400">TTS Supported:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              {tts.supported ? 'হ্যাঁ' : 'না'}
            </span>
          </div>

          <div className="flex items-center justify-between py-1.5">
            <span className="text-zinc-500 dark:text-zinc-400">Voice List Loaded:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              {tts.voicesLoaded
                ? `হ্যাঁ (${toBn(tts.totalVoicesCount)}টি ভয়েস)`
                : 'না (অপেক্ষমাণ)'}
            </span>
          </div>

          <div className="flex items-center justify-between py-1.5">
            <span className="text-zinc-500 dark:text-zinc-400">Bengali Voice Found:</span>
            <span
              className={`font-semibold ${
                tts.bengaliVoiceFound
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {tts.bengaliVoiceFound ? 'হ্যাঁ' : 'না'}
            </span>
          </div>

          <div className="flex items-center justify-between py-1.5">
            <span className="text-zinc-500 dark:text-zinc-400">Selected Voice Name:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200 text-right truncate max-w-[200px]">
              {tts.selectedVoiceName || 'অনুপস্থিত'}
            </span>
          </div>

          <div className="flex items-center justify-between py-1.5">
            <span className="text-zinc-500 dark:text-zinc-400">Selected Voice Language:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200 font-mono">
              {tts.selectedVoiceLang || '—'}
            </span>
          </div>

          <div className="flex items-center justify-between py-1.5">
            <span className="text-zinc-500 dark:text-zinc-400">Last Voice Test Status:</span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              {tts.lastTestStatus === 'speaking'
                ? 'কথা বলছে...'
                : tts.lastTestStatus === 'completed'
                ? 'সফলভাবে সম্পন্ন'
                : tts.lastTestStatus === 'testing'
                ? 'পরীক্ষা চলছে'
                : tts.lastTestStatus === 'error'
                ? 'ব্যর্থ / ত্রুটি'
                : 'অপেক্ষমাণ'}
            </span>
          </div>

          {tts.ttsError && (
            <div className="pt-2 pb-0.5">
              <div className="text-[11px] font-medium text-rose-600 dark:text-rose-400 flex items-start gap-1.5 leading-relaxed">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <span>TTS Error: {tts.ttsError}</span>
              </div>
            </div>
          )}
        </div>

        {/* Offline Audio Fallback Status Banner */}
        <div className="p-3 rounded-xl bg-emerald-50/90 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900/50 text-emerald-900 dark:text-emerald-200 text-[11px] space-y-1.5 leading-relaxed">
          <div className="font-semibold flex items-center gap-1.5 text-xs text-emerald-800 dark:text-emerald-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
            <span>অফলাইন বাংলা ভয়েস সিস্টেম প্রস্তুত (Offline Audio Active)</span>
          </div>
          <p>
            আপনার ডিভাইসে সিস্টেম বাংলা TTS ইনস্টল না থাকলেও কোনো সমস্যা নেই। Charging Assistant অ্যাপটিতে বিল্ট-ইন অফলাইন বাংলা অডিও (০ থেকে ১০০ পর্যন্ত সংখ্যা ও সব নোটিফিকেশন ভয়েস) অন্তর্ভুক্ত করা হয়েছে, যা কোনো ইন্টারনেট বা অতিরিক্ত ডাউনলোড ছাড়াই তৎক্ষণাৎ বেজে উঠবে।
          </p>
        </div>

        {/* Clear Instructions if User wants to install Android Device TTS */}
        {!tts.bengaliVoiceFound && (
          <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-700/60 text-zinc-700 dark:text-zinc-300 text-[11px] space-y-1.5 leading-relaxed">
            <div className="font-semibold flex items-center gap-1.5 text-xs text-zinc-800 dark:text-zinc-200">
              <Smartphone className="w-4 h-4 text-blue-500 flex-shrink-0" />
              <span>Android সিস্টেম TTS ইনস্টল করার নিয়ম (ঐচ্ছিক):</span>
            </div>
            <p>
              সরাসরি সিস্টেম সিন্থেসাইজার দিয়ে কথা শোনাতে চাইলে নিচের ধাপগুলো অনুসরণ করতে পারেন:
            </p>
            <ol className="list-decimal list-inside space-y-0.5 pl-1 text-[11px] text-zinc-600 dark:text-zinc-400">
              <li>ফোনের <strong>Settings &gt; System &gt; Languages &amp; input</strong> এ যান।</li>
              <li><strong>Text-to-speech output</strong> অপশনটিতে প্রবেশ করুন।</li>
              <li><strong>Preferred engine</strong>-এ Google Speech Services নির্বাচন করুন।</li>
              <li>ইঞ্জিনের পাশে থাকা <strong>গিয়ার (⚙️) আইকন &gt; Install voice data</strong>-এ গিয়ে <strong>Bengali (Bangladesh বা India)</strong> ডাউনলোড করুন।</li>
              <li>ডাউনলোড সম্পন্ন হলে উপরের <strong>"রিফ্রেশ"</strong> বাটনে ট্যাপ করুন।</li>
            </ol>
          </div>
        )}
      </div>

      {/* 3. Audio & Vibration Testing Buttons */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 mb-3">
          অ্যালার্ট ও ভয়েস পরীক্ষা
        </h3>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <button
            onClick={() => {
              alertEngine.playTone('connected');
              alertEngine.vibrate('connected');
              alertEngine.testBengaliVoice('চার্জার সংযুক্ত হয়েছে');
            }}
            className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/70 dark:border-zinc-700/60 flex flex-col items-center justify-center gap-1 hover:border-zinc-400 dark:hover:border-zinc-600 transition"
          >
            <Zap className="w-4 h-4 text-emerald-500 fill-current" />
            <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">চার্জার যুক্ত</span>
            <span className="text-[10px] text-zinc-400">ভয়েস + টোন</span>
          </button>

          <button
            onClick={() => {
              alertEngine.playTone('disconnected');
              alertEngine.vibrate('disconnected');
              alertEngine.testBengaliVoice('চার্জার বিচ্ছিন্ন করা হয়েছে');
            }}
            className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/70 dark:border-zinc-700/60 flex flex-col items-center justify-center gap-1 hover:border-zinc-400 dark:hover:border-zinc-600 transition"
          >
            <ZapOff className="w-4 h-4 text-zinc-500" />
            <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">চার্জার খোলা</span>
            <span className="text-[10px] text-zinc-400">ভয়েস + টোন</span>
          </button>

          <button
            onClick={() => {
              alertEngine.playTone('target_reached');
              alertEngine.vibrate('target_reached');
              alertEngine.testBengaliVoice('আপনার চার্জ সম্পূর্ণ হয়েছে');
            }}
            className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/70 dark:border-zinc-700/60 flex flex-col items-center justify-center gap-1 hover:border-zinc-400 dark:hover:border-zinc-600 transition"
          >
            <CheckCircle2 className="w-4 h-4 text-blue-500" />
            <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">টার্গেট ফুল</span>
            <span className="text-[10px] text-zinc-400">ভয়েস + সুর</span>
          </button>
        </div>

        {/* USB & Earphone Voice Previews */}
        <div className="pt-2.5 border-t border-zinc-100 dark:border-zinc-800">
          <div className="text-[11px] font-semibold text-zinc-700 dark:text-zinc-300 mb-2 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-purple-500" />
            <span>USB ও ইয়ারফোন সতর্কতা ভয়েস প্রিভিউ:</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                alertEngine.playTone('connected');
                alertEngine.vibrate('connected');
                alertEngine.testBengaliVoice('ইউএসবি সংযোগ করা হয়েছে');
              }}
              className="p-2.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200/60 dark:border-purple-900/50 flex items-center justify-between text-left hover:border-purple-400 transition"
            >
              <div>
                <div className="text-xs font-semibold text-purple-800 dark:text-purple-300 flex items-center gap-1">
                  🔌 USB কানেক্ট
                </div>
                <div className="text-[10px] text-purple-600 dark:text-purple-400">
                  "ইউএসবি সংযোগ করা হয়েছে"
                </div>
              </div>
              <Volume2 className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 flex-shrink-0" />
            </button>

            <button
              onClick={() => {
                alertEngine.playTone('disconnected');
                alertEngine.vibrate('disconnected');
                alertEngine.testBengaliVoice('ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে');
              }}
              className="p-2.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200/60 dark:border-purple-900/50 flex items-center justify-between text-left hover:border-purple-400 transition"
            >
              <div>
                <div className="text-xs font-semibold text-purple-800 dark:text-purple-300 flex items-center gap-1">
                  🔌 USB ডিসকানেক্ট
                </div>
                <div className="text-[10px] text-purple-600 dark:text-purple-400">
                  "ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে"
                </div>
              </div>
              <Volume2 className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 flex-shrink-0" />
            </button>

            <button
              onClick={() => {
                alertEngine.playTone('connected');
                alertEngine.vibrate('connected');
                alertEngine.testBengaliVoice('ইয়ারফোন সংযোগ করা হয়েছে');
              }}
              className="p-2.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/60 dark:border-teal-900/50 flex items-center justify-between text-left hover:border-teal-400 transition"
            >
              <div>
                <div className="text-xs font-semibold text-teal-800 dark:text-teal-300 flex items-center gap-1">
                  🎧 ইয়ারফোন কানেক্ট
                </div>
                <div className="text-[10px] text-teal-600 dark:text-teal-400">
                  "ইয়ারফোন সংযোগ করা হয়েছে"
                </div>
              </div>
              <Volume2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 flex-shrink-0" />
            </button>

            <button
              onClick={() => {
                alertEngine.playTone('disconnected');
                alertEngine.vibrate('disconnected');
                alertEngine.testBengaliVoice('ইয়ারফোন বিচ্ছিন্ন করা হয়েছে');
              }}
              className="p-2.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/60 dark:border-teal-900/50 flex items-center justify-between text-left hover:border-teal-400 transition"
            >
              <div>
                <div className="text-xs font-semibold text-teal-800 dark:text-teal-300 flex items-center gap-1">
                  🎧 ইয়ারফোন ডিসকানেক্ট
                </div>
                <div className="text-[10px] text-teal-600 dark:text-teal-400">
                  "ইয়ারফোন বিচ্ছিন্ন করা হয়েছে"
                </div>
              </div>
              <Volume2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 flex-shrink-0" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Notification Log Feed */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              সাম্প্রতিক নোটিফিকেশন লগ ({toBn(notifications.length)})
            </h3>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              চার্জিং সম্পর্কিত সব বার্তা
            </p>
          </div>
          {notifications.length > 0 && (
            <button
              onClick={onClearNotifications}
              className="text-xs text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1 font-medium"
            >
              <Trash2 className="w-3.5 h-3.5" />
              লগ মুছুন
            </button>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="py-8 text-center text-zinc-400 dark:text-zinc-500">
            <Bell className="w-7 h-7 mx-auto mb-1.5 opacity-30 stroke-1" />
            <div className="text-xs font-medium">কোনো নোটিফিকেশন নেই</div>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {notifications.map((n) => (
              <div
                key={n.id}
                className="p-3 rounded-xl bg-zinc-50/70 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-700/50 flex items-start gap-3"
              >
                <div className="w-7 h-7 rounded-lg bg-white dark:bg-zinc-700/80 border border-zinc-200/60 dark:border-zinc-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                  {getNotificationIcon(n.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-1">
                    <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 truncate">
                      {n.title}
                    </span>
                    <span className="text-[10px] text-zinc-400 flex-shrink-0">
                      {formatBnDateTime(n.timestamp)}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-600 dark:text-zinc-300 mt-0.5 leading-relaxed">
                    {n.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
