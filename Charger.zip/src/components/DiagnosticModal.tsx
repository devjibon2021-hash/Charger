import React from 'react';
import { X, Zap, ZapOff, CheckCircle2, AlertTriangle, Volume2, Mic, Vibrate, RotateCcw } from 'lucide-react';
import { alertEngine } from '../utils/alertEngine';

interface DiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSimulatePluggedIn: (pct: number) => void;
  onSimulateUnplugged: (pct: number) => void;
  onSimulateTargetReached: (pct: number) => void;
  onSimulateTempWarning: () => void;
  onSimulateUsbConnect?: () => void;
  onSimulateUsbDisconnect?: () => void;
  onSimulateEarphoneConnect?: () => void;
  onSimulateEarphoneDisconnect?: () => void;
  onExitTestMode: () => void;
  isTestMode: boolean;
  currentLevel: number;
}

export const DiagnosticModal: React.FC<DiagnosticModalProps> = ({
  isOpen,
  onClose,
  onSimulatePluggedIn,
  onSimulateUnplugged,
  onSimulateTargetReached,
  onSimulateTempWarning,
  onSimulateUsbConnect,
  onSimulateUsbDisconnect,
  onSimulateEarphoneConnect,
  onSimulateEarphoneDisconnect,
  onExitTestMode,
  isTestMode,
  currentLevel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-5 shadow-xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-zinc-800">
          <div>
            <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 flex items-center gap-1.5">
              <span>ডায়াগনস্টিক ও টেস্ট মোড</span>
            </h2>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
              বাস্তব ইভেন্ট যাচাই করার জন্য নিরাপদ সিমুলেশন
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 space-y-3">
          {/* Charger Connect / Disconnect */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              ১. চার্জার সংযোগ ও বিচ্ছিন্ন পরীক্ষা
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onSimulatePluggedIn(47)}
                className="p-3 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  <Zap className="w-4 h-4 fill-current" />
                  চার্জার লাগান (৪৭%)
                </div>
                <div className="text-[10px] text-zinc-500 dark:text-zinc-400 mt-1">
                  কানেক্ট ভয়েস ও অ্যালার্ট বাজবে
                </div>
              </button>

              <button
                onClick={() => onSimulateUnplugged(86)}
                className="p-3 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  <ZapOff className="w-4 h-4" />
                  চার্জার খুলুন (৮৬%)
                </div>
                <div className="text-[10px] text-zinc-500 dark:text-zinc-400 mt-1">
                  ডিসকানেক্ট ও হিস্ট্রি সেভ হবে
                </div>
              </button>
            </div>
          </div>

          {/* USB & Earphone Simulation Section */}
          <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              ২. USB ও ইয়ারফোন ভয়েস সতর্কতা পরীক্ষা
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onSimulateUsbConnect}
                className="p-2.5 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                  🔌 USB সংযুক্ত
                </div>
                <div className="text-[10px] text-zinc-500 mt-0.5">
                  "ইউএসবি সংযোগ করা হয়েছে"
                </div>
              </button>

              <button
                onClick={onSimulateUsbDisconnect}
                className="p-2.5 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="text-xs font-semibold text-purple-600 dark:text-purple-400 flex items-center gap-1">
                  🔌 USB বিচ্ছিন্ন
                </div>
                <div className="text-[10px] text-zinc-500 mt-0.5">
                  "ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে"
                </div>
              </button>

              <button
                onClick={onSimulateEarphoneConnect}
                className="p-2.5 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="text-xs font-semibold text-teal-600 dark:text-teal-400 flex items-center gap-1">
                  🎧 ইয়ারফোন যুক্ত
                </div>
                <div className="text-[10px] text-zinc-500 mt-0.5">
                  "ইয়ারফোন সংযোগ করা হয়েছে"
                </div>
              </button>

              <button
                onClick={onSimulateEarphoneDisconnect}
                className="p-2.5 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition"
              >
                <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                  🎧 ইয়ারফোন খোলা
                </div>
                <div className="text-[10px] text-zinc-500 mt-0.5">
                  "ইয়ারফোন বিচ্ছিন্ন করা হয়েছে"
                </div>
              </button>
            </div>
          </div>

          {/* Target Complete Alerts */}
          <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              ২. চার্জ সম্পূর্ণ ও টার্গেট অ্যালার্ট
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onSimulateTargetReached(85)}
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-center text-xs font-medium text-zinc-800 dark:text-zinc-200 transition"
              >
                ৮৫% টার্গেট
              </button>
              <button
                onClick={() => onSimulateTargetReached(90)}
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-center text-xs font-medium text-zinc-800 dark:text-zinc-200 transition"
              >
                ৯০% টার্গেট
              </button>
              <button
                onClick={() => onSimulateTargetReached(100)}
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-center text-xs font-semibold text-emerald-600 dark:text-emerald-400 transition"
              >
                ১০০% পূর্ণ
              </button>
            </div>
          </div>

          {/* Temperature Alert */}
          <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              ৩. উচ্চ তাপমাত্রা সতর্কতা পরীক্ষা
            </label>
            <button
              onClick={onSimulateTempWarning}
              className="w-full p-2.5 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/80 dark:border-zinc-700/60 text-left transition flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                    উচ্চ তাপমাত্রা অ্যালার্ট (৪৫°C)
                  </div>
                  <div className="text-[10px] text-zinc-500 dark:text-zinc-400">
                    সতর্কবার্তা, ভয়েস ও ভাইব্রেশন ট্রিগার করবে
                  </div>
                </div>
              </div>
            </button>
          </div>

          {/* Direct Hardware Sound & Voice Tester */}
          <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <label className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              ৪. সরাসরি সাউন্ড ও ভয়েস পরীক্ষা
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => alertEngine.playTone('target_reached')}
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/70 dark:border-zinc-700/50 text-xs font-medium text-zinc-700 dark:text-zinc-300 flex flex-col items-center gap-1 transition"
              >
                <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>সাউন্ড</span>
              </button>
              <button
                onClick={() =>
                  alertEngine.testBengaliVoice('আপনার ফোনের চার্জ ৯০ শতাংশ হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।')
                }
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/70 dark:border-zinc-700/50 text-xs font-medium text-zinc-700 dark:text-zinc-300 flex flex-col items-center gap-1 transition"
              >
                <Mic className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>বাংলা ভয়েস</span>
              </button>
              <button
                onClick={() => alertEngine.vibrate('target_reached')}
                className="p-2 rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800/40 dark:hover:bg-zinc-800/70 border border-zinc-200/70 dark:border-zinc-700/50 text-xs font-medium text-zinc-700 dark:text-zinc-300 flex flex-col items-center gap-1 transition"
              >
                <Vibrate className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>ভাইব্রেশন</span>
              </button>
            </div>
          </div>

          {/* Reset button */}
          {isTestMode && (
            <div className="pt-2">
              <button
                onClick={() => {
                  onExitTestMode();
                  onClose();
                }}
                className="w-full py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-medium flex items-center justify-center gap-1.5 shadow-xs transition"
              >
                <RotateCcw className="w-4 h-4" />
                <span>রিয়েল সেন্সরে ফিরে যান</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
