/**
 * বাংলা ভয়েস সার্ভিস (Bengali Voice Service)
 * Three-Tier Architecture:
 * 1. Android Native TTS Bridge
 * 2. Device / Web Speech API (bn-BD / bn-IN)
 * 3. App Built-in Pre-recorded Offline Bengali Audio System
 */

import { VoiceMode, AlertEventKey } from '../types';
import { normalizeTextForSpeech, toBnWord } from '../utils/bnUtils';

export interface VoiceDiagnosticInfo {
  voiceMode: VoiceMode;
  activeTier: 'native_bridge' | 'device_tts' | 'offline_audio' | 'none';
  deviceTTSAvailable: boolean;
  bengaliVoiceName: string | null;
  bengaliVoiceLang: string | null;
  nativeBridgeActive: boolean;
  offlineAudioAvailable: boolean;
  preloadedAudioCount: number;
  lastPlayedEvent: string | null;
  lastPlayedTime: number | null;
  status: 'ready' | 'offline_mode' | 'android_tts' | 'unavailable';
  statusText: string;
  isSpeaking: boolean;
  error: string | null;
}

export type VoiceAlertEvent =
  | AlertEventKey
  | 'voice_test'
  | 'offline_mode_announced'
  | 'charging_started'
  | 'battery_80'
  | 'battery_90'
  | 'usb_connected'
  | 'usb_disconnected'
  | 'earphone_connected'
  | 'earphone_disconnected'
  | 'service_turned_on'
  | 'service_turned_off';

export interface PlayAlertOptions {
  level?: number;
  customText?: string;
  voiceMode?: VoiceMode;
  forceOffline?: boolean;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: string) => void;
}

const STATIC_AUDIO_MAP: Record<string, string> = {
  charger_connected: '/audio/bn/charger_connected.mp3',
  charging_started: '/audio/bn/charging_started.mp3',
  battery_80: '/audio/bn/battery_80.mp3',
  battery_90: '/audio/bn/battery_90.mp3',
  charging_complete: '/audio/bn/charging_complete.mp3',
  temperature_warning: '/audio/bn/temperature_high.mp3',
  battery_low: '/audio/bn/battery_low.mp3',
  charger_removed: '/audio/bn/charger_removed.mp3',
  usb_connected: '/audio/bn/usb_connected.mp3',
  usb_disconnected: '/audio/bn/usb_disconnected.mp3',
  earphone_connected: '/audio/bn/earphone_connected.mp3',
  earphone_disconnected: '/audio/bn/earphone_disconnected.mp3',
  service_turned_on: '/audio/bn/service_turned_on.mp3',
  service_turned_off: '/audio/bn/service_turned_off.mp3',
  voice_test: '/audio/bn/voice_test.mp3',
  background_test: '/audio/bn/background_test.mp3',
  offline_mode_announced: '/audio/bn/offline_mode_announced.mp3',
  battery_prefix: '/audio/bn/battery_prefix.mp3',
  percent_complete: '/audio/bn/percent_complete.mp3',
};

class BengaliVoiceService {
  private voiceMode: VoiceMode = 'automatic';
  private preloadedAudio: Map<string, HTMLAudioElement> = new Map();
  private subscribers: Set<(info: VoiceDiagnosticInfo) => void> = new Set();
  
  // State variables
  private isUnlocked = false;
  private isSpeaking = false;
  private currentAudioElement: HTMLAudioElement | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private lastAlertEvent: string | null = null;
  private lastAlertTimestamp = 0;
  private currentSequenceId = 0;
  private lastError: string | null = null;

  // TTS Detection
  private ttsVoices: SpeechSynthesisVoice[] = [];
  private matchedBnVoice: SpeechSynthesisVoice | null = null;
  private isVoicesLoaded = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.initVoices();
      this.preloadCrucialAudios();
      this.setupUserGestureUnlock();
    }
  }

  /**
   * Set user preferred voice mode
   */
  public setVoiceMode(mode: VoiceMode): void {
    this.voiceMode = mode;
    this.notify();
  }

  public getVoiceMode(): VoiceMode {
    return this.voiceMode;
  }

  /**
   * Check if Android Native Bridge exists in WebView container
   */
  public hasNativeBridge(): boolean {
    if (typeof window === 'undefined') return false;
    const w = window as unknown as Record<string, unknown>;
    return !!(
      w.AndroidTTS ||
      w.AndroidBridge ||
      w.ChargingAssistantNative ||
      (w.Android && typeof (w.Android as Record<string, unknown>).speakTTS === 'function')
    );
  }

  /**
   * Preload crucial offline audio assets for instant latency-free playback
   */
  public preloadCrucialAudios(): void {
    if (typeof window === 'undefined') return;

    const crucialKeys = [
      'charger_connected',
      'charging_started',
      'battery_80',
      'battery_90',
      'charging_complete',
      'temperature_warning',
      'charger_removed',
      'battery_low',
      'voice_test',
      'offline_mode_announced',
      'battery_prefix',
      'percent_complete',
    ];

    crucialKeys.forEach((key) => {
      const src = STATIC_AUDIO_MAP[key];
      if (src && !this.preloadedAudio.has(src)) {
        try {
          const audio = new Audio();
          audio.preload = 'auto';
          audio.src = src;
          this.preloadedAudio.set(src, audio);
        } catch {
          // ignore
        }
      }
    });

    // Also preload numbers 70-100 which are most frequent for charging alerts
    for (let i = 70; i <= 100; i++) {
      const numSrc = `/audio/bn/numbers/${i}.mp3`;
      if (!this.preloadedAudio.has(numSrc)) {
        try {
          const audio = new Audio();
          audio.preload = 'auto';
          audio.src = numSrc;
          this.preloadedAudio.set(numSrc, audio);
        } catch {
          // ignore
        }
      }
    }
  }

  /**
   * Unlock AudioContext & Web Speech upon first user touch/click
   */
  public unlock(): void {
    if (this.isUnlocked) return;
    this.isUnlocked = true;

    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window && window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
  }

  private setupUserGestureUnlock(): void {
    if (typeof window === 'undefined') return;
    const unlockHandler = () => {
      this.unlock();
      window.removeEventListener('click', unlockHandler);
      window.removeEventListener('touchstart', unlockHandler);
    };
    window.addEventListener('click', unlockHandler, { passive: true, once: true });
    window.addEventListener('touchstart', unlockHandler, { passive: true, once: true });
  }

  /**
   * Evaluate Web Speech API voices
   */
  public initVoices(): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.isVoicesLoaded = true;
      this.notify();
      return;
    }

    const evaluate = () => {
      try {
        const voices = window.speechSynthesis.getVoices() || [];
        this.ttsVoices = voices;
        this.isVoicesLoaded = voices.length > 0;

        let matched: SpeechSynthesisVoice | null = null;
        matched = voices.find((v) => v.lang.toLowerCase() === 'bn-bd') || null;
        if (!matched) matched = voices.find((v) => v.lang.toLowerCase() === 'bn-in') || null;
        if (!matched) matched = voices.find((v) => v.lang.toLowerCase().startsWith('bn')) || null;
        if (!matched) {
          matched = voices.find((v) => {
            const nl = v.name.toLowerCase();
            return nl.includes('bangla') || nl.includes('bengali') || v.name.includes('বাংলা');
          }) || null;
        }

        this.matchedBnVoice = matched;
        this.notify();
      } catch (err) {
        this.lastError = (err as Error)?.message || 'Voice evaluation error';
        this.notify();
      }
    };

    evaluate();

    if ('onvoiceschanged' in window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = evaluate;
    }
    window.speechSynthesis.addEventListener('voiceschanged', evaluate);

    setTimeout(evaluate, 300);
    setTimeout(evaluate, 1200);
    setTimeout(evaluate, 2500);
  }

  /**
   * Subscribe to diagnostic state changes
   */
  public subscribe(callback: (info: VoiceDiagnosticInfo) => void): () => void {
    this.subscribers.add(callback);
    callback(this.getDiagnosticInfo());
    return () => {
      this.subscribers.delete(callback);
    };
  }

  private notify(): void {
    const info = this.getDiagnosticInfo();
    this.subscribers.forEach((cb) => {
      try {
        cb(info);
      } catch {
        // ignore
      }
    });
  }

  public getDiagnosticInfo(): VoiceDiagnosticInfo {
    const hasBridge = this.hasNativeBridge();
    const hasTTS = !!this.matchedBnVoice;
    const hasOffline = true; // Bundled offline audio assets in /public/audio/bn/

    let activeTier: 'native_bridge' | 'device_tts' | 'offline_audio' | 'none' = 'offline_audio';
    let status: 'ready' | 'offline_mode' | 'android_tts' | 'unavailable' = 'ready';
    let statusText = 'বাংলা ভয়েস: প্রস্তুত';

    if (this.voiceMode === 'android_tts') {
      if (hasBridge) {
        activeTier = 'native_bridge';
        status = 'android_tts';
        statusText = 'বাংলা ভয়েস: Android Native Bridge';
      } else if (hasTTS) {
        activeTier = 'device_tts';
        status = 'android_tts';
        statusText = `বাংলা ভয়েস: Android TTS (${this.matchedBnVoice?.name || 'Device'})`;
      } else {
        activeTier = 'none';
        status = 'unavailable';
        statusText = 'বাংলা ভয়েস: উপলব্ধ নয় (ডিভাইসে বাংলা TTS নেই)';
      }
    } else if (this.voiceMode === 'offline_audio') {
      activeTier = 'offline_audio';
      status = 'offline_mode';
      statusText = 'বাংলা ভয়েস: Offline Mode (বিল্ট-ইন অডিও)';
    } else {
      // Automatic Mode (Default)
      if (hasBridge) {
        activeTier = 'native_bridge';
        status = 'android_tts';
        statusText = 'বাংলা ভয়েস: Android Native Bridge';
      } else if (hasTTS) {
        activeTier = 'device_tts';
        status = 'android_tts';
        statusText = `বাংলা ভয়েস: Android TTS (${this.matchedBnVoice?.name || 'Device'})`;
      } else if (hasOffline) {
        activeTier = 'offline_audio';
        status = 'offline_mode';
        statusText = 'বাংলা ভয়েস: Offline Mode (বিল্ট-ইন অডিও)';
      } else {
        activeTier = 'none';
        status = 'unavailable';
        statusText = 'বাংলা ভয়েস: উপলব্ধ নয়';
      }
    }

    return {
      voiceMode: this.voiceMode,
      activeTier,
      deviceTTSAvailable: hasTTS,
      bengaliVoiceName: this.matchedBnVoice?.name || null,
      bengaliVoiceLang: this.matchedBnVoice?.lang || null,
      nativeBridgeActive: hasBridge,
      offlineAudioAvailable: hasOffline,
      preloadedAudioCount: this.preloadedAudio.size,
      lastPlayedEvent: this.lastAlertEvent,
      lastPlayedTime: this.lastAlertTimestamp,
      status,
      statusText,
      isSpeaking: this.isSpeaking,
      error: this.lastError,
    };
  }

  /**
   * Stop any ongoing speech or offline audio immediately
   */
  public stopCurrentVoice(): void {
    this.currentSequenceId++;
    this.isSpeaking = false;

    // 1. Stop Native Bridge
    if (this.hasNativeBridge()) {
      const w = window as unknown as Record<string, unknown>;
      try {
        if (w.AndroidTTS && typeof (w.AndroidTTS as Record<string, unknown>).stop === 'function') {
          (w.AndroidTTS as { stop: () => void }).stop();
        }
      } catch {
        // ignore
      }
    }

    // 2. Stop Web Speech
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
    }

    // 3. Stop HTMLAudioElement
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch {
        // ignore
      }
      this.currentAudioElement = null;
    }

    this.notify();
  }

  public clearQueue(): void {
    this.stopCurrentVoice();
  }

  /**
   * Plays a single pre-recorded audio file with promise resolution
   */
  private playAudioFile(src: string, sequenceId: number): Promise<boolean> {
    return new Promise((resolve) => {
      if (this.currentSequenceId !== sequenceId) {
        resolve(false);
        return;
      }

      let audio = this.preloadedAudio.get(src);
      if (!audio) {
        audio = new Audio(src);
        audio.preload = 'auto';
        this.preloadedAudio.set(src, audio);
      }

      this.currentAudioElement = audio;
      audio.currentTime = 0;

      const cleanup = () => {
        audio.onended = null;
        audio.onerror = null;
      };

      audio.onended = () => {
        cleanup();
        if (this.currentSequenceId === sequenceId) {
          resolve(true);
        } else {
          resolve(false);
        }
      };

      audio.onerror = (e) => {
        cleanup();
        console.warn(`[BengaliVoiceService] Audio playback error for ${src}:`, e);
        resolve(false);
      };

      audio.play().catch((err) => {
        cleanup();
        console.warn(`[BengaliVoiceService] Autoplay prevented for ${src}:`, err);
        resolve(false);
      });
    });
  }

  /**
   * Plays a sequence of pre-recorded audio files seamlessly (e.g. prefix -> number -> percent)
   */
  public async playOfflineSequence(sources: string[], sequenceId: number): Promise<boolean> {
    for (const src of sources) {
      if (this.currentSequenceId !== sequenceId) return false;
      const success = await this.playAudioFile(src, sequenceId);
      if (!success && this.currentSequenceId !== sequenceId) return false;
    }
    return true;
  }

  /**
   * Speaks using Android Native Bridge
   */
  private async speakWithNativeBridge(text: string): Promise<boolean> {
    if (!this.hasNativeBridge()) return false;
    const w = window as unknown as Record<string, unknown>;
    const normalized = normalizeTextForSpeech(text);
    try {
      if (w.AndroidTTS && typeof (w.AndroidTTS as Record<string, unknown>).speak === 'function') {
        (w.AndroidTTS as { speak: (t: string) => void }).speak(normalized);
        return true;
      }
      if (w.Android && typeof (w.Android as Record<string, unknown>).speakTTS === 'function') {
        (w.Android as { speakTTS: (t: string) => void }).speakTTS(normalized);
        return true;
      }
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).speak === 'function') {
        (w.ChargingAssistantNative as { speak: (t: string) => void }).speak(normalized);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  /**
   * Speaks using Device Web Speech API
   */
  private speakWithWebSpeech(text: string, sequenceId: number): Promise<boolean> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window) || !this.matchedBnVoice) {
        resolve(false);
        return;
      }

      try {
        window.speechSynthesis.cancel();
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }

        const normalized = normalizeTextForSpeech(text);
        const utterance = new SpeechSynthesisUtterance(normalized);
        utterance.rate = 0.92;
        utterance.pitch = 1.0;
        utterance.voice = this.matchedBnVoice;
        utterance.lang = this.matchedBnVoice.lang || 'bn-BD';

        this.currentUtterance = utterance;

        utterance.onend = () => {
          this.currentUtterance = null;
          if (this.currentSequenceId === sequenceId) {
            resolve(true);
          } else {
            resolve(false);
          }
        };

        utterance.onerror = () => {
          this.currentUtterance = null;
          resolve(false);
        };

        window.speechSynthesis.speak(utterance);
      } catch {
        resolve(false);
      }
    });
  }

  /**
   * Primary voice trigger method: handles Three-Tier Priority & Dynamic Percentage
   */
  public async playAlert(
    eventKey: VoiceAlertEvent,
    options?: PlayAlertOptions
  ): Promise<boolean> {
    this.unlock();

    // Prevent duplicate firing within 2.5 seconds for identical event
    const now = Date.now();
    if (this.lastAlertEvent === eventKey && now - this.lastAlertTimestamp < 2500) {
      return false;
    }

    this.lastAlertEvent = eventKey;
    this.lastAlertTimestamp = now;

    // Stop previous voice and increment sequence
    this.stopCurrentVoice();
    const sequenceId = ++this.currentSequenceId;
    this.isSpeaking = true;
    this.notify();

    if (options?.onStart) options.onStart();

    const currentMode = options?.voiceMode || this.voiceMode;
    const level = options?.level;
    const hasCustomText = Boolean(options?.customText && options.customText.trim());

    // Determine voice phrase text for TTS
    let ttsText = '';
    if (hasCustomText) {
      ttsText = options!.customText!.trim();
    } else {
      switch (eventKey) {
        case 'charger_connected':
          ttsText = 'চার্জার সংযোগ করা হয়েছে।';
          break;
        case 'charging_started':
          ttsText = 'চার্জ শুরু হয়েছে।';
          break;
        case 'battery_80':
        case 'target_reached':
          if (level && level >= 100) {
            ttsText = 'চার্জ সম্পূর্ণ হয়েছে। চার্জার খুলে দিন।';
          } else if (level) {
            ttsText = `ব্যাটারি ${toBnWord(level)} শতাংশ হয়েছে।`;
          } else {
            ttsText = 'ব্যাটারি লক্ষ্যমাত্রা অর্জিত হয়েছে।';
          }
          break;
        case 'charging_complete':
          ttsText = 'চার্জ সম্পূর্ণ হয়েছে। চার্জার খুলে দিন।';
          break;
        case 'temperature_warning':
          ttsText = 'সতর্কতা। ফোনের তাপমাত্রা বেশি হয়ে গেছে।';
          break;
        case 'battery_low':
          ttsText = 'ব্যাটারির চার্জ কম।';
          break;
        case 'charger_removed':
          ttsText = 'চার্জার খুলে ফেলা হয়েছে।';
          break;
        case 'usb_connected':
          ttsText = 'ইউএসবি সংযোগ করা হয়েছে।';
          break;
        case 'usb_disconnected':
          ttsText = 'ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে।';
          break;
        case 'earphone_connected':
          ttsText = 'ইয়ারফোন সংযোগ করা হয়েছে।';
          break;
        case 'earphone_disconnected':
          ttsText = 'ইয়ারফোন বিচ্ছিন্ন করা হয়েছে।';
          break;
        case 'service_turned_on':
          ttsText = 'চার্জিং সহকারী চালু করা হয়েছে।';
          break;
        case 'service_turned_off':
          ttsText = 'চার্জিং সহকারী বন্ধ করা হয়েছে।';
          break;
        case 'voice_test':
          ttsText = 'এটি চার্জিং সহকারীর বাংলা ভয়েস পরীক্ষা।';
          break;
        case 'offline_mode_announced':
          ttsText = 'অফলাইন বাংলা ভয়েস ব্যবহার করা হচ্ছে।';
          break;
        case 'reminder':
          if (level) {
            ttsText = `বর্তমানে আপনার ফোনের ব্যাটারি ${toBnWord(level)} শতাংশ চার্জ হয়েছে। চার্জিং অব্যাহত রয়েছে।`;
          } else {
            ttsText = 'বর্তমানে আপনার ফোন চার্জ হচ্ছে।';
          }
          break;
        default:
          ttsText = 'চার্জিং নোটিফিকেশন।';
          break;
      }
    }

    // Determine offline audio sources (dynamic sequence)
    // CRITICAL: ONLY populate default static audio files if there is NO custom text!
    // If the user provided a custom written sentence, we must NOT play pre-recorded audio of the default phrase!
    const offlineSources: string[] = [];
    if (!hasCustomText) {
      if (eventKey === 'target_reached' || eventKey === 'reminder') {
        if (level && level >= 100) {
          offlineSources.push(STATIC_AUDIO_MAP.charging_complete);
        } else if (level === 80) {
          offlineSources.push(STATIC_AUDIO_MAP.battery_80);
        } else if (level === 90) {
          offlineSources.push(STATIC_AUDIO_MAP.battery_90);
        } else if (level && level >= 0 && level <= 100) {
          offlineSources.push(STATIC_AUDIO_MAP.battery_prefix);
          offlineSources.push(`/audio/bn/numbers/${level}.mp3`);
          offlineSources.push(STATIC_AUDIO_MAP.percent_complete);
        } else {
          offlineSources.push(STATIC_AUDIO_MAP.battery_90);
        }
      } else if (STATIC_AUDIO_MAP[eventKey]) {
        offlineSources.push(STATIC_AUDIO_MAP[eventKey]);
      }
    }

    let playedSuccessfully = false;
    const isBackground = typeof document !== 'undefined' && document.hidden;

    // IF CUSTOM TEXT IS GIVEN: Speak the user's exact written sentence!
    if (hasCustomText) {
      // 1. Android Native Bridge
      if (this.hasNativeBridge()) {
        const bridgeSuccess = await this.speakWithNativeBridge(ttsText);
        if (bridgeSuccess) playedSuccessfully = true;
      }

      // 2. High-fidelity Server-side /api/tts endpoint (Guaranteed clear Bengali speech in background & foreground!)
      if (!playedSuccessfully && typeof window !== 'undefined' && navigator.onLine) {
        try {
          const ttsUrl = `/api/tts?text=${encodeURIComponent(ttsText)}&lang=bn`;
          playedSuccessfully = await this.playAudioFile(ttsUrl, sequenceId);
        } catch {
          // ignore
        }
      }

      // 3. Web Speech API (device TTS fallback in foreground)
      if (!playedSuccessfully && !isBackground) {
        const webSuccess = await this.speakWithWebSpeech(ttsText, sequenceId);
        if (webSuccess) playedSuccessfully = true;
      }
    } else {
      // TIER EXECUTION BASED ON MODE FOR DEFAULT PHRASES
      if (currentMode === 'offline_audio' || options?.forceOffline) {
        // Direct Tier 3: Built-in Offline Audio
        if (offlineSources.length > 0) {
          playedSuccessfully = await this.playOfflineSequence(offlineSources, sequenceId);
        }
      } else if (currentMode === 'android_tts') {
        // Force Android/Device TTS
        if (this.hasNativeBridge()) {
          playedSuccessfully = await this.speakWithNativeBridge(ttsText);
        } else if (!isBackground && this.matchedBnVoice) {
          playedSuccessfully = await this.speakWithWebSpeech(ttsText, sequenceId);
        } else {
          // In background or if TTS voice unavailable, fallback to offline audio
          if (offlineSources.length > 0) {
            playedSuccessfully = await this.playOfflineSequence(offlineSources, sequenceId);
          } else {
            playedSuccessfully = false;
            this.lastError = 'এই ডিভাইসে ব্যাকগ্রাউন্ড বাংলা TTS উপলব্ধ নেই।';
          }
        }
      } else {
        // Automatic Mode (Recommended & Default)
        // Tier 1: Android Native Bridge (Always works in background if APK)
        if (this.hasNativeBridge()) {
          const bridgeSuccess = await this.speakWithNativeBridge(ttsText);
          if (bridgeSuccess) playedSuccessfully = true;
        }

        // Tier 2: If in background (app minimized or screen off), prioritize HTML5 Audio
        if (!playedSuccessfully && isBackground) {
          if (offlineSources.length > 0) {
            playedSuccessfully = await this.playOfflineSequence(offlineSources, sequenceId);
          }
          if (!playedSuccessfully && typeof window !== 'undefined' && navigator.onLine) {
            try {
              const ttsUrl = `/api/tts?text=${encodeURIComponent(ttsText)}&lang=bn`;
              playedSuccessfully = await this.playAudioFile(ttsUrl, sequenceId);
            } catch {
              // ignore
            }
          }
        }

        // Tier 3: If in foreground, Web Speech API (bn-BD, bn-IN) or high-fidelity audio
        if (!playedSuccessfully && !isBackground) {
          if (offlineSources.length > 0) {
            playedSuccessfully = await this.playOfflineSequence(offlineSources, sequenceId);
          }
          if (!playedSuccessfully && this.matchedBnVoice) {
            const webSuccess = await this.speakWithWebSpeech(ttsText, sequenceId);
            if (webSuccess) playedSuccessfully = true;
          }
          if (!playedSuccessfully && typeof window !== 'undefined' && navigator.onLine) {
            try {
              const ttsUrl = `/api/tts?text=${encodeURIComponent(ttsText)}&lang=bn`;
              playedSuccessfully = await this.playAudioFile(ttsUrl, sequenceId);
            } catch {
              // ignore
            }
          }
        }

        // Tier 4: Fallback to whatever offline sources we have if still not played
        if (!playedSuccessfully && offlineSources.length > 0) {
          playedSuccessfully = await this.playOfflineSequence(offlineSources, sequenceId);
        }
      }
    }

    if (this.currentSequenceId === sequenceId) {
      this.isSpeaking = false;
      this.notify();
      if (playedSuccessfully && options?.onEnd) options.onEnd();
      if (!playedSuccessfully && options?.onError) {
        options.onError(this.lastError || 'ভয়েস প্লেব্যাক ব্যর্থ হয়েছে।');
      }
    }

    return playedSuccessfully;
  }

  /**
   * Test Voice function: Announced in Settings and Alerts
   */
  public async testVoice(): Promise<boolean> {
    this.unlock();

    // If in Android TTS mode and no voice available, announce offline mode
    if (this.voiceMode === 'android_tts' && !this.matchedBnVoice && !this.hasNativeBridge()) {
      return this.playAlert('voice_test', {
        forceOffline: true,
        customText: 'অফলাইন বাংলা ভয়েস ব্যবহার করা হচ্ছে। এটি চার্জিং সহকারীর বাংলা ভয়েস পরীক্ষা।',
      });
    }

    // Play test phrase
    return this.playAlert('voice_test', {
      customText: 'এটি চার্জিং সহকারীর বাংলা ভয়েস পরীক্ষা।',
    });
  }

  /**
   * Speak arbitrary text typed by user in Bengali or English (বাংলায় যা লিখা হবে তাই বলবে / Bilingual speech)
   * Guaranteed pronunciation: uses high-quality /api/tts proxy, Device TTS, Native Bridge, and offline fallbacks.
   */
  public async speakCustomText(
    text: string,
    options?: {
      lang?: 'bn' | 'en' | 'auto';
      rate?: number;
      forceDeviceTTS?: boolean;
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: string) => void;
    }
  ): Promise<boolean> {
    this.unlock();
    this.stopCurrentVoice();

    const trimmed = text.trim();
    if (!trimmed) {
      this.isSpeaking = false;
      this.notify();
      return false;
    }

    const sequenceId = ++this.currentSequenceId;
    this.isSpeaking = true;
    this.notify();
    if (options?.onStart) options.onStart();

    // Check if text has Bengali characters
    const hasBengali = /[\u0980-\u09FF]/.test(trimmed);
    const targetLang = options?.lang === 'auto' || !options?.lang ? (hasBengali ? 'bn' : 'en') : options.lang;

    let success = false;

    // 1. If Android Native Bridge is available
    if (targetLang === 'bn' && this.hasNativeBridge()) {
      success = await this.speakWithNativeBridge(trimmed);
    }

    // 2. High-fidelity Server-side /api/tts endpoint (Guaranteed to work for any Bengali/English sentence on any device)
    if (!success && !options?.forceDeviceTTS && typeof window !== 'undefined' && navigator.onLine) {
      try {
        const encoded = encodeURIComponent(trimmed);
        const ttsUrl = `/api/tts?text=${encoded}&lang=${targetLang}`;
        success = await this.playAudioFile(ttsUrl, sequenceId);
      } catch (e) {
        console.warn('[BengaliVoiceService] /api/tts error:', e);
      }
    }

    // 3. Web Speech API (device TTS fallback)
    if (!success && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      success = await new Promise<boolean>((resolve) => {
        try {
          window.speechSynthesis.cancel();
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }

          // Small timeout to prevent Chrome bug where immediate speak after cancel fails
          setTimeout(() => {
            if (this.currentSequenceId !== sequenceId) {
              resolve(false);
              return;
            }

            const normalized = targetLang === 'bn' ? normalizeTextForSpeech(trimmed) : trimmed;
            const utterance = new SpeechSynthesisUtterance(normalized);
            utterance.rate = options?.rate || (targetLang === 'bn' ? 0.92 : 1.0);
            utterance.pitch = 1.0;

            const voices = window.speechSynthesis.getVoices() || [];
            if (targetLang === 'bn') {
              if (this.matchedBnVoice) {
                utterance.voice = this.matchedBnVoice;
                utterance.lang = this.matchedBnVoice.lang || 'bn-BD';
              } else {
                const bnCandidate =
                  voices.find((v) => v.lang.toLowerCase().startsWith('bn')) ||
                  voices.find(
                    (v) =>
                      v.name.toLowerCase().includes('bangla') ||
                      v.name.toLowerCase().includes('bengali')
                  ) ||
                  voices.find((v) => v.lang.toLowerCase().startsWith('hi')) ||
                  voices.find((v) => v.lang.toLowerCase().startsWith('en-in'));

                if (bnCandidate) {
                  utterance.voice = bnCandidate;
                  utterance.lang = bnCandidate.lang;
                } else {
                  utterance.lang = 'bn-BD';
                }
              }
            } else {
              // English Voice
              const enCandidate = voices.find((v) => v.lang.toLowerCase().startsWith('en')) || voices[0];
              if (enCandidate) {
                utterance.voice = enCandidate;
                utterance.lang = enCandidate.lang || 'en-US';
              }
            }

            this.currentUtterance = utterance;

            // Safety timeout in case utterance onend never fires (common Chrome bug)
            const safetyTimeout = setTimeout(() => {
              if (this.currentSequenceId === sequenceId) {
                this.currentUtterance = null;
                resolve(true);
              }
            }, Math.max(2500, trimmed.length * 150));

            utterance.onend = () => {
              clearTimeout(safetyTimeout);
              this.currentUtterance = null;
              if (this.currentSequenceId === sequenceId) {
                resolve(true);
              } else {
                resolve(false);
              }
            };

            utterance.onerror = (err) => {
              clearTimeout(safetyTimeout);
              this.currentUtterance = null;
              console.warn('[BengaliVoiceService] Speech utterance error:', err);
              resolve(false);
            };

            window.speechSynthesis.speak(utterance);
          }, 60);
        } catch {
          resolve(false);
        }
      });
    }

    // Notice: Never substitute pre-recorded default audio clips when user requests speaking their custom text!
    if (this.currentSequenceId === sequenceId) {
      this.isSpeaking = false;
      this.notify();
      if (success && options?.onEnd) options.onEnd();
      if (!success && options?.onError) {
        options.onError('ভয়েস উচ্চারণ করা যায়নি। অনুগ্রহ করে ব্রাউজারের অডিও চালু করুন।');
      }
    }

    return success;
  }
}

export const bengaliVoiceService = new BengaliVoiceService();
