/**
 * চার্জিং সহকারী ব্যাকগ্রাউন্ড সার্ভিস (Background Service & Keepalive Engine)
 * 
 * মোবাইল ব্রাউজার/PWA অ্যাপ মিনিমাইজ হলে বা স্ক্রিন অফ হলে যেন বাংলা ভয়েস ও চার্জিং অ্যালার্ট
 * স্বাভাবিকভাবে বাজতে পারে, তার জন্য MediaSession Audio Keepalive, WakeLock এবং 
 * Service Worker Notification ম্যানেজ করে।
 */

import { workerTimer } from '../utils/workerTimer';

export interface BackgroundServiceState {
  enabled: boolean;
  audioKeepaliveRunning: boolean;
  isWakeLockActive: boolean;
  isTabVisible: boolean;
  mediaSessionSupported: boolean;
  wakeLockSupported: boolean;
  serviceWorkerActive: boolean;
}

class BackgroundService {
  private keepaliveAudio: HTMLAudioElement | null = null;
  private wakeLockSentinel: unknown = null;
  private watchdogTimerId: number | null = null;
  private subscribers: Set<(state: BackgroundServiceState) => void> = new Set();
  private hasUserInteracted = false;
  
  private state: BackgroundServiceState = {
    enabled: true,
    audioKeepaliveRunning: false,
    isWakeLockActive: false,
    isTabVisible: typeof document !== 'undefined' ? !document.hidden : true,
    mediaSessionSupported: typeof navigator !== 'undefined' && 'mediaSession' in navigator,
    wakeLockSupported: typeof navigator !== 'undefined' && 'wakeLock' in navigator,
    serviceWorkerActive: typeof navigator !== 'undefined' && 'serviceWorker' in navigator,
  };

  constructor() {
    if (typeof window !== 'undefined') {
      this.initVisibilityListener();
      this.initMediaSession();
      this.setupServiceWorkerWatch();
      this.initUserGestureUnlock();
    }
  }

  private initUserGestureUnlock(): void {
    if (typeof window === 'undefined') return;

    const unlock = async () => {
      this.hasUserInteracted = true;
      if (this.state.enabled && !this.state.audioKeepaliveRunning) {
        await this.startKeepalive();
      }
      if (this.state.enabled && !this.state.isWakeLockActive) {
        await this.requestWakeLock();
      }
    };

    window.addEventListener('click', unlock, { passive: true });
    window.addEventListener('touchstart', unlock, { passive: true });
    window.addEventListener('pointerdown', unlock, { passive: true });
  }

  public subscribe(cb: (state: BackgroundServiceState) => void): () => void {
    this.subscribers.add(cb);
    cb(this.getState());
    return () => {
      this.subscribers.delete(cb);
    };
  }

  private notify(): void {
    const s = this.getState();
    this.subscribers.forEach((cb) => cb(s));
  }

  public getState(): BackgroundServiceState {
    return { ...this.state };
  }

  /**
   * Listen to tab visibility changes
   */
  private initVisibilityListener(): void {
    if (typeof document === 'undefined') return;

    document.addEventListener('visibilitychange', () => {
      const isVisible = !document.hidden;
      this.state.isTabVisible = isVisible;

      if (!isVisible && this.state.enabled) {
        // App went to background - ensure keepalive audio is playing to prevent OS freeze
        this.ensureKeepaliveRunning();
      }

      // Re-acquire wake lock if visible again and was active
      if (isVisible && this.state.enabled && this.state.isWakeLockActive && !this.wakeLockSentinel) {
        this.requestWakeLock();
      }

      this.notify();
    });
  }

  /**
   * Configure MediaSession metadata for persistent lockscreen presence
   */
  private initMediaSession(): void {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: 'চার্জিং সহকারী (সক্রিয়)',
        artist: 'ব্যাকগ্রাউন্ডে ব্যাটারি ও চার্জিং মনিটর চলছে...',
        album: 'স্মার্ট চার্জ সহকারী',
        artwork: [
          { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      });

      navigator.mediaSession.setActionHandler('play', () => {
        this.startKeepalive();
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        // Keep running or silently resume if requested
        this.startKeepalive();
      });

      navigator.mediaSession.setActionHandler('stop', () => {
        this.stopKeepalive();
      });
    } catch (e) {
      console.warn('[BackgroundService] MediaSession setup error:', e);
    }
  }

  private setupServiceWorkerWatch(): void {
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then(() => {
          this.state.serviceWorkerActive = true;
          this.notify();
        })
        .catch(() => {
          // ignore
        });
    }
  }

  private isNativePlatform(): boolean {
    if (typeof window === 'undefined') return false;
    const w = window as unknown as Record<string, unknown>;
    return Boolean(w.isAndroidNativeApp || w.ChargingAssistantNative || w.Android);
  }

  /**
   * Start looping silent audio to maintain background media session
   * This is what prevents Android / iOS from putting the browser tab to sleep.
   */
  public async startKeepalive(): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    // In Native Android APK, the Foreground Service & WakeLock is the primary background mechanism
    if (this.isNativePlatform()) {
      this.state.audioKeepaliveRunning = true;
      this.notify();
      return true;
    }

    if (!this.keepaliveAudio) {
      const audio = new Audio('/audio/silent-keepalive.mp3');
      audio.loop = true;
      audio.volume = 0.05; // Non-zero so OS media router doesn't treat as muted
      audio.preload = 'auto';

      audio.onplay = () => {
        this.state.audioKeepaliveRunning = true;
        this.notify();
      };

      audio.onpause = () => {
        if (this.state.enabled && !this.state.isTabVisible) {
          // Attempt recovery if paused while in background
          setTimeout(() => {
            audio.play().catch(() => {});
          }, 300);
        } else {
          this.state.audioKeepaliveRunning = false;
          this.notify();
        }
      };

      audio.onerror = () => {
        this.state.audioKeepaliveRunning = false;
        this.notify();
      };

      this.keepaliveAudio = audio;
    }

    try {
      await this.keepaliveAudio.play();
      this.state.audioKeepaliveRunning = true;
      if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
        navigator.mediaSession.playbackState = 'playing';
      }
      this.initMediaSession();
      this.notify();
      return true;
    } catch (err) {
      console.warn('[BackgroundService] Keepalive play error (waiting for user touch):', err);
      return false;
    }
  }

  public ensureKeepaliveRunning(): void {
    if (this.state.enabled && !this.state.audioKeepaliveRunning) {
      this.startKeepalive().catch(() => {});
    }
  }

  public stopKeepalive(): void {
    if (this.keepaliveAudio) {
      try {
        this.keepaliveAudio.pause();
        this.keepaliveAudio.currentTime = 0;
      } catch {
        // ignore
      }
      this.state.audioKeepaliveRunning = false;
      this.notify();
    }
  }

  /**
   * Screen Wake Lock API to keep display on when charging
   */
  public async requestWakeLock(): Promise<boolean> {
    if (typeof navigator === 'undefined' || !('wakeLock' in navigator)) {
      return false;
    }

    try {
      const sentinel = await (navigator as unknown as { wakeLock: { request: (type: string) => Promise<unknown> } }).wakeLock.request('screen');
      this.wakeLockSentinel = sentinel;
      this.state.isWakeLockActive = true;
      this.notify();

      // Listen for release
      (sentinel as { addEventListener?: (event: string, cb: () => void) => void }).addEventListener?.('release', () => {
        this.wakeLockSentinel = null;
        this.state.isWakeLockActive = false;
        this.notify();
      });

      return true;
    } catch (e) {
      console.warn('[BackgroundService] WakeLock request failed:', e);
      this.state.isWakeLockActive = false;
      this.notify();
      return false;
    }
  }

  public async releaseWakeLock(): Promise<void> {
    if (this.wakeLockSentinel) {
      try {
        await (this.wakeLockSentinel as { release: () => Promise<void> }).release();
      } catch {
        // ignore
      }
      this.wakeLockSentinel = null;
    }
    this.state.isWakeLockActive = false;
    this.notify();
  }

  /**
   * Dispatch system notification safely via ServiceWorker (Required for Android Chrome)
   */
  public async showSystemNotification(
    title: string,
    options: {
      body: string;
      tag?: string;
      vibrate?: number[];
      icon?: string;
      badge?: string;
      renotify?: boolean;
    }
  ): Promise<boolean> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }

    if (Notification.permission !== 'granted') {
      return false;
    }

    const notifOptions: NotificationOptions & { renotify?: boolean } = {
      body: options.body,
      icon: options.icon || '/pwa-192x192.png',
      badge: options.badge || '/pwa-192x192.png',
      tag: options.tag || 'charging-assistant-alert',
      renotify: options.renotify !== false,
      silent: false,
    };

    // Android Chrome REQUIRES ServiceWorkerRegistration.showNotification
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.ready;
        if (registration && typeof registration.showNotification === 'function') {
          await registration.showNotification(title, notifOptions);
          return true;
        }
      } catch {
        // fallback to standard constructor
      }
    }

    // Standard fallback (Desktop / Safari)
    try {
      new Notification(title, notifOptions);
      return true;
    } catch (err) {
      console.warn('[BackgroundService] Notification constructor failed on this platform:', err);
      return false;
    }
  }

  /**
   * Master Background Mode Toggle
   */
  public setEnabled(enabled: boolean): void {
    this.state.enabled = enabled;
    if (enabled) {
      this.startKeepalive();
    } else {
      this.stopKeepalive();
      this.releaseWakeLock();
    }
    this.notify();
  }

  /**
   * Watchdog timer to continuously check battery status even when backgrounded
   */
  public startWatchdog(callback: () => void): void {
    if (this.watchdogTimerId !== null) {
      workerTimer.clearInterval(this.watchdogTimerId);
    }
    // 3.5s interval is aggressive enough to catch unplug/plug immediately,
    // but gentle on mobile battery
    this.watchdogTimerId = workerTimer.setInterval(() => {
      callback();
    }, 3500);
  }

  public stopWatchdog(): void {
    if (this.watchdogTimerId !== null) {
      workerTimer.clearInterval(this.watchdogTimerId);
      this.watchdogTimerId = null;
    }
  }
}

export const backgroundService = new BackgroundService();
