/**
 * অফলাইন লোকাল স্টোরেজ ম্যানেজার
 */
import { AppSettings, ChargingSession, AppNotification } from '../types';

const SETTINGS_KEY = 'bn_charging_assistant_settings_v1';
const SESSIONS_KEY = 'bn_charging_assistant_sessions_v1';
const NOTIFICATIONS_KEY = 'bn_charging_assistant_notifications_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  serviceEnabled: true,
  targetBatteryLevel: 85,
  customTargetLevel: 80,
  repeatReminderEnabled: true,
  reminderIntervalMinutes: 10,
  customIntervalMinutes: 10,
  temperatureWarningEnabled: true,
  temperatureThreshold: 42,
  voiceMode: 'automatic',
  bengaliVoiceEnabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  notificationEnabled: true,
  alertChannels: {
    charger_connected: { voice: true, sound: true, vibration: true, notification: true },
    charging_started: { voice: true, sound: true, vibration: true, notification: true },
    target_reached: { voice: true, sound: true, vibration: true, notification: true },
    charging_complete: { voice: true, sound: true, vibration: true, notification: true },
    temperature_warning: { voice: true, sound: true, vibration: true, notification: true },
    charger_removed: { voice: true, sound: true, vibration: true, notification: true },
    battery_low: { voice: true, sound: true, vibration: true, notification: true },
    usb_connected: { voice: true, sound: true, vibration: true, notification: true },
    usb_disconnected: { voice: true, sound: true, vibration: true, notification: true },
    earphone_connected: { voice: true, sound: true, vibration: true, notification: true },
    earphone_disconnected: { voice: true, sound: true, vibration: true, notification: true },
    reminder: { voice: true, sound: true, vibration: true, notification: true },
  },
  themeMode: 'system',
  nightModeEnabled: false,
  nightTargetLevel: 80,
  nightStartHour: 23,
  nightEndHour: 7,
  usbDetectionEnabled: true,
  peripheralDetectionEnabled: true,
  backgroundModeEnabled: true,
  keepScreenOnWhileCharging: false,
  customPhrases: {
    useCustomPhrases: true,
    customBengaliText: 'আমার ফোন এখন চার্জে আছে। ১০০% হলে খুলে দিন।',
    applyToTargetReached: true,
    charger_connected: '',
    charger_removed: '',
    target_reached: '',
    battery_low: '',
  },
};

export function loadSettings(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Storage quota or private browsing mode
  }
}

export function loadSessions(): ChargingSession[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveSessions(sessions: ChargingSession[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch {
    // ignore
  }
}

export function addSession(session: ChargingSession): ChargingSession[] {
  const current = loadSessions();
  // Keep up to 200 sessions
  const updated = [session, ...current.filter((s) => s.id !== session.id)].slice(0, 200);
  saveSessions(updated);
  return updated;
}

export function deleteSession(id: string): ChargingSession[] {
  const current = loadSessions();
  const updated = current.filter((s) => s.id !== id);
  saveSessions(updated);
  return updated;
}

export function clearSessions(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(SESSIONS_KEY);
  } catch {
    // ignore
  }
}

export function loadNotifications(): AppNotification[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveNotifications(notifications: AppNotification[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch {
    // ignore
  }
}

export function addNotification(notification: AppNotification): AppNotification[] {
  const current = loadNotifications();
  const updated = [notification, ...current].slice(0, 50);
  saveNotifications(updated);
  return updated;
}

export function clearNotifications(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(NOTIFICATIONS_KEY);
  } catch {
    // ignore
  }
}

const CHAT_KEY = 'bn_charging_assistant_chat_v1';
const CUSTOM_VOICE_KEY = 'bn_charging_assistant_custom_voice_v1';

export function loadChatMessages(): import('../types').ChatMessage[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CHAT_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveChatMessages(messages: import('../types').ChatMessage[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CHAT_KEY, JSON.stringify(messages.slice(-50)));
  } catch {
    // ignore
  }
}

export function loadCustomVoiceHistory(): import('../types').CustomVoiceItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CUSTOM_VOICE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomVoiceHistory(items: import('../types').CustomVoiceItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CUSTOM_VOICE_KEY, JSON.stringify(items.slice(0, 30)));
  } catch {
    // ignore
  }
}
