/**
 * বাংলা সংখ্যা ও টেক্সট ফরম্যাটিং ইউটিলিটি
 */

const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toBn(value: number | string | null | undefined): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  return str.replace(/[0-9]/g, (digit) => BN_DIGITS[parseInt(digit, 10)] || digit);
}

export function toBnPercent(value: number | null | undefined): string {
  if (value === null || value === undefined) return '০%';
  return `${toBn(Math.round(value))}%`;
}

/**
 * ফরম্যাট: ৩ সেপ্টেম্বর ২০২৬, ১২:১০ PM
 */
const BN_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

export function formatBnDateTime(dateInput: number | string | Date): string {
  const date = new Date(dateInput);
  if (isNaN(date.getTime())) return '';

  const day = toBn(date.getDate());
  const month = BN_MONTHS[date.getMonth()];
  const year = toBn(date.getFullYear());

  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // 0 becomes 12

  const hoursBn = toBn(hours);
  const minutesBn = toBn(minutes < 10 ? `0${minutes}` : minutes);

  return `${day} ${month} ${year}, ${hoursBn}:${minutesBn} ${ampm}`;
}

export function formatBnTime(dateInput: number | string | Date): string {
  const date = new Date(dateInput);
  if (isNaN(date.getTime())) return '';

  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;

  const hoursBn = toBn(hours);
  const minutesBn = toBn(minutes < 10 ? `0${minutes}` : minutes);

  return `${hoursBn}:${minutesBn} ${ampm}`;
}

export function formatBnDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '০ মিনিট';
  
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const parts: string[] = [];
  if (hrs > 0) {
    parts.push(`${toBn(hrs)} ঘণ্টা`);
  }
  if (mins > 0 || hrs > 0) {
    parts.push(`${toBn(mins)} মিনিট`);
  }
  if (hrs === 0 && mins === 0) {
    parts.push(`${toBn(secs)} সেকেন্ড`);
  }

  return parts.join(' ');
}

/**
 * ০ থেকে ১০০ পর্যন্ত বাংলা সংখ্যা শব্দের তালিকা
 * Android TTS ইঞ্জিনে সংখ্যা যাতে বিকৃত উচ্চারণ ("নয় শূন্য") না হয়
 */
const BN_NUM_WORDS: string[] = [
  'শূন্য', 'এক', 'দুই', 'তিন', 'চার', 'পাঁচ', 'ছয়', 'সাত', 'আট', 'নয়', 'দশ',
  'এগারো', 'বারো', 'তেরো', 'চৌদ্দ', 'পনেরো', 'ষোলো', 'সতেরো', 'আঠারো', 'উনিশ', 'বিশ',
  'একুশ', 'বাইশ', 'তেইশ', 'চব্বিশ', 'পঁচিশ', 'ছাব্বিশ', 'সাতাশ', 'আঠাশ', 'উনত্রিশ', 'ত্রিশ',
  'একত্রিশ', 'বত্রিশ', 'তেত্রিশ', 'চৌত্রিশ', 'পঁয়ত্রিশ', 'ছত্রিশ', 'সাঁইত্রিশ', 'আটত্রিশ', 'উনচল্লিশ', 'চল্লিশ',
  'একচল্লিশ', 'বিয়াল্লিশ', 'তেতাল্লিশ', 'চুয়াল্লিশ', 'পঁয়তাল্লিশ', 'ছেচল্লিশ', 'সাতচল্লিশ', 'আটচল্লিশ', 'উনপঞ্চাশ', 'পঞ্চাশ',
  'একান্ন', 'বায়ান্ন', 'তিপ্পান্ন', 'চুয়ান্ন', 'পঞ্চান্ন', 'ছাপ্পান্ন', 'সাতান্ন', 'আটান্ন', 'উনষাট', 'ষাট',
  'একষট্টি', 'বাষট্টি', 'তেষট্টি', 'চৌষট্টি', 'পঁয়ষট্টি', 'ছেষট্টি', 'সাতষট্টি', 'আটষট্টি', 'উনসত্তর', 'সত্তর',
  'একাত্তর', 'বাহাত্তর', 'তিয়াত্তর', 'চুয়াত্তর', 'পঁচাত্তর', 'ছিয়াত্তর', 'সাতাত্তর', 'আটাত্তর', 'উনআশি', 'আশি',
  'একাশি', 'বিরাশি', 'তিরাশি', 'চুরাশি', 'পঁচাশি', 'ছিয়াশি', 'সাতাশি', 'আটাশি', 'ঊননব্বই', 'নব্বই',
  'একানব্বই', 'বায়ানব্বই', 'তিরানব্বই', 'চুরানব্বই', 'পঁচানব্বই', 'ছিয়ানব্বই', 'সাতানব্বই', 'আটানব্বই', 'নিরানব্বই', 'একশত'
];

/**
 * সংখ্যাকে (০-১০০) কথায় রূপান্তর
 */
export function bnNumberToWords(num: number): string {
  const rounded = Math.round(num);
  if (rounded >= 0 && rounded <= 100) {
    return BN_NUM_WORDS[rounded];
  }
  return toBn(num);
}

export const toBnWord = bnNumberToWords;

/**
 * TTS-এর জন্য বাক্য স্বাভাবিকীকরণ:
 * সংখ্যা ও চিহ্নকে স্পষ্ট বাংলা উচ্চারণে রূপান্তর করে যাতে TTS সহজে সঠিক উচ্চারণে পড়তে পারে
 */
export function normalizeTextForSpeech(text: string): string {
  if (!text) return '';
  let result = text;

  // শতাংশ বা % চিহ্ন হ্যান্ডলিং
  result = result.replace(/%/g, ' শতাংশ');

  // বাংলা সংখ্যা (যেমন: ৯০, ১০০, ৮৫, ইত্যাদি) শব্দের সমতুল্যে রূপান্তর
  // যাতে Android Speech Engine "নয় শূন্য" না পড়ে সরাসরি "নব্বই" পড়ে
  const bnToEnglishMap: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };

  // বাংলা সংখ্যা জোড়া শনাক্ত করে শব্দে রূপান্তর (০ থেকে ১০০ পর্যন্ত)
  result = result.replace(/[০-৯]{1,3}/g, (match) => {
    const engStr = match.split('').map(c => bnToEnglishMap[c] || c).join('');
    const n = parseInt(engStr, 10);
    if (!isNaN(n) && n >= 0 && n <= 100) {
      return BN_NUM_WORDS[n];
    }
    return match;
  });

  // ইংরেজি সংখ্যা শনাক্ত করে শব্দে রূপান্তর (০ থেকে ১০০)
  result = result.replace(/\b\d{1,3}\b/g, (match) => {
    const n = parseInt(match, 10);
    if (!isNaN(n) && n >= 0 && n <= 100) {
      return BN_NUM_WORDS[n];
    }
    return match;
  });

  return result.trim();
}
