/**
 * অডিও সিন্থেসাইজার, বাংলা ভয়েস (TTS) এবং ভাইব্রেশন ইঞ্জিন
 * Android / PWA / WebView স্ট্যান্ডার্ড ও অপটিমাইজড আর্কিটেকচার
 */

import { normalizeTextForSpeech } from './bnUtils';
import { bengaliVoiceService } from '../services/bengaliVoiceService';
import { AlertEventKey, VoiceMode } from '../types';

export interface TTSDiagnosticState {
  supported: boolean;
  voicesLoaded: boolean;
  totalVoicesCount: number;
  bengaliVoiceFound: boolean;
  selectedVoiceName: string | null;
  selectedVoiceLang: string | null;
  ttsError: string | null;
  lastTestStatus: 'idle' | 'testing' | 'speaking' | 'completed' | 'error';
  lastSpokenText: string | null;
  lastEventTimestamp: number | null;
  isNativeBridgeActive: boolean;
  backgroundLimitationNotified: boolean;
}

/**
 * Android Native Bridge Interface Abstraction
 * ভবিষ্যতে বা বর্তমান Android WebView কনটেইনারে Java/Kotlin TTS Bridge এর জন্য প্রস্তুত
 */
export interface ITTSBridge {
  isAvailable(): boolean;
  speak(text: string, options?: { rate?: number; pitch?: number }): Promise<boolean>;
  stop(): void;
  getVoiceName(): string | null;
}

class AndroidNativeBridge implements ITTSBridge {
  public isAvailable(): boolean {
    if (typeof window === 'undefined') return false;
    const w = window as unknown as Record<string, unknown>;
    return !!(
      w.AndroidTTS ||
      w.AndroidBridge ||
      w.ChargingAssistantNative ||
      (w.Android && typeof (w.Android as Record<string, unknown>).speakTTS === 'function')
    );
  }

  public getVoiceName(): string | null {
    if (!this.isAvailable()) return null;
    const w = window as unknown as Record<string, unknown>;
    if (w.AndroidTTS && typeof (w.AndroidTTS as Record<string, unknown>).getVoiceName === 'function') {
      return (w.AndroidTTS as { getVoiceName: () => string }).getVoiceName();
    }
    return 'Android Native TTS Bridge';
  }

  public async speak(text: string): Promise<boolean> {
    if (!this.isAvailable()) return false;
    const w = window as unknown as Record<string, unknown>;
    try {
      if (w.AndroidTTS && typeof (w.AndroidTTS as Record<string, unknown>).speak === 'function') {
        (w.AndroidTTS as { speak: (t: string) => void }).speak(text);
        return true;
      }
      if (w.Android && typeof (w.Android as Record<string, unknown>).speakTTS === 'function') {
        (w.Android as { speakTTS: (t: string) => void }).speakTTS(text);
        return true;
      }
      if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).speak === 'function') {
        (w.ChargingAssistantNative as { speak: (t: string) => void }).speak(text);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  public stop(): void {
    if (!this.isAvailable()) return;
    const w = window as unknown as Record<string, unknown>;
    try {
      if (w.AndroidTTS && typeof (w.AndroidTTS as Record<string, unknown>).stop === 'function') {
        (w.AndroidTTS as { stop: () => void }).stop();
      }
    } catch {
      // ignore
    }
  }
}

class AlertEngine {
  private audioCtx: AudioContext | null = null;
  private bnVoice: SpeechSynthesisVoice | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private nativeBridge: ITTSBridge = new AndroidNativeBridge();
  private subscribers: Set<(state: TTSDiagnosticState) => void> = new Set();
  private speakSequence = 0;
  private isUnlocked = false;

  private state: TTSDiagnosticState = {
    supported: typeof window !== 'undefined' && 'speechSynthesis' in window,
    voicesLoaded: false,
    totalVoicesCount: 0,
    bengaliVoiceFound: false,
    selectedVoiceName: null,
    selectedVoiceLang: null,
    ttsError: null,
    lastTestStatus: 'idle',
    lastSpokenText: null,
    lastEventTimestamp: null,
    isNativeBridgeActive: false,
    backgroundLimitationNotified: true,
  };

  constructor() {
    if (typeof window !== 'undefined') {
      this.initNativeBridgeCheck();
      this.initVoices();
      this.setupUserGestureUnlock();
    }
  }

  private initNativeBridgeCheck(): void {
    const isBridge = this.nativeBridge.isAvailable();
    this.state.isNativeBridgeActive = isBridge;
    if (isBridge) {
      this.state.supported = true;
      this.state.bengaliVoiceFound = true;
      this.state.selectedVoiceName = this.nativeBridge.getVoiceName();
      this.state.selectedVoiceLang = 'bn-BD';
    }
  }

  /**
   * স্টেট পরিবর্তনের সাবস্ক্রিপশন
   */
  public subscribe(callback: (state: TTSDiagnosticState) => void): () => void {
    this.subscribers.add(callback);
    callback({ ...this.state });
    return () => {
      this.subscribers.delete(callback);
    };
  }

  private notify(): void {
    const current = { ...this.state };
    this.subscribers.forEach((cb) => {
      try {
        cb(current);
      } catch {
        // ignore subscriber errors
      }
    });
  }

  public getState(): TTSDiagnosticState {
    return { ...this.state };
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  /**
   * ব্রাউজার অটোপ্লে ও স্পিচ আনলক
   */
  public unlock(): void {
    if (this.isUnlocked) return;
    this.isUnlocked = true;

    // 1. AudioContext unlock
    const ctx = this.getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    // 2. SpeechSynthesis wake up
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
  }

  private setupUserGestureUnlock(): void {
    if (typeof window === 'undefined') return;
    const unlockHandler = () => {
      this.unlock();
      window.removeEventListener('click', unlockHandler);
      window.removeEventListener('touchstart', unlockHandler);
      window.removeEventListener('keydown', unlockHandler);
    };
    window.addEventListener('click', unlockHandler, { passive: true, once: true });
    window.addEventListener('touchstart', unlockHandler, { passive: true, once: true });
    window.addEventListener('keydown', unlockHandler, { passive: true, once: true });
  }

  /**
   * ভয়েস তালিকা লোড ও বাংলা ভয়েস শনাক্তকরণ
   */
  public initVoices(): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.state.supported = false;
      this.state.ttsError = 'এই ব্রাউজারে Web Speech API (speechSynthesis) সমর্থিত নয়।';
      this.notify();
      return;
    }

    const evaluateVoices = () => {
      const voices = window.speechSynthesis.getVoices() || [];
      this.state.totalVoicesCount = voices.length;
      this.state.voicesLoaded = voices.length > 0;

      // বাংলা ভয়েস শনাক্তকরণের অগ্রাধিকার সার্চ
      let matchedVoice: SpeechSynthesisVoice | null = null;

      // 1. Exact bn-BD (বাংলাদেশ বাংলা)
      matchedVoice = voices.find((v) => v.lang.toLowerCase() === 'bn-bd') || null;

      // 2. Exact bn-IN (ভারত বাংলা)
      if (!matchedVoice) {
        matchedVoice = voices.find((v) => v.lang.toLowerCase() === 'bn-in') || null;
      }

      // 3. Language starts with bn
      if (!matchedVoice) {
        matchedVoice = voices.find((v) => v.lang.toLowerCase().startsWith('bn')) || null;
      }

      // 4. Voice Name contains bangla / bengali / বাংলা
      if (!matchedVoice) {
        matchedVoice =
          voices.find((v) => {
            const nameLower = v.name.toLowerCase();
            return (
              nameLower.includes('bangla') ||
              nameLower.includes('bengali') ||
              v.name.includes('বাংলা')
            );
          }) || null;
      }

      // 5. Lang code contains 'bn'
      if (!matchedVoice) {
        matchedVoice = voices.find((v) => v.lang.toLowerCase().includes('bn')) || null;
      }

      if (matchedVoice) {
        this.bnVoice = matchedVoice;
        this.state.bengaliVoiceFound = true;
        this.state.selectedVoiceName = matchedVoice.name;
        this.state.selectedVoiceLang = matchedVoice.lang;
        this.state.ttsError = null;
      } else {
        this.bnVoice = null;
        this.state.bengaliVoiceFound = false;
        this.state.selectedVoiceName = null;
        this.state.selectedVoiceLang = null;
        if (voices.length > 0) {
          this.state.ttsError =
            'এই ডিভাইসে বাংলা Text-to-Speech voice পাওয়া যায়নি। Android-এর Text-to-Speech settings থেকে Bengali voice install করুন।';
        }
      }

      this.notify();
    };

    // প্রথমবার কল
    evaluateVoices();

    // voiceschanged ইভেন্ট হ্যান্ডলার (Chrome, Android WebView ও অন্যান্য ব্রাউজারে অ্যাসিনক্রোনাস ভয়েস লোডিং)
    if ('onvoiceschanged' in window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = evaluateVoices;
    }
    window.speechSynthesis.addEventListener('voiceschanged', evaluateVoices);

    // কিছু Android Chromium ভার্সনে initial getVoices খালি থাকে এবং event ট্রিগার হয় না
    // তাই শর্ট ইন্টারভালে ৩ বার ব্যাকআপ চেক
    setTimeout(evaluateVoices, 250);
    setTimeout(evaluateVoices, 1000);
    setTimeout(evaluateVoices, 2500);
  }

  public reloadVoices(): void {
    this.unlock();
    this.initVoices();
  }

  public hasBengaliVoice(): boolean {
    if (this.nativeBridge.isAvailable()) return true;
    if (!this.state.voicesLoaded) this.initVoices();
    return !!this.bnVoice;
  }

  public getBengaliVoiceName(): string | null {
    if (this.nativeBridge.isAvailable()) return this.nativeBridge.getVoiceName();
    if (!this.state.voicesLoaded) this.initVoices();
    return this.bnVoice ? this.bnVoice.name : null;
  }

  /**
   * সাউন্ড মেলোডি (বিশুদ্ধ ওয়েব অডিও সাইন ওয়েভ)
   */
  public playTone(type: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder'): void {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'connected') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.18); // G5
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.25, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
        osc.start(now);
        osc.stop(now + 0.45);
      } else if (type === 'disconnected') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(783.99, now);
        osc.frequency.exponentialRampToValueAtTime(523.25, now + 0.18);
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.25, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
        osc.start(now);
        osc.stop(now + 0.45);
      } else if (type === 'target_reached') {
        const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
        notes.forEach((freq, idx) => {
          const noteOsc = ctx.createOscillator();
          const noteGain = ctx.createGain();
          noteOsc.connect(noteGain);
          noteGain.connect(ctx.destination);

          noteOsc.type = 'triangle';
          noteOsc.frequency.setValueAtTime(freq, now + idx * 0.12);
          noteGain.gain.setValueAtTime(0, now + idx * 0.12);
          noteGain.gain.linearRampToValueAtTime(0.3, now + idx * 0.12 + 0.03);
          noteGain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.35);

          noteOsc.start(now + idx * 0.12);
          noteOsc.stop(now + idx * 0.12 + 0.35);
        });
      } else if (type === 'warning') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.setValueAtTime(440, now + 0.15);
        osc.frequency.setValueAtTime(880, now + 0.3);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      } else if (type === 'reminder') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(659.25, now);
        osc.frequency.setValueAtTime(880, now + 0.15);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      }
    } catch {
      // Audio might be waiting for user gesture
    }
  }

  /**
   * মোবাইল ভাইব্রেশন
   */
  public vibrate(pattern: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder'): void {
    if (typeof window === 'undefined' || !navigator.vibrate) return;
    try {
      if (pattern === 'connected') {
        navigator.vibrate([150, 80, 150]);
      } else if (pattern === 'disconnected') {
        navigator.vibrate([200, 100, 100]);
      } else if (pattern === 'target_reached') {
        navigator.vibrate([300, 150, 300, 150, 500]);
      } else if (pattern === 'warning') {
        navigator.vibrate([500, 200, 500, 200, 500]);
      } else if (pattern === 'reminder') {
        navigator.vibrate([200, 100, 200]);
      }
    } catch {
      // ignored
    }
  }

  /**
   * বাংলা ভয়েস স্পিচ (Android / PWA অপটিমাইজড)
   */
  public async speakBengali(
    text: string,
    callbacks?: {
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
      onFallback?: (spokenText: string) => void;
    }
  ): Promise<{ success: boolean; error?: string }> {
    this.unlock();

    const normalizedText = normalizeTextForSpeech(text);
    this.state.lastSpokenText = text;
    this.state.lastEventTimestamp = Date.now();

    // 1. Check Native Android Bridge
    if (this.nativeBridge.isAvailable()) {
      this.state.lastTestStatus = 'speaking';
      this.notify();
      if (callbacks?.onStart) callbacks.onStart();

      const bridgeResult = await this.nativeBridge.speak(normalizedText);
      if (bridgeResult) {
        this.state.lastTestStatus = 'completed';
        this.state.ttsError = null;
        this.notify();
        if (callbacks?.onEnd) callbacks.onEnd();
        return { success: true };
      }
    }

    // 2. Check Standard Web Speech API
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      const err = 'এই ব্রাউজারে Web Speech API সমর্থিত নয়।';
      this.state.ttsError = err;
      this.state.lastTestStatus = 'error';
      this.notify();
      if (callbacks?.onError) callbacks.onError(err);
      if (callbacks?.onFallback) callbacks.onFallback(text);
      return { success: false, error: err };
    }

    // Re-verify voices if not loaded
    if (!this.state.voicesLoaded) {
      this.initVoices();
    }

    // STRICT: If no Bengali TTS voice installed, smoothly fallback to Priority 3: Offline Audio System!
    if (!this.bnVoice) {
      const offlinePlayed = await bengaliVoiceService.playAlert('voice_test', {
        customText: text,
        forceOffline: true,
        onStart: () => {
          this.state.lastTestStatus = 'speaking';
          this.notify();
          if (callbacks?.onStart) callbacks.onStart();
        },
        onEnd: () => {
          this.state.lastTestStatus = 'completed';
          this.notify();
          if (callbacks?.onEnd) callbacks.onEnd();
        },
      });

      if (offlinePlayed) {
        return { success: true };
      }

      const err =
        'এই ডিভাইসে বাংলা Text-to-Speech voice পাওয়া যায়নি। অফলাইন বাংলা অডিও কার্যকর করা হয়েছে।';
      this.state.ttsError = err;
      this.state.lastTestStatus = 'error';
      this.notify();
      if (callbacks?.onError) callbacks.onError(err);
      if (callbacks?.onFallback) callbacks.onFallback(text);
      return { success: false, error: err };
    }

    const currentSeq = ++this.speakSequence;

    try {
      // Android Bug Fix: cancel() এর পরে তাৎক্ষণিক speak() দিলে অনেক ডিভাইসে আটকে যায়
      // তাই ছোট একটি delay (৮০ms) দেওয়া হলো
      window.speechSynthesis.cancel();
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      await new Promise((resolve) => setTimeout(resolve, 80));

      if (this.speakSequence !== currentSeq) {
        // নতুন আরেকটি utterance চলে এসেছে, তাই এটি বাদ দিন
        return { success: false, error: 'পরবর্তী অ্যালার্ট অগ্রাধিকার পেয়েছে।' };
      }

      const utterance = new SpeechSynthesisUtterance(normalizedText);
      utterance.rate = 0.92; // স্বাভাবিক ও স্পষ্ট গতি
      utterance.pitch = 1.0;
      utterance.voice = this.bnVoice;
      utterance.lang = this.bnVoice.lang || 'bn-BD';

      // Android Garbage Collection Bug Fix: class reference এ সংরক্ষণ
      this.currentUtterance = utterance;

      return new Promise((resolve) => {
        utterance.onstart = () => {
          if (this.speakSequence !== currentSeq) return;
          this.state.lastTestStatus = 'speaking';
          this.state.ttsError = null;
          this.notify();
          if (callbacks?.onStart) callbacks.onStart();
        };

        utterance.onend = () => {
          if (this.speakSequence === currentSeq) {
            this.state.lastTestStatus = 'completed';
            this.currentUtterance = null;
            this.notify();
            if (callbacks?.onEnd) callbacks.onEnd();
            resolve({ success: true });
          }
        };

        utterance.onerror = (event) => {
          if (this.speakSequence === currentSeq) {
            const rawError = event.error || 'unknown_error';
            let banglaError = `TTS ত্রুটি (${rawError})`;
            if (rawError === 'not-allowed') {
              banglaError = 'ব্রাউজার অডিও পারমিশন রিস্ট্রিক্টেড। পেজে ট্যাপ করে আনলক করুন।';
            } else if (rawError === 'canceled') {
              banglaError = 'পূর্ববর্তী ভয়েস বাতিল হয়েছে।';
            } else if (rawError === 'interrupted') {
              banglaError = 'ভয়েস প্লেব্যাক বিঘ্নিত হয়েছে।';
            } else if (rawError === 'audio-busy') {
              banglaError = 'অডিও ডিভাইস অন্য কাজে ব্যস্ত।';
            }

            this.state.ttsError = banglaError;
            this.state.lastTestStatus = 'error';
            this.currentUtterance = null;
            this.notify();

            if (callbacks?.onError) callbacks.onError(banglaError);
            if (callbacks?.onFallback) callbacks.onFallback(text);
            resolve({ success: false, error: banglaError });
          }
        };

        window.speechSynthesis.speak(utterance);
      });
    } catch (e) {
      const err = (e as Error)?.message || 'TTS এক্সিকিউশন ত্রুটি';
      this.state.ttsError = err;
      this.state.lastTestStatus = 'error';
      this.notify();
      if (callbacks?.onError) callbacks.onError(err);
      if (callbacks?.onFallback) callbacks.onFallback(text);
      return { success: false, error: err };
    }
  }

  /**
   * থ্রি-টিয়ার বাংলা ভয়েস অ্যালার্ট ইঞ্জিন
   */
  public async playVoiceAlert(
    eventKey: AlertEventKey | 'voice_test' | 'offline_mode_announced',
    options?: {
      level?: number;
      customText?: string;
      voiceMode?: VoiceMode;
      forceOffline?: boolean;
    }
  ): Promise<boolean> {
    return bengaliVoiceService.playAlert(eventKey, {
      ...options,
      onStart: () => {
        this.state.lastTestStatus = 'speaking';
        this.notify();
      },
      onEnd: () => {
        this.state.lastTestStatus = 'completed';
        this.notify();
      },
      onError: (errMsg) => {
        this.state.ttsError = errMsg;
        this.state.lastTestStatus = 'error';
        this.notify();
      },
    });
  }

  /**
   * ভয়েস টেস্ট ফাংশন (ডায়াগনস্টিক পরীক্ষার জন্য সরাসরি)
   */
  public async testBengaliVoice(sampleSentence?: string): Promise<{ success: boolean; error?: string }> {
    this.state.lastTestStatus = 'testing';
    this.notify();

    // Reload voices immediately before test
    this.reloadVoices();

    if (sampleSentence && sampleSentence.trim()) {
      const ok = await bengaliVoiceService.speakCustomText(sampleSentence.trim(), {
        onStart: () => {
          this.state.lastTestStatus = 'speaking';
          this.notify();
        },
        onEnd: () => {
          this.state.lastTestStatus = 'completed';
          this.state.ttsError = null;
          this.notify();
        },
        onError: (err) => {
          this.state.lastTestStatus = 'error';
          this.state.ttsError = err;
          this.notify();
        },
      });

      if (ok) {
        return { success: true };
      }
      return this.speakBengali(sampleSentence.trim());
    }

    const ok = await bengaliVoiceService.testVoice();
    if (ok) {
      this.state.lastTestStatus = 'completed';
      this.state.ttsError = null;
      this.notify();
      return { success: true };
    }

    const sentence =
      'আপনার ফোনের চার্জ ৯০ শতাংশ হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।';

    return this.speakBengali(sentence);
  }

  public cancelSpeech(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    bengaliVoiceService.stopCurrentVoice();
    this.currentUtterance = null;
    this.state.lastTestStatus = 'idle';
    this.notify();
  }
}

export const alertEngine = new AlertEngine();
