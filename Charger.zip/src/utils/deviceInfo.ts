/**
 * ডিভাইস ও ব্রাউজার স্পেসিফিকেশন ডিটেক্টর
 */
import { DeviceInfo } from '../types';

export function getDeviceInfo(): DeviceInfo {
  if (typeof window === 'undefined') {
    return {
      browser: 'Unknown',
      os: 'Unknown',
      androidVersion: null,
      deviceModel: null,
      userAgent: '',
      isOnline: true,
      standalone: false,
      hasAudioOutput: false,
      audioDeviceCount: 0,
      usbSupported: false,
      bluetoothSupported: false,
      batteryApiSupported: false,
      speechSynthesisSupported: false,
      vibrationSupported: false,
      notificationSupported: false,
    };
  }

  const ua = navigator.userAgent;
  let os = 'Unknown';
  let androidVersion: string | null = null;
  let deviceModel: string | null = null;

  if (/android/i.test(ua)) {
    os = 'Android';
    const androidMatch = ua.match(/Android\s+([0-9.]+)/i);
    if (androidMatch) {
      androidVersion = `Android ${androidMatch[1]}`;
    }
    // Try to extract device model (e.g., Build/..., or between ; and Build)
    const modelMatch = ua.match(/;\s*([^;]+?)\s*Build\//i);
    if (modelMatch && modelMatch[1]) {
      deviceModel = modelMatch[1].trim();
    }
  } else if (/iphone|ipad|ipod/i.test(ua)) {
    os = 'iOS';
    deviceModel = /ipad/i.test(ua) ? 'iPad' : 'iPhone';
  } else if (/windows/i.test(ua)) {
    os = 'Windows';
  } else if (/mac/i.test(ua)) {
    os = 'macOS';
  } else if (/linux/i.test(ua)) {
    os = 'Linux';
  }

  let browser = 'Browser';
  if (/chrome|crios/i.test(ua) && !/edge|edg|opr\//i.test(ua)) {
    browser = 'Google Chrome';
  } else if (/firefox|fxios/i.test(ua)) {
    browser = 'Mozilla Firefox';
  } else if (/safari/i.test(ua) && !/chrome|crios/i.test(ua)) {
    browser = 'Apple Safari';
  } else if (/edg/i.test(ua)) {
    browser = 'Microsoft Edge';
  } else if (/samsungbrowser/i.test(ua)) {
    browser = 'Samsung Internet';
  }

  const standalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true;

  return {
    browser,
    os,
    androidVersion,
    deviceModel,
    userAgent: ua,
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    standalone,
    hasAudioOutput: false,
    audioDeviceCount: 0,
    usbSupported: typeof navigator !== 'undefined' && 'usb' in navigator,
    bluetoothSupported: typeof navigator !== 'undefined' && 'bluetooth' in navigator,
    batteryApiSupported: typeof navigator !== 'undefined' && 'getBattery' in navigator,
    speechSynthesisSupported: typeof window !== 'undefined' && 'speechSynthesis' in window,
    vibrationSupported: typeof navigator !== 'undefined' && 'vibrate' in navigator,
    notificationSupported: typeof window !== 'undefined' && 'Notification' in window,
  };
}
