/**
 * Web Worker based High-Precision Background Timer
 * 
 * Standard window.setInterval is aggressively throttled or suspended
 * by mobile browsers (Chrome / Safari / Edge) when the tab is hidden or backgrounded.
 * Web Workers run on a separate OS thread and continue executing timers
 * without tab visibility clamping when media keepalive is active.
 */

export class WorkerTimer {
  private worker: Worker | null = null;
  private callbacks: Map<number, () => void> = new Map();
  private nextId = 1;

  constructor() {
    if (typeof window !== 'undefined' && typeof Worker !== 'undefined') {
      try {
        const workerCode = `
          const activeTimers = new Map();
          self.onmessage = function(e) {
            const data = e.data;
            if (!data) return;
            if (data.action === 'start') {
              if (activeTimers.has(data.id)) {
                clearInterval(activeTimers.get(data.id));
              }
              const timerId = setInterval(function() {
                self.postMessage({ type: 'tick', id: data.id });
              }, data.interval);
              activeTimers.set(data.id, timerId);
            } else if (data.action === 'stop') {
              if (activeTimers.has(data.id)) {
                clearInterval(activeTimers.get(data.id));
                activeTimers.delete(data.id);
              }
            }
          };
        `;
        const blob = new Blob([workerCode], { type: 'application/javascript' });
        this.worker = new Worker(URL.createObjectURL(blob));
        this.worker.onmessage = (event: MessageEvent) => {
          const data = event.data;
          if (data && data.type === 'tick' && typeof data.id === 'number') {
            const cb = this.callbacks.get(data.id);
            if (cb) {
              cb();
            }
          }
        };
      } catch (err) {
        console.warn('[WorkerTimer] Failed to instantiate inline Web Worker, will use window.setInterval fallback:', err);
      }
    }
  }

  public setInterval(callback: () => void, intervalMs: number): number {
    const id = this.nextId++;
    this.callbacks.set(id, callback);

    if (this.worker) {
      this.worker.postMessage({ action: 'start', id, interval: intervalMs });
    } else if (typeof window !== 'undefined') {
      const fallbackId = window.setInterval(callback, intervalMs);
      this.callbacks.set(id, () => {
        window.clearInterval(fallbackId);
      });
      return fallbackId as unknown as number;
    }
    return id;
  }

  public clearInterval(id: number | null | undefined): void {
    if (id === null || id === undefined) return;
    this.callbacks.delete(id);

    if (this.worker) {
      this.worker.postMessage({ action: 'stop', id });
    } else if (typeof window !== 'undefined') {
      window.clearInterval(id);
    }
  }
}

export const workerTimer = new WorkerTimer();
