/**
 * বাংলা চার্জিং সহকারী (Charging Assistant) Types
 */

export interface BatteryState {
  supported: boolean;
  charging: boolean;
  level: number; // 0 to 1
  levelPercent: number; // 0 to 100
  chargingTime: number; // seconds or Infinity
  dischargingTime: number; // seconds or Infinity
  
  // Hardware metrics that standard Web Battery API does not provide
  // We keep them as null to strictly follow "no fake data" rule
  temperature: number | null; // in °C if available
  voltage: number | null; // in V if available
  current: number | null; // in A if available
  power: number | null; // in W if available
  chargingType: 'AC' | 'USB' | 'Wireless' | 'Unknown' | null;
  health: string | null;
  technology: string | null;
  capacityMah: number | null;
}

export interface ChargingSession {
  id: string;
  timestamp: number;
  startTime: string; // ISO or formatted
  endTime: string | null;
  startLevel: number;
  endLevel: number;
  durationSeconds: number;
  maxTemperature: number | null;
  chargingType: string;
  completed: boolean;
}

export type VoiceMode = 'automatic' | 'android_tts' | 'offline_audio';

export type AlertEventKey =
  | 'charger_connected'
  | 'charging_started'
  | 'target_reached'
  | 'charging_complete'
  | 'temperature_warning'
  | 'battery_low'
  | 'charger_removed'
  | 'usb_connected'
  | 'usb_disconnected'
  | 'earphone_connected'
  | 'earphone_disconnected'
  | 'reminder';

export interface AlertChannels {
  voice: boolean;
  sound: boolean;
  vibration: boolean;
  notification: boolean;
}

export interface CustomAlertPhrases {
  useCustomPhrases?: boolean; // When true, custom written sentences will be spoken
  customBengaliText?: string; // Main custom sentence (e.g. from Voice Writer)
  applyToTargetReached?: boolean; // Whether main customBengaliText applies to full charge / target
  charger_connected?: string; // Custom sentence when charger connected
  charger_removed?: string; // Custom sentence when charger removed
  target_reached?: string; // Custom sentence when battery reaches target
  battery_low?: string; // Custom sentence when battery is low
}

export interface AppSettings {
  serviceEnabled: boolean; // Master ON/OFF toggle for alerts and monitoring
  targetBatteryLevel: number; // 80, 85, 90, 95, 100, custom
  customTargetLevel: number;
  repeatReminderEnabled: boolean;
  reminderIntervalMinutes: number; // 5, 10, 15, 30, custom
  customIntervalMinutes: number;
  temperatureWarningEnabled: boolean;
  temperatureThreshold: number; // e.g. 40°C
  
  // Voice Mode & Global Alert Toggles
  voiceMode: VoiceMode;
  bengaliVoiceEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  notificationEnabled: boolean;
  
  // Per-Alert Granular Channel Controls (Section 8)
  alertChannels?: Partial<Record<AlertEventKey, AlertChannels>>;

  themeMode: 'system' | 'light' | 'dark';
  nightModeEnabled: boolean;
  nightTargetLevel: number;
  nightStartHour: number; // 0-23
  nightEndHour: number; // 0-23
  usbDetectionEnabled: boolean;
  peripheralDetectionEnabled: boolean;
  backgroundModeEnabled: boolean; // Keep speaking/monitoring in background via MediaSession & silent keepalive
  keepScreenOnWhileCharging: boolean; // Screen WakeLock API when connected to power
  customPhrases?: CustomAlertPhrases;
}

export type NotificationType =
  | 'charger_connected'
  | 'charger_disconnected'
  | 'target_reached'
  | 'charging_complete'
  | 'temperature_warning'
  | 'reminder'
  | 'usb_connected'
  | 'usb_disconnected'
  | 'earphone_connected'
  | 'earphone_disconnected'
  | 'peripheral_connected'
  | 'peripheral_disconnected'
  | 'service_toggled'
  | 'info';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
}

export interface DeviceInfo {
  browser: string;
  os: string;
  androidVersion: string | null;
  deviceModel: string | null;
  userAgent: string;
  isOnline: boolean;
  standalone: boolean;
  hasAudioOutput: boolean;
  audioDeviceCount: number;
  usbSupported: boolean;
  bluetoothSupported: boolean;
  batteryApiSupported: boolean;
  speechSynthesisSupported: boolean;
  vibrationSupported: boolean;
  notificationSupported: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  textBn: string;
  textEn: string;
  timestamp: number;
}

export interface CustomVoiceItem {
  id: string;
  text: string;
  timestamp: number;
}
