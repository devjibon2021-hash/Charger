import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { ChargingView } from './components/ChargingView';
import { ChatView } from './components/ChatView';
import { StatisticsView } from './components/StatisticsView';
import { AlertsView } from './components/AlertsView';
import { SettingsView } from './components/SettingsView';
import { DiagnosticModal } from './components/DiagnosticModal';
import { ToastBanner } from './components/ToastBanner';
import { useBatteryManager } from './hooks/useBatteryManager';
import { clearSessions, clearNotifications, DEFAULT_SETTINGS } from './utils/storage';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [diagnosticOpen, setDiagnosticOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  const {
    batteryState,
    settings,
    updateSettings,
    toggleService,
    sessions,
    setSessions,
    notifications,
    reminderActive,
    reminderSecondsLeft,
    stopReminder,
    testMode,
    simulatePluggedIn,
    simulateUnplugged,
    simulateTargetReached,
    simulateTempWarning,
    simulateLowBattery,
    simulateUsbConnect,
    simulateUsbDisconnect,
    simulateEarphoneConnect,
    simulateEarphoneDisconnect,
    exitTestMode,
    notificationPermission,
    requestNotificationPermission,
    toastMessage,
    dismissToast,
    backgroundState,
    backgroundTesting,
    backgroundCountdown,
    testBackgroundVoice,
  } = useBatteryManager();

  // Monitor network status
  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);

    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Sync Theme (Light / Dark / System)
  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = (theme: 'light' | 'dark') => {
      if (theme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    if (settings.themeMode === 'system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      applyTheme(prefersDark ? 'dark' : 'light');

      const mediaListener = (e: MediaQueryListEvent) => {
        applyTheme(e.matches ? 'dark' : 'light');
      };
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      mediaQuery.addEventListener('change', mediaListener);
      return () => mediaQuery.removeEventListener('change', mediaListener);
    } else {
      applyTheme(settings.themeMode);
    }
  }, [settings.themeMode]);

  // Handle Clear History
  const handleClearHistory = () => {
    clearSessions();
    setSessions([]);
  };

  // Handle Reset Settings
  const handleResetSettings = () => {
    updateSettings(DEFAULT_SETTINGS);
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-zinc-100/70 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors duration-200">
      {/* Mobile-constrained wrapper for perfect Android App viewport */}
      <div className="max-w-md mx-auto min-h-screen bg-zinc-50/40 dark:bg-zinc-950 relative flex flex-col shadow-[0_0_30px_rgba(0,0,0,0.03)] border-x border-zinc-200/80 dark:border-zinc-850">
        {/* Floating Toast Notification */}
        <ToastBanner message={toastMessage} onDismiss={dismissToast} />

        {/* Top Header */}
        <Header
          settings={settings}
          onUpdateSettings={updateSettings}
          onToggleService={toggleService}
          isOnline={isOnline}
          testMode={testMode}
          onExitTestMode={exitTestMode}
          onOpenDiagnostic={() => setDiagnosticOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 px-4 py-4 overflow-y-auto">
          {currentTab === 'home' && (
            <HomeView
              batteryState={batteryState}
              settings={settings}
              reminderActive={reminderActive}
              reminderSecondsLeft={reminderSecondsLeft}
              onStopReminder={stopReminder}
              notificationPermission={notificationPermission}
              onRequestNotificationPermission={requestNotificationPermission}
              onOpenDiagnostic={() => setDiagnosticOpen(true)}
              onToggleService={toggleService}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onUpdateSettings={updateSettings}
              backgroundState={backgroundState}
              backgroundTesting={backgroundTesting}
              backgroundCountdown={backgroundCountdown}
              onTestBackgroundVoice={testBackgroundVoice}
            />
          )}

          {currentTab === 'charging' && (
            <ChargingView
              batteryState={batteryState}
              settings={settings}
              onUpdateSettings={updateSettings}
              reminderActive={reminderActive}
              onStopReminder={stopReminder}
            />
          )}

          {currentTab === 'chat' && (
            <ChatView
              batteryState={batteryState}
              settings={settings}
              onUpdateSettings={updateSettings}
              onOpenDiagnostic={() => setDiagnosticOpen(true)}
            />
          )}

          {currentTab === 'stats' && (
            <StatisticsView
              sessions={sessions}
              onUpdateSessions={setSessions}
            />
          )}

          {currentTab === 'alerts' && (
            <AlertsView
              notifications={notifications}
              onClearNotifications={() => {
                clearNotifications();
              }}
              notificationPermission={notificationPermission}
              onRequestNotificationPermission={requestNotificationPermission}
              settings={settings}
              onUpdateSettings={updateSettings}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={updateSettings}
              batteryState={batteryState}
              onClearHistory={handleClearHistory}
              onResetSettings={handleResetSettings}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <BottomNav
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          unreadCount={unreadNotificationsCount}
        />

        {/* Diagnostic & Testing Modal */}
        <DiagnosticModal
          isOpen={diagnosticOpen}
          onClose={() => setDiagnosticOpen(false)}
          onSimulatePluggedIn={simulatePluggedIn}
          onSimulateUnplugged={simulateUnplugged}
          onSimulateTargetReached={simulateTargetReached}
          onSimulateTempWarning={simulateTempWarning}
          onSimulateUsbConnect={simulateUsbConnect}
          onSimulateUsbDisconnect={simulateUsbDisconnect}
          onSimulateEarphoneConnect={simulateEarphoneConnect}
          onSimulateEarphoneDisconnect={simulateEarphoneDisconnect}
          onExitTestMode={exitTestMode}
          isTestMode={testMode}
          currentLevel={batteryState.levelPercent}
        />
      </div>
    </div>
  );
}
