import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register Service Worker for offline support and background system notifications
if ('serviceWorker' in navigator) {
  import('virtual:pwa-register')
    .then(({ registerSW }) => {
      registerSW({
        immediate: true,
        onRegisteredSW(_swScriptUrl, registration) {
          console.log('[PWA] Service Worker registered:', registration);
        },
        onRegisterError(error) {
          console.warn('[PWA] Service Worker registration failed:', error);
        },
      });
    })
    .catch((err) => {
      console.warn('[PWA] virtual:pwa-register import error:', err);
    });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
