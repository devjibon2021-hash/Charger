import { useState, useEffect, useRef, useCallback } from 'react';
import { BatteryState, ChargingSession, AppSettings, AppNotification, AlertEventKey } from '../types';
import { toBn, toBnPercent } from '../utils/bnUtils';
import { alertEngine } from '../utils/alertEngine';
import { bengaliVoiceService } from '../services/bengaliVoiceService';
import { backgroundService, BackgroundServiceState } from '../services/backgroundService';
import { workerTimer } from '../utils/workerTimer';
import {
  loadSettings,
  saveSettings,
  loadSessions,
  addSession,
  addNotification,
  loadNotifications,
} from '../utils/storage';

interface BatteryManagerAPI extends EventTarget {
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
  level: number;
  onchargingchange: ((this: BatteryManagerAPI, ev: Event) => void) | null;
  onchargingtimechange: ((this: BatteryManagerAPI, ev: Event) => void) | null;
  ondischargingtimechange: ((this: BatteryManagerAPI, ev: Event) => void) | null;
  onlevelchange: ((this: BatteryManagerAPI, ev: Event) => void) | null;
}

export function useBatteryManager() {
  const [settings, setSettingsState] = useState<AppSettings>(loadSettings());
  const [batteryState, setBatteryState] = useState<BatteryState>({
    supported: false,
    charging: false,
    level: 0.85,
    levelPercent: 85,
    chargingTime: Infinity,
    dischargingTime: Infinity,
    temperature: null,
    voltage: null,
    current: null,
    power: null,
    chargingType: null,
    health: null,
    technology: null,
    capacityMah: null,
  });

  const [activeSession, setActiveSession] = useState<ChargingSession | null>(null);
  const [sessions, setSessions] = useState<ChargingSession[]>(loadSessions());
  const [notifications, setNotifications] = useState<AppNotification[]>(loadNotifications());
  const [reminderActive, setReminderActive] = useState<boolean>(false);
  const [reminderSecondsLeft, setReminderSecondsLeft] = useState<number>(0);
  const [testMode, setTestMode] = useState<boolean>(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );

  // Background service state
  const [backgroundState, setBackgroundState] = useState<BackgroundServiceState>(backgroundService.getState());
  const [backgroundTesting, setBackgroundTesting] = useState<boolean>(false);
  const [backgroundCountdown, setBackgroundCountdown] = useState<number | null>(null);

  // Fallback speech visual alert for when device lacks Bengali TTS voice
  const [toastMessage, setToastMessage] = useState<{ id: string; text: string; type: string } | null>(null);

  const prevChargingRef = useRef<boolean | null>(null);
  const hasAlertedTargetRef = useRef<boolean>(false);
  const hasAlertedLowBatteryRef = useRef<boolean>(false);
  const reminderTimerRef = useRef<number | null>(null);
  const reminderCountdownRef = useRef<number | null>(null);
  const batteryStateRef = useRef<BatteryState>(batteryState);
  const sessionStartLevelRef = useRef<number>(85);
  const sessionStartTimeRef = useRef<number>(Date.now());

  useEffect(() => {
    batteryStateRef.current = batteryState;
  }, [batteryState]);

  // Subscribe to background service
  useEffect(() => {
    return backgroundService.subscribe((s) => {
      setBackgroundState(s);
    });
  }, []);

  // Sync background service & wakeLock with settings
  useEffect(() => {
    const isServiceActive = settings.serviceEnabled !== false;
    const isBgActive = settings.backgroundModeEnabled !== false && isServiceActive;
    backgroundService.setEnabled(isBgActive);

    if (settings.keepScreenOnWhileCharging && batteryState.charging && isServiceActive) {
      backgroundService.requestWakeLock();
    } else {
      backgroundService.releaseWakeLock();
    }
  }, [settings.serviceEnabled, settings.backgroundModeEnabled, settings.keepScreenOnWhileCharging, batteryState.charging]);

  // Show a temporary banner toast
  const showToast = useCallback((text: string, type: string = 'info') => {
    const id = Math.random().toString();
    setToastMessage({ id, text, type });
    setTimeout(() => {
      setToastMessage((cur) => (cur?.id === id ? null : cur));
    }, 4500);
  }, []);

  // Dispatch both system browser notification (if permitted) and in-app record
  const dispatchNotification = useCallback(
    (type: AppNotification['type'], title: string, message: string) => {
      const notif: AppNotification = {
        id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        type,
        title,
        message,
        timestamp: Date.now(),
        read: false,
      };

      const updated = addNotification(notif);
      setNotifications(updated);

      // System notification via ServiceWorker (works reliably on Android Chrome & Background)
      if (settings.notificationEnabled) {
        backgroundService.showSystemNotification(title, {
          body: message,
          tag: type,
          vibrate: [300, 150, 300],
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
        });
      }

      showToast(`${title} — ${message}`, type);
    },
    [settings.notificationEnabled, showToast]
  );

  // Sync voiceMode with bengaliVoiceService whenever changed
  useEffect(() => {
    if (settings.voiceMode) {
      bengaliVoiceService.setVoiceMode(settings.voiceMode);
    }
  }, [settings.voiceMode]);

  // Trigger alert bundle (Sound + Bengali Voice + Vibration) with granular alert channel support
  const triggerAlertBundle = useCallback(
    (
      eventKeyOrTone: AlertEventKey | 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder',
      voiceTextOrOptions?:
        | string
        | {
            toneType?: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder';
            voiceText?: string;
            vibrateType?: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder';
            level?: number;
          },
      legacyVibrateType?: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder',
      alertLevel?: number
    ) => {
      let eventKey: AlertEventKey = 'target_reached';
      let toneType: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder' = 'target_reached';
      let vibrateType: 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder' = 'target_reached';
      let voiceText = '';
      let level: number | undefined = alertLevel;

      if (typeof voiceTextOrOptions === 'object' && voiceTextOrOptions !== null) {
        eventKey = eventKeyOrTone as AlertEventKey;
        toneType =
          voiceTextOrOptions.toneType ||
          (eventKey === 'charger_connected'
            ? 'connected'
            : eventKey === 'charger_removed'
            ? 'disconnected'
            : eventKey === 'target_reached'
            ? 'target_reached'
            : eventKey === 'temperature_warning'
            ? 'warning'
            : 'reminder');
        vibrateType = voiceTextOrOptions.vibrateType || toneType;
        voiceText = voiceTextOrOptions.voiceText || '';
        level = voiceTextOrOptions.level;
      } else {
        // Legacy call: (toneType, voiceText, vibrateType)
        toneType = eventKeyOrTone as 'connected' | 'disconnected' | 'target_reached' | 'warning' | 'reminder';
        vibrateType = legacyVibrateType || toneType;
        voiceText = typeof voiceTextOrOptions === 'string' ? voiceTextOrOptions : '';

        if (toneType === 'connected') eventKey = 'charger_connected';
        else if (toneType === 'disconnected') eventKey = 'charger_removed';
        else if (toneType === 'target_reached') eventKey = 'target_reached';
        else if (toneType === 'warning') eventKey = 'temperature_warning';
        else eventKey = 'reminder';
      }

      // Stop if service is completely turned OFF (except for explicit service toggle events)
      if (settings.serviceEnabled === false && (eventKey as string) !== 'service_turned_on' && (eventKey as string) !== 'service_turned_off') {
        return;
      }

      // Check granular channel preferences
      const channel = settings.alertChannels?.[eventKey] || {
        voice: true,
        sound: true,
        vibration: true,
        notification: true,
      };

      const soundActive = settings.soundEnabled && channel.sound !== false;
      const vibrateActive = settings.vibrationEnabled && channel.vibration !== false;
      const voiceActive = settings.bengaliVoiceEnabled && channel.voice !== false;

      if (soundActive) {
        alertEngine.playTone(toneType);
      }
      if (vibrateActive) {
        alertEngine.vibrate(vibrateType);
      }
      if (voiceActive) {
        alertEngine
          .playVoiceAlert(eventKey, {
            level,
            customText: voiceText,
            voiceMode: settings.voiceMode,
          })
          .then((success) => {
            if (!success && voiceText) {
              showToast(`🗣️ ভয়েস: "${voiceText}"`, 'voice');
            }
          });
      }
    },
    [
      settings.soundEnabled,
      settings.vibrationEnabled,
      settings.bengaliVoiceEnabled,
      settings.alertChannels,
      settings.voiceMode,
      showToast,
    ]
  );

  // Helper to resolve custom written phrase if user has written one
  const getEventVoiceText = useCallback(
    (eventKey: AlertEventKey, defaultText: string): string => {
      const phrases = settings.customPhrases;
      const useCustom = phrases?.useCustomPhrases !== false;

      if (useCustom && phrases) {
        // Check direct key in customPhrases (e.g. charger_connected, charger_removed, target_reached, battery_low, reminder)
        const customValue = phrases[eventKey as keyof typeof phrases];
        if (typeof customValue === 'string' && customValue.trim()) {
          return customValue.trim();
        }

        // If target_reached, charging_complete or reminder, fallback to main customBengaliText from Voice Writer
        if (
          (eventKey === 'target_reached' || eventKey === 'charging_complete' || (eventKey as string) === 'reminder') &&
          phrases.customBengaliText &&
          phrases.customBengaliText.trim()
        ) {
          return phrases.customBengaliText.trim();
        }
      }

      return defaultText;
    },
    [settings.customPhrases]
  );

  // Stop active repeating reminder
  const stopReminder = useCallback(() => {
    if (reminderTimerRef.current !== null) {
      workerTimer.clearInterval(reminderTimerRef.current);
      reminderTimerRef.current = null;
    }
    if (reminderCountdownRef.current !== null) {
      workerTimer.clearInterval(reminderCountdownRef.current);
      reminderCountdownRef.current = null;
    }
    setReminderActive(false);
    setReminderSecondsLeft(0);
  }, []);

  // Update Settings
  const updateSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setSettingsState((prev) => {
      const updated = { ...prev, ...newSettings };
      saveSettings(updated);

      // Instant synchronization with Native Android Bridge if running in APK / WebView
      if (typeof window !== 'undefined') {
        const w = window as unknown as Record<string, unknown>;
        try {
          if (w.ChargingAssistantNative && typeof (w.ChargingAssistantNative as Record<string, unknown>).syncSettings === 'function') {
            (w.ChargingAssistantNative as { syncSettings: (s: string) => boolean }).syncSettings(JSON.stringify(updated));
          } else if (w.Android && typeof (w.Android as Record<string, unknown>).syncSettings === 'function') {
            (w.Android as { syncSettings: (s: string) => boolean }).syncSettings(JSON.stringify(updated));
          }
        } catch (e) {
          console.error('Failed to sync settings with Native Android Bridge:', e);
        }
      }

      return updated;
    });
  }, []);

  // Request Notification Permission
  const requestNotificationPermission = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return 'denied';
    try {
      const perm = await Notification.requestPermission();
      setNotificationPermission(perm);
      if (perm === 'granted') {
        dispatchNotification('info', 'বিজ্ঞপ্তি সক্রিয় হয়েছে', 'চার্জিং সহকারী এখন আপনাকে তাৎক্ষণিক সতর্কতা পাঠাবে।');
      }
      return perm;
    } catch {
      return 'denied';
    }
  }, [dispatchNotification]);

  // Target level calculation (accounts for Night Mode)
  const getEffectiveTargetLevel = useCallback(() => {
    if (settings.nightModeEnabled) {
      const curHour = new Date().getHours();
      const isNight =
        settings.nightStartHour > settings.nightEndHour
          ? curHour >= settings.nightStartHour || curHour < settings.nightEndHour
          : curHour >= settings.nightStartHour && curHour < settings.nightEndHour;

      if (isNight) {
        return settings.nightTargetLevel;
      }
    }
    return settings.targetBatteryLevel === 0 ? settings.customTargetLevel : settings.targetBatteryLevel;
  }, [settings]);

  // Start repeated reminder
  const startRepeatedReminder = useCallback(
    (targetPct: number) => {
      if (!settings.repeatReminderEnabled) return;
      stopReminder();

      const intervalMins =
        settings.reminderIntervalMinutes === 0
          ? settings.customIntervalMinutes
          : settings.reminderIntervalMinutes;
      const intervalMs = Math.max(1, intervalMins) * 60 * 1000;

      setReminderActive(true);
      setReminderSecondsLeft(intervalMins * 60);

      reminderCountdownRef.current = workerTimer.setInterval(() => {
        setReminderSecondsLeft((prev) => {
          if (prev <= 1) return intervalMins * 60;
          return prev - 1;
        });
      }, 1000);

      reminderTimerRef.current = workerTimer.setInterval(() => {
        const liveLevel = batteryStateRef.current?.levelPercent ?? targetPct;
        const levelBn = toBn(liveLevel);
        const baseVoice = `বর্তমানে আপনার ফোনের ব্যাটারি ${levelBn} শতাংশ চার্জ হয়েছে।`;

        let reminderVoice = '';
        const customPhrase = (
          settings.customPhrases?.reminder ||
          settings.customPhrases?.customBengaliText ||
          ''
        ).trim();

        if (customPhrase) {
          if (customPhrase.includes('{percent}')) {
            reminderVoice = customPhrase.replace('{percent}', levelBn + '%');
          } else {
            reminderVoice = `${baseVoice} ${customPhrase}`;
          }
        } else {
          reminderVoice = `${baseVoice} চার্জিং অব্যাহত রয়েছে।`;
        }

        triggerAlertBundle('reminder', {
          toneType: 'reminder',
          voiceText: reminderVoice,
          vibrateType: 'reminder',
          level: liveLevel,
        });

        dispatchNotification(
          'reminder',
          `⏰ চার্জিং রিমাইন্ডার (${toBn(intervalMins)} মিনিট)`,
          `বর্তমান ব্যাটারি চার্জ: ${levelBn}% | ফোন চার্জ হচ্ছে।`
        );
      }, intervalMs);
    },
    [settings, stopReminder, triggerAlertBundle, dispatchNotification]
  );

  // Monitor Battery and Handle Events
  useEffect(() => {
    if (testMode) return; // User is using diagnostic test mode

    // 1. Native Android Bridge listener for live hardware battery status
    const handleNativeBattery = (e: CustomEvent | { detail: Record<string, unknown> }) => {
      const data = ('detail' in e ? e.detail : e) as Record<string, unknown>;
      if (!data) return;
      const isCharging = Boolean(data.isCharging);
      const levelNum = typeof data.level === 'number' ? data.level : 0;
      const levelPct = Math.round(levelNum);
      const level = levelPct / 100;
      const temp = typeof data.temperature === 'number' ? data.temperature : null;
      const volt = typeof data.voltage === 'number' ? data.voltage / 1000 : null;
      const plug = typeof data.plugType === 'string' && data.plugType !== 'none' ? data.plugType : isCharging ? 'AC' : null;

      setBatteryState((prev) => ({
        ...prev,
        supported: true,
        charging: isCharging,
        level: level,
        levelPercent: levelPct,
        temperature: temp !== null ? temp : prev.temperature,
        voltage: volt !== null ? volt : prev.voltage,
        chargingType: plug,
      }));
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('nativeBatteryChanged' as unknown as string, handleNativeBattery as EventListener);
      (window as unknown as Record<string, unknown>).onNativeBatteryUpdate = (data: Record<string, unknown>) => handleNativeBattery({ detail: data });
    }

    let batteryManager: BatteryManagerAPI | null = null;
    let isSubscribed = true;

    async function initBattery() {
      if (typeof navigator === 'undefined' || !('getBattery' in navigator)) {
        if (isSubscribed) {
          setBatteryState((prev) => ({
            ...prev,
            supported: false,
          }));
        }
        return;
      }

      try {
        const bm = await (navigator as unknown as { getBattery: () => Promise<BatteryManagerAPI> }).getBattery();
        if (!isSubscribed) return;
        batteryManager = bm;

        const updateBatteryInfo = () => {
          const isCharging = bm.charging;
          const level = bm.level;
          const levelPct = Math.round(level * 100);

          setBatteryState((prev) => ({
            ...prev,
            supported: true,
            charging: isCharging,
            level: level,
            levelPercent: levelPct,
            chargingTime: bm.chargingTime,
            dischargingTime: bm.dischargingTime,
            // Follow strict rule: Hardware parameters not available in standard web are kept null
            chargingType: isCharging ? 'AC' : null,
          }));

          // Handle Charging Status Transition
          if (prevChargingRef.current !== null && prevChargingRef.current !== isCharging) {
            if (isCharging) {
              // Charger Connected!
              hasAlertedTargetRef.current = false;
              stopReminder();

              sessionStartLevelRef.current = levelPct;
              sessionStartTimeRef.current = Date.now();

              const newSession: ChargingSession = {
                id: 'sess_' + Date.now(),
                timestamp: Date.now(),
                startTime: new Date().toISOString(),
                endTime: null,
                startLevel: levelPct,
                endLevel: levelPct,
                durationSeconds: 0,
                maxTemperature: null,
                chargingType: 'AC',
                completed: false,
              };
              setActiveSession(newSession);

              const isNative = typeof window !== 'undefined' && (
                Boolean((window as unknown as { isAndroidNativeApp?: boolean }).isAndroidNativeApp) ||
                Boolean((window as unknown as { ChargingAssistantNative?: unknown }).ChargingAssistantNative)
              );

              // 2. Charger Connected Notification & Bengali Voice (Web fallback if not native)
              if (!isNative) {
                const connVoice = getEventVoiceText('charger_connected', 'চার্জার সংযোগ করা হয়েছে।');
                triggerAlertBundle('charger_connected', {
                  toneType: 'connected',
                  voiceText: connVoice,
                  vibrateType: 'connected',
                  level: levelPct,
                });
                dispatchNotification(
                  'charger_connected',
                  '🔌 চার্জার সংযুক্ত হয়েছে',
                  `বর্তমান চার্জ ${toBn(levelPct)}%।`
                );

                // 3. Start Repeating Reminder if enabled in settings
                if (settings.repeatReminderEnabled) {
                  startRepeatedReminder(levelPct);
                }
              }
            } else {
              // Charger Disconnected!
              stopReminder();

              const endTime = Date.now();
              const durationSecs = Math.max(1, Math.round((endTime - sessionStartTimeRef.current) / 1000));

              const finishedSession: ChargingSession = {
                id: activeSession?.id || 'sess_' + Date.now(),
                timestamp: sessionStartTimeRef.current,
                startTime: new Date(sessionStartTimeRef.current).toISOString(),
                endTime: new Date(endTime).toISOString(),
                startLevel: sessionStartLevelRef.current,
                endLevel: levelPct,
                durationSeconds: durationSecs,
                maxTemperature: null,
                chargingType: 'AC',
                completed: true,
              };

              setActiveSession(null);
              setSessions(addSession(finishedSession));

              const isNative = typeof window !== 'undefined' && (
                Boolean((window as unknown as { isAndroidNativeApp?: boolean }).isAndroidNativeApp) ||
                Boolean((window as unknown as { ChargingAssistantNative?: unknown }).ChargingAssistantNative)
              );

              // 2. Charger Disconnected Notification & Bengali Voice (Web fallback if not native)
              if (!isNative) {
                const disconnVoice = getEventVoiceText('charger_removed', 'চার্জার খুলে ফেলা হয়েছে।');
                triggerAlertBundle('charger_removed', {
                  toneType: 'disconnected',
                  voiceText: disconnVoice,
                  vibrateType: 'disconnected',
                  level: levelPct,
                });
                dispatchNotification(
                  'charger_disconnected',
                  '🔌 চার্জার বিচ্ছিন্ন হয়েছে',
                  `শেষ চার্জ ছিল ${toBn(levelPct)}%। চার্জিং স্থায়িত্ব: ${durationSecs > 60 ? Math.round(durationSecs / 60) + ' মিনিট' : durationSecs + ' সেকেন্ড'}।`
                );
              }
            }
          } else if (prevChargingRef.current === null && isCharging) {
            // First run and already charging: start repeated reminder if enabled (Web fallback)
            const isNative = typeof window !== 'undefined' && (
              Boolean((window as unknown as { isAndroidNativeApp?: boolean }).isAndroidNativeApp) ||
              Boolean((window as unknown as { ChargingAssistantNative?: unknown }).ChargingAssistantNative)
            );
            if (!isNative && settings.repeatReminderEnabled && !reminderTimerRef.current) {
              startRepeatedReminder(levelPct);
            }
          }

          prevChargingRef.current = isCharging;

          // Check Target Battery Reached
          const isNative = typeof window !== 'undefined' && (
            Boolean((window as unknown as { isAndroidNativeApp?: boolean }).isAndroidNativeApp) ||
            Boolean((window as unknown as { ChargingAssistantNative?: unknown }).ChargingAssistantNative)
          );
          const targetLevel = getEffectiveTargetLevel();
          if (!isNative && isCharging && levelPct >= targetLevel && !hasAlertedTargetRef.current) {
            hasAlertedTargetRef.current = true;

            const isFull = levelPct >= 100;
            const defaultTargetVoice = isFull
              ? 'চার্জ সম্পূর্ণ হয়েছে। চার্জার খুলে দিন।'
              : `ব্যাটারি ${toBn(levelPct)} শতাংশ হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।`;
            const voiceText = getEventVoiceText('target_reached', defaultTargetVoice);

            const notifTitle = isFull ? '🔋 চার্জ সম্পূর্ণ হয়েছে' : `🔋 লক্ষ্যমাত্রা অর্জিত (${toBn(targetLevel)}%)`;
            const notifMsg = `আপনার ফোনের চার্জ ${toBn(levelPct)}% হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।`;

            triggerAlertBundle('target_reached', {
              toneType: 'target_reached',
              voiceText,
              vibrateType: 'target_reached',
              level: levelPct,
            });
            dispatchNotification('target_reached', notifTitle, notifMsg);

            // Trigger Repeating Reminder if enabled
            if (settings.repeatReminderEnabled) {
              startRepeatedReminder(levelPct);
            }
          }

          // Check Low Battery Alert (<= 20%)
          if (!isCharging && levelPct <= 20 && !hasAlertedLowBatteryRef.current) {
            hasAlertedLowBatteryRef.current = true;
            const lowVoice = getEventVoiceText('battery_low', 'ব্যাটারির চার্জ কম।');
            triggerAlertBundle('battery_low', {
              toneType: 'warning',
              voiceText: lowVoice,
              vibrateType: 'warning',
              level: levelPct,
            });
            dispatchNotification(
              'battery_low',
              '🪫 ব্যাটারি চার্জ কম',
              `আপনার ফোনের চার্জ ${toBn(levelPct)}% এ নেমে এসেছে। চার্জার সংযোগ করুন।`
            );
          } else if (isCharging || levelPct > 25) {
            hasAlertedLowBatteryRef.current = false;
          }
        };

        // Initial fetch
        updateBatteryInfo();

        bm.addEventListener('chargingchange', updateBatteryInfo);
        bm.addEventListener('levelchange', updateBatteryInfo);
        bm.addEventListener('chargingtimechange', updateBatteryInfo);
        bm.addEventListener('dischargingtimechange', updateBatteryInfo);
      } catch {
        if (isSubscribed) {
          setBatteryState((prev) => ({ ...prev, supported: false }));
        }
      }
    }

    initBattery();

    return () => {
      isSubscribed = false;
      if (batteryManager) {
        // cleanup listeners
      }
    };
  }, [
    testMode,
    activeSession,
    settings.repeatReminderEnabled,
    getEffectiveTargetLevel,
    triggerAlertBundle,
    dispatchNotification,
    startRepeatedReminder,
    stopReminder,
  ]);

  const prevAudioCountRef = useRef<number | null>(null);

  // Peripheral & USB Detection
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Media / Audio devices detection (Earphone/Headphone plugged/unplugged)
    if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
      const handleDeviceChange = async () => {
        if (!settings.peripheralDetectionEnabled) return;
        try {
          const devices = await navigator.mediaDevices.enumerateDevices();
          const audioOutputs = devices.filter((d) => d.kind === 'audiooutput' || d.kind === 'audioinput');
          const currentCount = audioOutputs.length;

          if (prevAudioCountRef.current !== null) {
            if (currentCount > prevAudioCountRef.current) {
              // Earphone/Headphone Connected!
              triggerAlertBundle('earphone_connected', {
                toneType: 'connected',
                voiceText: 'ইয়ারফোন সংযোগ করা হয়েছে।',
                vibrateType: 'connected',
              });
              dispatchNotification(
                'earphone_connected',
                '🎧 ইয়ারফোন সংযুক্ত হয়েছে',
                'ইয়ারফোন বা হেডফোন সংযোগ শনাক্ত হয়েছে।'
              );
            } else if (currentCount < prevAudioCountRef.current) {
              // Earphone Disconnected!
              triggerAlertBundle('earphone_disconnected', {
                toneType: 'disconnected',
                voiceText: 'ইয়ারফোন বিচ্ছিন্ন করা হয়েছে।',
                vibrateType: 'disconnected',
              });
              dispatchNotification(
                'earphone_disconnected',
                '🎧 ইয়ারফোন বিচ্ছিন্ন হয়েছে',
                'ইয়ারফোন বা হেডফোন খুলে ফেলা হয়েছে।'
              );
            }
          }
          prevAudioCountRef.current = currentCount;
        } catch {
          // ignore
        }
      };

      navigator.mediaDevices.addEventListener('devicechange', handleDeviceChange);
      navigator.mediaDevices.enumerateDevices().then((devices) => {
        const audioOutputs = devices.filter((d) => d.kind === 'audiooutput' || d.kind === 'audioinput');
        prevAudioCountRef.current = audioOutputs.length;
      }).catch(() => {});

      return () => {
        navigator.mediaDevices.removeEventListener('devicechange', handleDeviceChange);
      };
    }
  }, [settings.peripheralDetectionEnabled, dispatchNotification, triggerAlertBundle]);

  // WebUSB Detection
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('usb' in navigator)) return;
    const usb = (navigator as unknown as { usb: EventTarget }).usb;

    const onUsbConnect = () => {
      if (!settings.usbDetectionEnabled) return;
      dispatchNotification('usb_connected', '🔌 USB সংযোগ শনাক্ত হয়েছে', 'একটি নতুন USB ডিভাইস সংযুক্ত হয়েছে।');
      triggerAlertBundle('usb_connected', {
        toneType: 'connected',
        voiceText: 'ইউএসবি সংযোগ করা হয়েছে।',
        vibrateType: 'connected',
      });
    };

    const onUsbDisconnect = () => {
      if (!settings.usbDetectionEnabled) return;
      dispatchNotification('usb_disconnected', '🔌 USB সংযোগ বিচ্ছিন্ন হয়েছে', 'USB ডিভাইসটি খুলে ফেলা হয়েছে।');
      triggerAlertBundle('usb_disconnected', {
        toneType: 'disconnected',
        voiceText: 'ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে।',
        vibrateType: 'disconnected',
      });
    };

    usb.addEventListener('connect', onUsbConnect);
    usb.addEventListener('disconnect', onUsbDisconnect);

    return () => {
      usb.removeEventListener('connect', onUsbConnect);
      usb.removeEventListener('disconnect', onUsbDisconnect);
    };
  }, [settings.usbDetectionEnabled, dispatchNotification, triggerAlertBundle]);

  // Master Service Toggle (ON / OFF)
  const toggleService = useCallback((forceState?: boolean) => {
    setSettingsState((prev) => {
      const nextState = forceState !== undefined ? forceState : !prev.serviceEnabled;
      const updated = { ...prev, serviceEnabled: nextState };
      saveSettings(updated);

      if (nextState) {
        triggerAlertBundle('service_turned_on', {
          toneType: 'connected',
          voiceText: 'চার্জিং সহকারী চালু করা হয়েছে।',
          vibrateType: 'connected',
        });
        dispatchNotification('service_toggled', '⚡ চার্জিং সহকারী চালু', 'সমস্ত ভয়েস অ্যালার্ট ও মনিটরিং সক্রিয় করা হয়েছে।');
        showToast('⚡ চার্জিং সহকারী চালু (ON)', 'success');
      } else {
        stopReminder();
        alertEngine.cancelSpeech();
        bengaliVoiceService.stopCurrentVoice();
        triggerAlertBundle('service_turned_off', {
          toneType: 'disconnected',
          voiceText: 'চার্জিং সহকারী বন্ধ করা হয়েছে।',
          vibrateType: 'disconnected',
        });
        dispatchNotification('service_toggled', '⏸️ চার্জিং সহকারী বন্ধ', 'ভয়েস অ্যালার্ট ও নোটিফিকেশন সাময়িক বন্ধ করা হয়েছে।');
        showToast('⏸️ চার্জিং সহকারী বন্ধ (OFF)', 'warning');
      }

      return updated;
    });
  }, [triggerAlertBundle, dispatchNotification, showToast, stopReminder]);

  // Diagnostic Simulation Actions for User Testing
  const simulatePluggedIn = useCallback(
    (levelPct: number = 47) => {
      setTestMode(true);
      hasAlertedTargetRef.current = false;
      stopReminder();
      setBatteryState((prev) => ({
        ...prev,
        supported: true,
        charging: true,
        level: levelPct / 100,
        levelPercent: levelPct,
        chargingType: 'AC',
      }));

      sessionStartLevelRef.current = levelPct;
      sessionStartTimeRef.current = Date.now();

      const connVoice = getEventVoiceText('charger_connected', 'চার্জার সংযোগ করা হয়েছে।');
      triggerAlertBundle('charger_connected', {
        toneType: 'connected',
        voiceText: connVoice,
        vibrateType: 'connected',
        level: levelPct,
      });
      dispatchNotification(
        'charger_connected',
        '🔌 চার্জার সংযুক্ত হয়েছে (পরীক্ষা)',
        `বর্তমান চার্জ ${toBn(levelPct)}%।`
      );
    },
    [stopReminder, triggerAlertBundle, dispatchNotification, getEventVoiceText]
  );

  const simulateUnplugged = useCallback(
    (levelPct: number = 86) => {
      setTestMode(true);
      stopReminder();
      setBatteryState((prev) => ({
        ...prev,
        supported: true,
        charging: false,
        level: levelPct / 100,
        levelPercent: levelPct,
        chargingType: null,
      }));

      const durationSecs = 1800; // 30 mins
      const finishedSession: ChargingSession = {
        id: 'sess_test_' + Date.now(),
        timestamp: Date.now() - durationSecs * 1000,
        startTime: new Date(Date.now() - durationSecs * 1000).toISOString(),
        endTime: new Date().toISOString(),
        startLevel: sessionStartLevelRef.current || 47,
        endLevel: levelPct,
        durationSeconds: durationSecs,
        maxTemperature: null,
        chargingType: 'AC',
        completed: true,
      };

      setSessions(addSession(finishedSession));

      const disconnVoice = getEventVoiceText('charger_removed', 'চার্জার খুলে ফেলা হয়েছে।');
      triggerAlertBundle('charger_removed', {
        toneType: 'disconnected',
        voiceText: disconnVoice,
        vibrateType: 'disconnected',
        level: levelPct,
      });
      dispatchNotification(
        'charger_disconnected',
        '🔌 চার্জার বিচ্ছিন্ন হয়েছে (পরীক্ষা)',
        `শেষ চার্জ ছিল ${toBn(levelPct)}%। সময়: ৩০ মিনিট।`
      );
    },
    [stopReminder, triggerAlertBundle, dispatchNotification, getEventVoiceText]
  );

  const simulateTargetReached = useCallback(
    (pct: number = 90) => {
      setTestMode(true);
      setBatteryState((prev) => ({
        ...prev,
        supported: true,
        charging: true,
        level: pct / 100,
        levelPercent: pct,
        chargingType: 'AC',
      }));

      const isFull = pct >= 100;
      const defaultTargetVoice = isFull
        ? 'চার্জ সম্পূর্ণ হয়েছে। চার্জার খুলে দিন।'
        : `ব্যাটারি ${toBn(pct)} শতাংশ হয়েছে। চার্জার খুলে নেওয়ার সময় হয়েছে।`;
      const voiceText = getEventVoiceText('target_reached', defaultTargetVoice);

      triggerAlertBundle('target_reached', {
        toneType: 'target_reached',
        voiceText,
        vibrateType: 'target_reached',
        level: pct,
      });
      dispatchNotification(
        'target_reached',
        `🔋 আপনার ফোনের চার্জ ${toBn(pct)}% হয়েছে`,
        'চার্জার খুলে নেওয়ার সময় হয়েছে।'
      );

      if (settings.repeatReminderEnabled) {
        startRepeatedReminder(pct);
      }
    },
    [settings.repeatReminderEnabled, triggerAlertBundle, dispatchNotification, startRepeatedReminder, getEventVoiceText]
  );

  const simulateTempWarning = useCallback(() => {
    triggerAlertBundle('temperature_warning', {
      toneType: 'warning',
      voiceText: 'সতর্কতা! ব্যাটারির তাপমাত্রা অনেক বেশি। চার্জার খুলে ফোনটি ঠান্ডা হতে দিন।',
      vibrateType: 'warning',
    });
    dispatchNotification(
      'temperature_warning',
      '⚠️ উচ্চ তাপমাত্রা সতর্কতা (পরীক্ষা)',
      'ব্যাটারির তাপমাত্রা নিরাপদ সীমা অতিক্রম করেছে। চার্জার খুলে ফোনটি ঠান্ডা হতে দিন।'
    );
  }, [triggerAlertBundle, dispatchNotification]);

  const simulateLowBattery = useCallback(
    (levelPct: number = 15) => {
      setTestMode(true);
      setBatteryState((prev) => ({
        ...prev,
        supported: true,
        charging: false,
        level: levelPct / 100,
        levelPercent: levelPct,
        chargingType: null,
      }));
      triggerAlertBundle('battery_low', {
        toneType: 'warning',
        voiceText: 'ব্যাটারির চার্জ কম।',
        vibrateType: 'warning',
        level: levelPct,
      });
      dispatchNotification(
        'battery_low',
        '🪫 ব্যাটারি চার্জ কম (পরীক্ষা)',
        `আপনার ফোনের চার্জ ${toBn(levelPct)}% এ নেমে এসেছে।`
      );
    },
    [triggerAlertBundle, dispatchNotification]
  );

  const simulateUsbConnect = useCallback(() => {
    triggerAlertBundle('usb_connected', {
      toneType: 'connected',
      voiceText: 'ইউএসবি সংযোগ করা হয়েছে।',
      vibrateType: 'connected',
    });
    dispatchNotification('usb_connected', '🔌 USB সংযোগ (পরীক্ষা)', 'USB ডিভাইস সংযুক্ত হয়েছে।');
  }, [triggerAlertBundle, dispatchNotification]);

  const simulateUsbDisconnect = useCallback(() => {
    triggerAlertBundle('usb_disconnected', {
      toneType: 'disconnected',
      voiceText: 'ইউএসবি সংযোগ বিচ্ছিন্ন হয়েছে।',
      vibrateType: 'disconnected',
    });
    dispatchNotification('usb_disconnected', '🔌 USB বিচ্ছিন্ন (পরীক্ষা)', 'USB ডিভাইস বিচ্ছিন্ন হয়েছে।');
  }, [triggerAlertBundle, dispatchNotification]);

  const simulateEarphoneConnect = useCallback(() => {
    triggerAlertBundle('earphone_connected', {
      toneType: 'connected',
      voiceText: 'ইয়ারফোন সংযোগ করা হয়েছে।',
      vibrateType: 'connected',
    });
    dispatchNotification('earphone_connected', '🎧 ইয়ারফোন সংযুক্ত (পরীক্ষা)', 'ইয়ারফোন বা হেডফোন সংযুক্ত হয়েছে।');
  }, [triggerAlertBundle, dispatchNotification]);

  const simulateEarphoneDisconnect = useCallback(() => {
    triggerAlertBundle('earphone_disconnected', {
      toneType: 'disconnected',
      voiceText: 'ইয়ারফোন বিচ্ছিন্ন করা হয়েছে।',
      vibrateType: 'disconnected',
    });
    dispatchNotification('earphone_disconnected', '🎧 ইয়ারফোন বিচ্ছিন্ন (পরীক্ষা)', 'ইয়ারফোন বা হেডফোন বিচ্ছিন্ন হয়েছে।');
  }, [triggerAlertBundle, dispatchNotification]);

  const testBackgroundVoice = useCallback((delaySeconds = 5) => {
    setBackgroundTesting(true);
    setBackgroundCountdown(delaySeconds);

    // Ensure audio keepalive and media session are unlocked right on user tap
    backgroundService.ensureKeepaliveRunning();

    showToast(`⏳ ${toBn(delaySeconds)} সেকেন্ডের টেস্ট শুরু! এখনই হোম বাটন চেপে অ্যাপ মিনিমাইজ করুন বা স্ক্রিন অফ করুন।`, 'info');

    let remaining = delaySeconds;
    const interval = setInterval(() => {
      remaining -= 1;
      if (remaining > 0) {
        setBackgroundCountdown(remaining);
      } else {
        clearInterval(interval);
        setBackgroundTesting(false);
        setBackgroundCountdown(null);

        // Fire background voice alert!
        triggerAlertBundle('voice_test', {
          toneType: 'target_reached',
          voiceText: 'পরীক্ষা সফল হয়েছে! ব্যাকগ্রাউন্ডেও বাংলা ভয়েস সক্রিয় আছে।',
          vibrateType: 'target_reached',
        });

        dispatchNotification(
          'info',
          '🎉 ব্যাকগ্রাউন্ড ভয়েস পরীক্ষা সম্পন্ন',
          'অ্যাপ মিনিমাইজ বা স্ক্রিন লক থাকলেও বাংলা ভয়েস সফলভাবে বেজেছে।'
        );
      }
    }, 1000);
  }, [showToast, triggerAlertBundle, dispatchNotification]);

  const exitTestMode = useCallback(() => {
    setTestMode(false);
    prevChargingRef.current = null;
  }, []);

  return {
    batteryState,
    settings,
    updateSettings,
    toggleService,
    sessions,
    setSessions,
    notifications,
    reminderActive,
    reminderSecondsLeft,
    stopReminder,
    testMode,
    simulatePluggedIn,
    simulateUnplugged,
    simulateTargetReached,
    simulateTempWarning,
    simulateLowBattery,
    simulateUsbConnect,
    simulateUsbDisconnect,
    simulateEarphoneConnect,
    simulateEarphoneDisconnect,
    speakCustomText: bengaliVoiceService.speakCustomText.bind(bengaliVoiceService),
    exitTestMode,
    notificationPermission,
    requestNotificationPermission,
    toastMessage,
    dismissToast: () => setToastMessage(null),
    triggerAlertBundle,
    backgroundState,
    backgroundTesting,
    backgroundCountdown,
    testBackgroundVoice,
  };
}
