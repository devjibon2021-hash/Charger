import { useState, useEffect, useCallback } from 'react';
import { alertEngine, TTSDiagnosticState } from '../utils/alertEngine';

export function useTTSDiagnostics() {
  const [ttsState, setTtsState] = useState<TTSDiagnosticState>(alertEngine.getState());

  useEffect(() => {
    const unsubscribe = alertEngine.subscribe((state) => {
      setTtsState(state);
    });
    return unsubscribe;
  }, []);

  const testVoice = useCallback((sampleText?: string) => {
    return alertEngine.testBengaliVoice(sampleText);
  }, []);

  const reloadVoices = useCallback(() => {
    alertEngine.reloadVoices();
  }, []);

  const cancelSpeech = useCallback(() => {
    alertEngine.cancelSpeech();
  }, []);

  return {
    ...ttsState,
    testVoice,
    reloadVoices,
    cancelSpeech,
  };
}
