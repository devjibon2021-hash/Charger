import { useState, useEffect, useCallback } from 'react';
import { bengaliVoiceService, VoiceDiagnosticInfo } from '../services/bengaliVoiceService';
import { VoiceMode, AlertEventKey } from '../types';

export function useBengaliVoice() {
  const [voiceInfo, setVoiceInfo] = useState<VoiceDiagnosticInfo>(
    bengaliVoiceService.getDiagnosticInfo()
  );

  useEffect(() => {
    const unsubscribe = bengaliVoiceService.subscribe((info) => {
      setVoiceInfo(info);
    });
    return unsubscribe;
  }, []);

  const setVoiceMode = useCallback((mode: VoiceMode) => {
    bengaliVoiceService.setVoiceMode(mode);
  }, []);

  const testVoice = useCallback((customText?: string) => {
    return bengaliVoiceService.testVoice();
  }, []);

  const playAlert = useCallback(
    (eventKey: AlertEventKey, options?: { level?: number; customText?: string }) => {
      return bengaliVoiceService.playAlert(eventKey, options);
    },
    []
  );

  const stopVoice = useCallback(() => {
    bengaliVoiceService.stopCurrentVoice();
  }, []);

  const speakCustom = useCallback((text: string) => {
    return bengaliVoiceService.speakCustomText(text);
  }, []);

  return {
    ...voiceInfo,
    setVoiceMode,
    testVoice,
    playAlert,
    stopVoice,
    speakCustom,
  };
}
