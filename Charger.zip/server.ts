import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API health endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: Date.now() });
});

/**
 * Text-to-Speech (TTS) Proxy Endpoint
 * Generates natural Bengali and English speech audio for any custom text
 */
app.get('/api/tts', async (req, res) => {
  const rawText = (req.query.text as string) || '';
  const trimmed = rawText.trim();

  if (!trimmed) {
    res.status(400).json({ error: 'Text parameter is required' });
    return;
  }

  // Detect language if not provided
  let lang = (req.query.lang as string) || '';
  if (!lang || (lang !== 'bn' && lang !== 'en')) {
    const hasBengali = /[\u0980-\u09FF]/.test(trimmed);
    lang = hasBengali ? 'bn' : 'en';
  }

  try {
    // Split text into reasonable chunks (<= 170 chars) to prevent TTS cutoff
    const chunks: string[] = [];
    if (trimmed.length <= 170) {
      chunks.push(trimmed);
    } else {
      // Split by sentence delimiters
      const sentenceRegex = /[^।!?\n.,]+[।!?\n.,]*/g;
      const matches = trimmed.match(sentenceRegex) || [trimmed];
      let currentChunk = '';

      for (const sentence of matches) {
        if ((currentChunk + sentence).length <= 170) {
          currentChunk += sentence;
        } else {
          if (currentChunk) chunks.push(currentChunk.trim());
          if (sentence.length <= 170) {
            currentChunk = sentence;
          } else {
            // Split long sentence by space
            const words = sentence.split(' ');
            let wordChunk = '';
            for (const w of words) {
              if ((wordChunk + ' ' + w).length <= 170) {
                wordChunk = wordChunk ? wordChunk + ' ' + w : w;
              } else {
                if (wordChunk) chunks.push(wordChunk.trim());
                wordChunk = w;
              }
            }
            currentChunk = wordChunk;
          }
        }
      }
      if (currentChunk) chunks.push(currentChunk.trim());
    }

    const audioBuffers: Buffer[] = [];
    for (const chunk of chunks) {
      if (!chunk.trim()) continue;
      const encoded = encodeURIComponent(chunk.trim());
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encoded}&tl=${lang}&client=tw-ob`;

      const response = await fetch(url, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          Accept: 'audio/mpeg, audio/*;q=0.9, */*;q=0.8',
        },
      });

      if (!response.ok) {
        throw new Error(`TTS service returned ${response.status}`);
      }

      const arrayBuf = await response.arrayBuffer();
      audioBuffers.push(Buffer.from(arrayBuf));
    }

    if (audioBuffers.length === 0) {
      res.status(500).json({ error: 'Failed to generate speech audio' });
      return;
    }

    const finalBuffer = Buffer.concat(audioBuffers);
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Content-Length', finalBuffer.length);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(finalBuffer);
  } catch (error) {
    console.error('[Server TTS Error]:', error);
    res.status(502).json({
      error: 'TTS generation failed',
      details: error instanceof Error ? error.message : String(error),
    });
  }
});

/**
 * AI Assistant Chat Endpoint (Gemini API with fallback)
 */
app.post('/api/chat', async (req, res) => {
  const { message, batteryState } = req.body || {};
  const query = (message || '').trim();

  if (!query) {
    res.status(400).json({ error: 'Message is required' });
    return;
  }

  // If GEMINI_API_KEY is configured, try using Gemini
  if (process.env.GEMINI_API_KEY) {
    try {
      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

      const prompt = `You are an intelligent, friendly Bengali mobile charging and battery assistant.
User query: "${query}"
Phone battery context:
- Level: ${batteryState?.levelPercent ?? 'unknown'}%
- Charging: ${batteryState?.charging ? 'Yes (plugged in)' : 'No (on battery)'}
- Temperature: ${batteryState?.temperature ?? 'normal'}°C

Reply with a JSON object with two fields:
{
  "textBn": "Helpful, concise, friendly answer in pure natural Bengali",
  "textEn": "Concise English translation of the same answer"
}
Ensure the tone is helpful and direct. Return ONLY raw JSON without markdown code fences.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const responseText = response.text || '';
      const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);

      res.json({
        textBn: parsed.textBn,
        textEn: parsed.textEn,
      });
      return;
    } catch (err) {
      console.warn('[Gemini Chat Fallback]:', err);
      // fallback to standard rules below
    }
  }

  // Fallback response generator
  const q = query.toLowerCase();
  const currentPct = batteryState?.levelPercent ?? 75;
  const isCharging = batteryState?.charging ?? false;

  let textBn = `আমি আপনার চার্জিং সহকারী। আপনার ব্যাটারি চার্জ ${currentPct}%।`;
  let textEn = `I am your Charging Assistant. Your battery is at ${currentPct}%.`;

  if (q.includes('battery') || q.includes('ব্যাটারি') || q.includes('চার্জ')) {
    textBn = `আপনার ফোনের বর্তমান ব্যাটারি চার্জ ${currentPct}%। ${isCharging ? 'চার্জার সংযুক্ত আছে।' : 'ব্যাটারিতে চলছে।'}`;
    textEn = `Your phone currently has ${currentPct}% charge. ${isCharging ? 'Charger is connected.' : 'Running on battery.'}`;
  } else if (q.includes('tip') || q.includes('টিপস') || q.includes('স্বাস্থ্য')) {
    textBn = `ব্যাটারি দীর্ঘস্থায়ী রাখতে চার্জ ২০% থেকে ৮০% এর মধ্যে রাখুন এবং অতিরিক্ত গরম হতে দেবেন না।`;
    textEn = `To prolong battery lifespan, keep the level between 20% and 80% and avoid high temperatures.`;
  }

  res.json({ textBn, textEn });
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
